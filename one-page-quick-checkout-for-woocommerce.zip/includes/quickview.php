<?php

/**
 * WooCommerce Quick View Implementation
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class ONEPAQUC_Quick_View
{
    private $is_btn_add_hook_works;
    /**
     * Constructor
     */
    public function __construct()
    {
        // Initialize only if quick view is enabled
        if (get_option('rmenu_enable_quick_view', 0)) {
            // Add quick view button to product loops
            $this->add_quick_view_button();
            $this->is_btn_add_hook_works = false;

            // Enqueue scripts and styles
            add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));

            // Add quick view modal container to footer
            add_action('wp_footer', array($this, 'quick_view_modal_container'));

            // Add product data to each product element
            add_action('woocommerce_after_shop_loop_item', array($this, 'add_product_data'), 20);
            // fallback
            add_action('wp', function () {
                add_action('woocommerce_shop_loop', array($this, 'add_product_data'), 5);
                add_action('woocommerce_before_shop_loop_item', array($this, 'add_product_data'), 25);
                add_action('woocommerce_before_shop_loop_item_title', array($this, 'add_product_data'), 25);
                add_action('woocommerce_shop_loop_item_title', array($this, 'add_product_data'), 25);
                add_action('woocommerce_after_shop_loop_item_title', array($this, 'add_product_data'), 25);
                add_action('woocommerce_before_single_product_summary', array($this, 'add_product_data'), 5);
                add_action('woocommerce_single_product_summary', array($this, 'add_product_data'), 5);
                add_action('woocommerce_output_related_products_args', array($this, 'add_product_data'), 5);
                add_action('woocommerce_cross_sell_display', array($this, 'add_product_data'), 5);
                add_action('woocommerce_upsell_display', array($this, 'add_product_data'), 5);
            });
        }
    }

    /**
     * Add quick view button to appropriate locations
     */
    private function add_quick_view_button()
    {
        $button_position = get_option('rmenu_quick_view_button_position', 'image_overlay');
        $button_position = is_scalar($button_position) ? sanitize_key($button_position) : 'image_overlay';

        switch ($button_position) {
            case 'after_image':
                break;
            case 'before_title':
                add_action('woocommerce_before_shop_loop_item_title', array($this, 'display_quick_view_button'), 9);
                break;
            case 'after_title':
                add_action('woocommerce_shop_loop_item_title', array($this, 'display_quick_view_button'), 11);
                break;
            case 'before_price':
                add_action('woocommerce_after_shop_loop_item_title', array($this, 'display_quick_view_button'), 9);
                break;
            case 'after_price':
                add_action('woocommerce_after_shop_loop_item_title', array($this, 'display_quick_view_button'), 11);
                break;
            case 'before_add_to_cart':
            case 'after_add_to_cart':
                add_filter('woocommerce_loop_add_to_cart_link', array($this, 'onepaquc_display_quick_view_button_to_add_to_cart'), 100, 2);
                break;
            case 'image_overlay':
                break;
        }

        add_action('wp_enqueue_scripts', array($this, 'display_overlay_quick_view_button_footer'), 30);
    }


    public function onepaquc_display_quick_view_button_to_add_to_cart($link, $product)
    {
        global $displayed_quick_view_buttons; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Existing integration global retained for backward compatibility.
        $displayed_quick_view_buttons = true; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Existing integration global retained for backward compatibility.
        if (!$product instanceof WC_Product) {
            return $link;
        }

        // Check if product type is allowed
        $allowed_types = onepaquc_normalize_key_list(
            get_option('rmenu_show_quick_view_by_types', ['simple', 'variable', "grouped", "external"]),
            ['simple', 'variable', "grouped", "external"]
        );
        if (!in_array($product->get_type(), $allowed_types, true)) {
            return $link;
        }

        $this->is_btn_add_hook_works = true;

        // Check if current page is allowed
        $allowed_pages = onepaquc_normalize_key_list(
            get_option('rmenu_show_quick_view_by_page', ['shop-page', 'category-archives', 'tag-archives', 'brand-archives', 'attribute-archives', 'single', 'search', 'featured-products', 'on-sale', 'recent', 'widgets', 'shortcodes']),
            ['shop-page', 'category-archives', 'tag-archives', 'brand-archives', 'attribute-archives', 'single', 'search', 'featured-products', 'on-sale', 'recent', 'widgets', 'shortcodes']
        );
        if (!$this->is_allowed_quick_view_page($allowed_pages)) {
            return $link;
        }

        $position = get_option('rmenu_quick_view_button_position', 'image_overlay');

        $this->is_btn_add_hook_works = true;

        // Final button HTML
        $quick_view_button = $this->display_overlay_quick_view_button(true);
        switch ($position) {
            case 'before_add_to_cart':
                return $quick_view_button . ' ' . $link;

            default:
                return $link . ' ' . $quick_view_button;
        }
    }

    public function display_overlay_quick_view_button_footer()
    {
        if ($this->is_btn_add_hook_works) {
            return;
        }

        global $onepaquc_onepaquc_allowed_tags;

        $allowed_pages = onepaquc_normalize_key_list(
            get_option('rmenu_show_quick_view_by_page', ['shop-page', 'category-archives', 'tag-archives', 'brand-archives', 'attribute-archives', 'single', 'search', 'featured-products', 'on-sale', 'recent', 'widgets', 'shortcodes']),
            ['shop-page', 'category-archives', 'tag-archives', 'brand-archives', 'attribute-archives', 'single', 'search', 'featured-products', 'on-sale', 'recent', 'widgets', 'shortcodes']
        );

        if (is_singular('product') && !in_array('single', (array) $allowed_pages, true)) {
            return;
        }

        $button_contents = $this->button_contents();

        // Check if current page is allowed
        if (!$this->is_allowed_quick_view_page($allowed_pages)) {
            return;
        }

        if (!wp_script_is('rmenu-quick-view-scripts', 'enqueued')) {
            return;
        }

        $config = array(
            'buttonPos'    => sanitize_key(is_scalar(get_option('rmenu_quick_view_button_position', 'image_overlay')) ? get_option('rmenu_quick_view_button_position', 'image_overlay') : 'image_overlay'),
            'contents'     => wp_kses($button_contents['button_content'], $onepaquc_onepaquc_allowed_tags),
            'buttonClass'  => sanitize_text_field(implode(' ', $button_contents['button_classes'])),
            'buttonLabel'  => sanitize_text_field($button_contents['button_label']),
            'allowedTypes' => onepaquc_normalize_key_list(get_option('rmenu_show_quick_view_by_types', ['simple', 'variable', 'grouped', 'external']), ['simple', 'variable', 'grouped', 'external']),
        );

        $inline_script_parts = array(
            'jQuery(function($){',
            'var quickViewConfig=' . wp_json_encode($config) . ';',
            'var namespace=window.onepaqucQuickViewButtons=window.onepaqucQuickViewButtons||{};',
            'var scheduled=false;',
            'function getQuickViewProductData($product){var $button=$product.find(".button[data-product_id],.button[data-product-id],a[data-product_id],a[data-product-id],button[data-product_id],button[data-product-id]").first();var productId=$button.data("product_id")||$button.data("product-id")||$product.data("product_id")||$product.data("product-id");if(!productId){var idMatch=($product.attr("class")||"").match(/post-(\d+)/);productId=idMatch?idMatch[1]:null;}var productType=$button.data("product_type")||$button.data("product-type")||$product.data("product_type")||$product.data("product-type");if(!productType){var typeMatch=($product.attr("class")||"").match(/product-type-([A-Za-z0-9_-]+)/);productType=typeMatch?typeMatch[1]:null;}if(!productType&&$button.length){if($button.hasClass("product_type_simple")){productType="simple";}else if($button.hasClass("product_type_variable")){productType="variable";}else if($button.hasClass("product_type_grouped")){productType="grouped";}else if($button.hasClass("product_type_external")){productType="external";}}return{id:productId,type:productType};}',
            'function addQuickViewButton($product,productId){var $wrap=$("<div/>",{"class":"rmenu-quick-view-overlay "+quickViewConfig.buttonPos});var $button=$("<button/>",{"type":"button","class":quickViewConfig.buttonClass,"data-product-id":productId,"aria-label":quickViewConfig.buttonLabel,"title":quickViewConfig.buttonLabel}).html(quickViewConfig.contents);$wrap.append($button);if(quickViewConfig.buttonPos==="after_image"){var $image=$product.find("img").first();if($image.length){$image.after($wrap);}else{$product.append($wrap);}}else{$product.append($wrap);}}',
            'function initQuickViewButtons(container){var $container=container?$(container):$(document);$container.find(".product").addBack(".product").each(function(){var $this=$(this);if($("body").hasClass("single-product")&&!$this.closest("ul.products, .products").length){return;}if($this.find(".rmenu-quick-view-overlay,.opqvfw-btn").length){return;}var productData=getQuickViewProductData($this);if(quickViewConfig.allowedTypes.indexOf(productData.type)!==-1&&productData.id){addQuickViewButton($this,productData.id);}});cleanupOrphanedQuickViewButtons();}',
            'function cleanupOrphanedQuickViewButtons(){$(".rmenu-quick-view-overlay").each(function(){if(!$(this).closest(".product").length){$(this).remove();}});}',
            'function refreshQuickViewButtons(container){container=container||$(document);$(container).find(".rmenu-quick-view-overlay").remove();initQuickViewButtons(container);}',
            'function scheduleQuickViewButtons(container){if(scheduled){return;}scheduled=true;window.setTimeout(function(){scheduled=false;initQuickViewButtons(container);},100);}',
            'function observeQuickViewProductLists(){if(namespace.observer||!window.MutationObserver){return;}var target=document.querySelector(".woocommerce,.products,.wc-block-grid__products,.site-main")||document.body;if(!target){return;}namespace.observer=new MutationObserver(function(mutations){for(var i=0;i<mutations.length;i++){if(mutations[i].addedNodes&&mutations[i].addedNodes.length){scheduleQuickViewButtons();break;}}});namespace.observer.observe(target,{childList:true,subtree:true});}',
            'initQuickViewButtons();observeQuickViewProductLists();',
            '$("body").on("wc_fragments_loaded.onepaqucQuickView wc_fragments_refreshed.onepaqucQuickView post-load.onepaqucQuickView woocommerce_updated_cart_totals.onepaqucQuickView updated_checkout.onepaqucQuickView updated_shipping_method.onepaqucQuickView",function(event,data){if(data&&data.length){scheduleQuickViewButtons($(data));}else{scheduleQuickViewButtons();}});',
            'namespace.init=initQuickViewButtons;namespace.refresh=refreshQuickViewButtons;namespace.cleanup=cleanupOrphanedQuickViewButtons;',
            'window.initQuickViewButtons=initQuickViewButtons;window.refreshQuickViewButtons=refreshQuickViewButtons;window.cleanupOrphanedQuickViewButtons=cleanupOrphanedQuickViewButtons;',
            '});',
        );
        $inline_script = implode('', $inline_script_parts);

        wp_add_inline_script('rmenu-quick-view-scripts', $inline_script);
    }

    /**
     * Display quick view button
     */
    public function display_quick_view_button()
    {

        global $product;
        if (!$product instanceof WC_Product) {
            return;
        }

        // Check if product type is allowed
        $allowed_types = onepaquc_normalize_key_list(
            get_option('rmenu_show_quick_view_by_types', ['simple', 'variable', "grouped", "external"]),
            ['simple', 'variable', "grouped", "external"]
        );
        if (!in_array($product->get_type(), $allowed_types, true)) {
            return;
        }

        $this->is_btn_add_hook_works = true;

        // Check if current page is allowed
        $allowed_pages = onepaquc_normalize_key_list(
            get_option('rmenu_show_quick_view_by_page', ['shop-page', 'category-archives', 'tag-archives', 'brand-archives', 'attribute-archives', 'single', 'search', 'featured-products', 'on-sale', 'recent', 'widgets', 'shortcodes']),
            ['shop-page', 'category-archives', 'tag-archives', 'brand-archives', 'attribute-archives', 'single', 'search', 'featured-products', 'on-sale', 'recent', 'widgets', 'shortcodes']
        );
        if (!$this->is_allowed_quick_view_page($allowed_pages)) {
            return;
        }

        // Create button
        $this->render_quick_view_button($product);
    }

    /**
     * Display overlay quick view button on image
     */
    public function display_overlay_quick_view_button($is_return = false)
    {
        global $product;
        if (!$product instanceof WC_Product) {
            return $is_return ? '' : null;
        }

        $button_position_option = get_option('rmenu_quick_view_button_position', 'image_overlay');
        $button_position = is_scalar($button_position_option) ? sanitize_key($button_position_option) : 'image_overlay';

        $this->is_btn_add_hook_works = true;

        // Same checks as display_quick_view_button
        $allowed_types = onepaquc_normalize_key_list(
            get_option('rmenu_show_quick_view_by_types', ['simple', 'variable', "grouped", "external"]),
            ['simple', 'variable', "grouped", "external"]
        );
        if (!in_array($product->get_type(), $allowed_types, true)) {
            return $is_return ? '' : null;
        }

        if (!$is_return) {
            echo '<div class="rmenu-quick-view-overlay ' . esc_attr($button_position) . '">';
            $this->render_quick_view_button($product);
            echo '</div>';
        } else {
            ob_start();
            echo '<div class="rmenu-quick-view-overlay ' . esc_attr($button_position) . '">';
            $this->render_quick_view_button($product);
            echo '</div>';

            return ob_get_clean();
        }
    }

    /**
     * Render the actual quick view button HTML
     */
    private function render_quick_view_button($product)
    {
        static $displayed_products = array();
        if (!$product instanceof WC_Product) {
            return;
        }

        // Use product ID to track if we already displayed button for this product
        $product_id = $product->get_id();

        static $loop_counter = 0;
        $loop_counter++;
        $context_key = $product_id . '_' . $loop_counter;

        if (isset($displayed_products[$context_key])) {
            return; // Already displayed for this product
        }

        // Mark as displayed
        $displayed_products[$context_key] = true;

        $button_contents = $this->button_contents();

        // Output button HTML with data-product-id attribute
        $button_html = sprintf(
            '<button type="button" class="%1$s" data-product-id="%2$s" aria-label="%3$s" title="%3$s">%4$s</button>',
            esc_attr(implode(' ', $button_contents['button_classes'])),
            esc_attr($product->get_id()),
            esc_attr($button_contents['button_label']),
            $button_contents['button_content']
        );


        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Existing public compatibility hook retained for third-party integrations.
        echo wp_kses_post(apply_filters('rmenu_quick_view_button_html', $button_html, $product));
    }

    /**
     * Determine whether quick view should be displayed on current page.
     */
    private function is_allowed_quick_view_page($allowed_pages)
    {
        $allowed_pages = is_array($allowed_pages) ? $allowed_pages : array();

        if (in_array('shop-page', $allowed_pages, true) && is_shop()) {
            return true;
        }
        if (in_array('category-archives', $allowed_pages, true) && is_product_category()) {
            return true;
        }
        if (in_array('tag-archives', $allowed_pages, true) && is_product_tag()) {
            return true;
        }
        if (in_array('brand-archives', $allowed_pages, true) && $this->is_product_brand_archive()) {
            return true;
        }
        if (in_array('attribute-archives', $allowed_pages, true) && $this->is_product_attribute_archive()) {
            return true;
        }
        if (in_array('single', $allowed_pages, true) && function_exists('is_product') && is_product()) {
            return true;
        }
        if (in_array('search', $allowed_pages, true) && is_search()) {
            return true;
        }
        if (in_array('featured-products', $allowed_pages, true) && wc_get_loop_prop('is_featured')) {
            return true;
        }
        if (in_array('on-sale', $allowed_pages, true) && wc_get_loop_prop('is_on_sale')) {
            return true;
        }
        if (in_array('recent', $allowed_pages, true) && wc_get_loop_prop('is_recent')) {
            return true;
        }
        if (in_array('widgets', $allowed_pages, true) && (is_active_widget(false, false, 'woocommerce_products', true) || is_active_widget(false, false, 'woocommerce_top_rated_products', true))) {
            return true;
        }
        if (in_array('shortcodes', $allowed_pages, true) && is_singular() && !(function_exists('is_product') && is_product())) {
            return true;
        }

        return false;
    }

    /**
     * Check whether current page is a product attribute archive.
     */
    private function is_product_attribute_archive()
    {
        if (!is_tax()) {
            return false;
        }

        $queried_object = get_queried_object();
        if (!($queried_object instanceof WP_Term)) {
            return false;
        }

        return (0 === strpos($queried_object->taxonomy, 'pa_'));
    }

    /**
     * Check whether current page is a product brand archive.
     */
    private function is_product_brand_archive()
    {
        if (!is_tax()) {
            return false;
        }

        $queried_object = get_queried_object();
        if (!($queried_object instanceof WP_Term)) {
            return false;
        }

        $brand_taxonomies = apply_filters(
            'onepaquc_quick_view_brand_taxonomies',
            array('product_brand', 'pwb-brand', 'yith_product_brand')
        );

        if (!is_array($brand_taxonomies)) {
            $brand_taxonomies = array('product_brand', 'pwb-brand', 'yith_product_brand');
        }

        if (in_array($queried_object->taxonomy, $brand_taxonomies, true)) {
            return true;
        }

        return function_exists('is_product_taxonomy') && is_product_taxonomy() && (strpos($queried_object->taxonomy, 'brand') !== false);
    }

    public function button_contents()
    {
        $display_type = sanitize_key(is_scalar(get_option('rmenu_quick_view_display_type', 'icon')) ? get_option('rmenu_quick_view_display_type', 'icon') : 'icon');
        $display_type = in_array($display_type, array('icon', 'text', 'text_icon', 'hover_icon'), true) ? $display_type : 'icon';
        $button_icon = sanitize_key(is_scalar(get_option('rmenu_quick_view_button_icon', 'eye')) ? get_option('rmenu_quick_view_button_icon', 'eye') : 'eye');
        $button_icon = in_array($button_icon, array('none', 'eye', 'search', 'zoom', 'preview'), true) ? $button_icon : 'eye';
        $icon_position = sanitize_key(is_scalar(get_option('rmenu_quick_view_icon_position', 'left')) ? get_option('rmenu_quick_view_icon_position', 'left') : 'left');
        $icon_position = in_array($icon_position, array('left', 'right'), true) ? $icon_position : 'left';
        $button_position = sanitize_key(is_scalar(get_option('rmenu_quick_view_button_position', 'image_overlay')) ? get_option('rmenu_quick_view_button_position', 'image_overlay') : 'image_overlay');
        $button_text = onepaquc_get_text_option('rmenu_quick_view_button_text', __('Quick View', 'one-page-quick-checkout-for-woocommerce'));
        if (!is_scalar($button_text) || empty($button_text)) {
            $button_text = __('Quick View', 'one-page-quick-checkout-for-woocommerce');
        }

        // Generate icon HTML if needed
        $icon_html = '';
        if (empty($icon_html)) {
            if ($button_icon !== 'none' && ($display_type === 'icon' || $display_type === 'text_icon' || $display_type === 'hover_icon')) {
                $icon_html = '<span class="ricons ricons-' . $button_icon . '"></span>';
            }
        }



        // Generate button classes
        $button_classes = array('opqvfw-btn');
        $button_style_option = get_option('rmenu_quick_view_button_style', 'default');
        $button_style = is_scalar($button_style_option) ? sanitize_key($button_style_option) : 'default';

        if ($button_style === 'default') {
            $button_classes[] = 'button';
        } elseif ($button_style === 'alt') {
            $button_classes[] = 'button alt';
        } else {
            $button_classes[] = 'custom-style';
        }

        $button_classes[] = $button_position . ' display-' . $display_type;

        // Build button content
        $button_content = '';

        if ($display_type === 'icon') {
            $button_content = $icon_html;
        } elseif ($display_type === 'text_icon') {
            if ($icon_position === 'left') {
                $button_content = $icon_html . ' ' . esc_html($button_text);
            } else {
                $button_content = esc_html($button_text) . ' ' . $icon_html;
            }
        }
        // elseif ($display_type === 'hover_icon') {
        //     $button_content = '<span class="text">' . esc_html($button_text) . '</span><span class="icon">' . $icon_html . '</span>';
        //     $button_classes[] = 'hover-effect';
        // } 
        else {
            $button_content = esc_html($button_text);
        }

        return [
            "button_classes" => $button_classes,
            "button_content" => $button_content,
            "button_label"   => wp_strip_all_tags((string) $button_text),
        ];
    }

    /**
     * Add product data to product elements
     */
    public function add_product_data()
    {
        global $product; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce public loop global.

        static $displayed_product_data = array();

        if (!$product instanceof WC_Product) {
            return;
        }

        $product_id = $product->get_id();

        static $loop_counter = 0;
        $loop_counter++;
        $context_key = $product_id . '_' . $loop_counter;

        if (isset($displayed_product_data[$context_key])) {
            return; // Already displayed for this product
        }

        // Mark as displayed
        $displayed_product_data[$context_key] = true;

        // Get elements to display
        $elements = onepaquc_normalize_key_list(
            get_option('rmenu_quick_view_content_elements', ['image', 'title', 'rating', 'price', 'excerpt', 'add_to_cart', 'meta']),
            ['image', 'title', 'rating', 'price', 'excerpt', 'add_to_cart', 'meta']
        );

        // Prepare product data
        $product_data = array(
            'id' => $product_id,
            'title' => $product->get_name(),
            'price_html' => $product->get_price_html(),
            'type' => $product->get_type(),
            'excerpt' => $product->get_short_description(),
            'permalink' => $product->get_permalink(),
            'images' => array(),
            'variations' => array(),
            'attributes' => array(),
            'is_purchasable' => $product->is_purchasable(),
            'is_in_stock' => $product->is_in_stock(),
            'rating_html' => '',
            'add_to_cart_url' => $product->add_to_cart_url(),
            'stock_quantity' => $product->get_stock_quantity(),
            'min_purchase_quantity' => $product->get_min_purchase_quantity(),
            'max_purchase_quantity' => $product->get_max_purchase_quantity(),
            // Categories with HTML links
            'categories_html' => wc_get_product_category_list($product_id),
            'categories_text' => wp_strip_all_tags(wc_get_product_category_list($product_id)),
            // Tags with HTML links
            'tags_html' => wc_get_product_tag_list($product_id),
            'tags_text' => wp_strip_all_tags(wc_get_product_tag_list($product_id)),
            // Brands with HTML links (if using a brand taxonomy or plugin)
            'brands_html' => '',
            'brands_text' => '',
        );

        // Get brands - this depends on your setup
        // Option 1: If using a custom taxonomy 'product_brand'
        $brand_terms = get_the_terms($product->get_id(), 'product_brand');
        if ($brand_terms && !is_wp_error($brand_terms)) {
            $brand_links = array();
            $brand_names = array();
            foreach ($brand_terms as $brand) {
                $term_link = get_term_link($brand);
                if (is_wp_error($term_link)) {
                    continue;
                }
                $brand_links[] = '<a href="' . esc_url($term_link) . '">' . esc_html($brand->name) . '</a>';
                $brand_names[] = $brand->name;
            }
            $product_data['brands_html'] = implode(', ', $brand_links);
            $product_data['brands_text'] = implode(', ', $brand_names);
        }

        // Add rating if available
        if ($product->get_rating_count() > 0) {
            $product_data['rating_html'] = wc_get_rating_html($product->get_average_rating(), $product->get_rating_count());
            $product_data['rating_count'] = $product->get_rating_count();
            $product_data['average_rating'] = $product->get_average_rating();
        }

        // Add SKU if enabled
        if (wc_product_sku_enabled() && $product->get_sku()) {
            $product_data['sku'] = $product->get_sku();
        }

        $image_ids = array();
        $image_id = $product->get_image_id();
        if ($image_id) {
            $image_ids[] = $image_id;
        }
        $gallery_ids = $product->get_gallery_image_ids();
        if (!empty($gallery_ids)) {
            $image_ids = array_merge($image_ids, $gallery_ids);
        }
        $product_data['images'] = onepaquc_get_product_gallery_image_data($image_ids, 'shop_thumbnail', false);

        // Add variation data for variable products
        if ($product->is_type('variable')) {
            $product_data['attributes'] = $product->get_variation_attributes();
            $product_data['default_attributes'] = $product->get_default_attributes();

            // Get available variations
            $available_variations = onepaquc_get_validated_variations( $product );
            if (!empty($available_variations)) {
                foreach ($available_variations as $variation) {
                    if (!is_array($variation) || empty($variation['variation_id'])) {
                        continue;
                    }
                    $variation_id = $variation['variation_id'];
                    $variation_obj = wc_get_product($variation_id);
                    if (!$variation_obj instanceof WC_Product_Variation) {
                        continue;
                    }

                    $product_data['variations'][] = array(
                        'variation_id' => $variation_id,
                        'attributes' => isset($variation['attributes']) && is_array($variation['attributes']) ? $variation['attributes'] : array(),
                        'price_html' => $variation_obj->get_price_html(),
                        'is_in_stock' => $variation_obj->is_in_stock(),
                        'image_id' => isset($variation['image_id']) ? absint($variation['image_id']) : 0,
                        'image_src' => isset($variation['image']['src']) ? esc_url_raw($variation['image']['src']) : '',
                        // 'image_full_src' => $variation['image']['full_src'],
                    );
                }
            }
        }

        // Output data attribute with JSON encoded product data
        echo '<div class="rmenu-product-data" style="display:none;" data-product-info="' . esc_attr(wp_json_encode($product_data)) . '"></div>';
    }

    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts()
    {

        // Register and enqueue styles
        wp_register_style(
            'rmenu-quick-view-styles',
            plugin_dir_url(__FILE__) . '../assets/css/quick-view.css',
            array(),
            ONEPAQUC_VERSION
        );
        wp_enqueue_style('rmenu-quick-view-styles');

        // Register and enqueue scripts
        wp_register_script(
            'rmenu-quick-view-scripts',
            plugin_dir_url(__FILE__) . '../assets/js/quick-view.js',
            array('jquery'),
            ONEPAQUC_VERSION,
            true
        );

        // Get settings for JS
        $onepaquc_ajax_add_to_cart = onepaquc_is_enabled_option('rmenu_quick_view_ajax_add_to_cart', 1);
        $close_on_add = false;
        $keyboard_nav = onepaquc_is_enabled_option('rmenu_quick_view_keyboard_nav', 1);
        $effect =  'fade';
        $mobile_optimize = false;
        $debug_mode = onepaquc_is_enabled_option('rmenu_quick_view_debug_mode', 0);
        $lightbox = onepaquc_is_enabled_option('rmenu_quick_view_enable_lightbox', 1);
        $elements_in_popup = onepaquc_normalize_key_list(
            get_option('rmenu_quick_view_content_elements', ['image', 'title', 'rating', 'price', 'excerpt', 'add_to_cart', 'meta']),
            ['image', 'title', 'rating', 'price', 'excerpt', 'add_to_cart', 'meta']
        );

        // Localize script with settings
        wp_localize_script('rmenu-quick-view-scripts', 'rmenu_quick_view_params', array(
            'onepaquc_ajax_add_to_cart' => (bool) $onepaquc_ajax_add_to_cart,
            'close_on_add' => (bool) $close_on_add,
            'keyboard_nav' => (bool) $keyboard_nav,
            'effect' => $effect,
            'mobile_optimize' => (bool) $mobile_optimize,
            'debug' => (bool) $debug_mode,
            'lightbox' => (bool) $lightbox,
            'elements_in_popup' => $elements_in_popup,
            'ajax_url' => esc_url(admin_url('admin-ajax.php')),
            'nonce' => esc_js(wp_create_nonce('rmenu_quick_view_nonce')),
            'i18n' => array(
                'close' => onepaquc_get_text_option('rmenu_quick_view_close_text', __('Close', 'one-page-quick-checkout-for-woocommerce')),
                'prev' => onepaquc_get_text_option('rmenu_quick_view_prev_text', __('Previous Product', 'one-page-quick-checkout-for-woocommerce')),
                'next' => onepaquc_get_text_option('rmenu_quick_view_next_text', __('Next Product', 'one-page-quick-checkout-for-woocommerce')),
                'add_to_cart' => esc_html__('Add to cart', 'one-page-quick-checkout-for-woocommerce'),
                'select_options' => esc_html__('Select options', 'one-page-quick-checkout-for-woocommerce'),
                'view_details' => onepaquc_get_text_option('rmenu_quick_view_details_text', __('View Full Details', 'one-page-quick-checkout-for-woocommerce')),
                'out_of_stock' => esc_html__('Out of stock', 'one-page-quick-checkout-for-woocommerce'),
                'error_loading' => esc_html__('Error loading product information. Please try again.', 'one-page-quick-checkout-for-woocommerce'),
            )
        ));

        wp_enqueue_script('rmenu-quick-view-scripts');

        // Add dynamic CSS
        $this->add_dynamic_css();
    }

    /**
     * Add dynamic CSS for button styling
     */
    private function add_dynamic_css()
    {
        $button_style = get_option('rmenu_quick_view_button_style', 'default');

        if ($button_style === 'default') {
            return; // Only add dynamic CSS for custom style
        }
        $button_color = onepaquc_sanitize_hex_color(get_option('rmenu_quick_view_button_color', '#000'), '#000000');
        $text_color = onepaquc_sanitize_hex_color(get_option('rmenu_quick_view_text_color', '#ffffff'), '#ffffff');
        $button_color = $button_color ? $button_color : '#000000';
        $text_color = $text_color ? $text_color : '#ffffff';

        $custom_css = "
            .opqvfw-btn {
                background-color: {$button_color} !important;
                color: {$text_color} !important;
            }
            .opqvfw-btn:hover {
                background-color: {$button_color} !important;
                color: {$text_color} !important;
            }
        ";

        wp_add_inline_style('rmenu-quick-view-styles', $custom_css);
    }

    /**
     * Add quick view modal container to footer
     */
    public function quick_view_modal_container()
    {
    ?>
        <div class="opqvfw-modal-container">
            <div class="opqvfw-modal-overlay"></div>
            <div class="opqvfw-modal">
                <button type="button" class="rmenu-quick-view-close">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M15 5 5 15M5 5l10 10" />
                    </svg>
                    <span class="screen-reader-text"><?php echo esc_html(onepaquc_get_text_option('rmenu_quick_view_close_text', __('Close', 'one-page-quick-checkout-for-woocommerce'))); ?></span>
                </button>
                <div class="rmenu-quick-view-content">
                    <div class="rmenu-quick-view-loading">
                        <div class="rmenu-loader"></div>
                    </div>
                    <div class="rmenu-quick-view-inner"></div>
                </div>
                <div class="rmenu-quick-view-nav">
                    <button type="button" class="rmenu-quick-view-prev">
                        <svg width="22" height="22" viewBox="0 0 1.32 1.32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill="#fff" fill-opacity=".01" d="M0 0h1.32v1.32H0z" />
                            <path d="M.853.99.523.66l.33-.33" stroke="#fff" stroke-width=".11" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span class="screen-reader-text"><?php echo esc_html(onepaquc_get_text_option('rmenu_quick_view_prev_text', __('Previous Product', 'one-page-quick-checkout-for-woocommerce'))); ?></span>
                    </button>
                    <button type="button" class="rmenu-quick-view-next">
                        <svg width="22" height="22" viewBox="0 0 1.32 1.32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill="#fff" fill-opacity=".01" d="M0 0h1.32v1.32H0z" />
                            <path d="m.522.33.33.33-.33.33" stroke="#fff" stroke-width=".11" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span class="screen-reader-text"><?php echo esc_html(onepaquc_get_text_option('rmenu_quick_view_next_text', __('Next Product', 'one-page-quick-checkout-for-woocommerce'))); ?></span>
                    </button>
                </div>
            </div>
        </div>
<?php
    }
}

// Initialize the quick view class
$rmenu_quick_view = new ONEPAQUC_Quick_View(); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Existing integration global retained for backward compatibility.

/**
 * Add shortcode for quick view button
 */
// function rmenu_quick_view_shortcode($atts) {
//     $atts = shortcode_atts(array(
//         'product_id' => '',
//         'button_text' => get_option('rmenu_quick_view_button_text', 'Quick View')
//     ), $atts, 'rmenu_quick_view');
    
//     $product_id = absint($atts['product_id']);
    
//     if (!$product_id) {
//         return '';
//     }
    
//     $product = wc_get_product($product_id);
    
//     if (!$product) {
//         return '';
//     }
    
//     // Create temporary instance to use the method
//     $quick_view = new ONEPAQUC_Quick_View();
    
//     ob_start();
//     $quick_view->render_quick_view_button($product);
//     $quick_view->add_product_data();
//     return ob_get_clean();
// }
// add_shortcode('plugincy_quick_view', 'rmenu_quick_view_shortcode');
