<?php
if (! defined('ABSPATH')) exit; // Exit if accessed directly


// Admin Menu
add_action('admin_menu', 'onepaquc_cart_menu');


function onepaquc_cart_menu()
{

    add_menu_page(
        __('Onpage Checkout', 'one-page-quick-checkout-for-woocommerce'), // Page title
        __('Onpage Checkout', 'one-page-quick-checkout-for-woocommerce'), // Menu title
        'manage_options',
        'onepaquc_cart',
        'onepaquc_cart_dashboard',
        'dashicons-cart', // Shopping cart icon
        '55.50'
    );

    add_submenu_page(
        'onepaquc_cart',
        __('Cart Recovery', 'one-page-quick-checkout-for-woocommerce'), // Page title
        __('Cart Recovery <span class="onepaqucpro-menu-new-badge">NEW!</span>', 'one-page-quick-checkout-for-woocommerce'), // Menu title
        'manage_options',
        'onepaqucpro_cart_recovery',
        'onepaqucpro_cart_recovery_page'
    );

    add_submenu_page(
        'onepaquc_cart',
        __('Edit Recovery Email', 'one-page-quick-checkout-for-woocommerce'),
        '',
        'manage_options',
        'onepaqucpro_cart_recovery_template',
        'onepaqucpro_cart_recovery_template_page'
    );

    add_submenu_page(
        'onepaquc_cart',
        __('Documentation', 'one-page-quick-checkout-for-woocommerce'), // Page title
        __('Documentation', 'one-page-quick-checkout-for-woocommerce'), // Menu title
        'manage_options',
        'onepaquc_cart_documentation',
        'onepaquc_cart_documentation'
    );


    add_submenu_page(
        'onepaquc_cart',
        __('Get Pro', 'one-page-quick-checkout-for-woocommerce'), // Page title
        __('Get Pro', 'one-page-quick-checkout-for-woocommerce'), // Menu title
        'manage_options',
        'onepaquc_cart_get_pro',
        'onepaquc_cart_get_pro'
    );
}

// Callback function for Get Pro page
function onepaquc_cart_get_pro()
{
?>
    <div class="wrap">
        <h1>
            <?php esc_html_e('Upgrade to Onepage Checkout Pro', 'one-page-quick-checkout-for-woocommerce'); ?>
        </h1>



        <div class="onepaquc-pro-banner" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin: 20px 0;">
            <h2 style="color: white; margin-top: 0;">
                <?php esc_html_e('🚀 Unlock Premium Features', 'one-page-quick-checkout-for-woocommerce'); ?>
            </h2>

            <p style="font-size: 18px; margin-bottom: 30px;"><?php esc_html_e('Take your checkout experience to the next level with our premium features designed to boost conversions and enhance user experience.', 'one-page-quick-checkout-for-woocommerce'); ?></p>
            <a target="_blank" href="https://plugincy.com/one-page-quick-checkout-for-woocommerce/" class="button button-primary button-hero" style="background: #ff6b6b; border-color: #ff6b6b; text-shadow: none; box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);"><?php esc_html_e('Get Pro Version', 'one-page-quick-checkout-for-woocommerce'); ?></a>
        </div>

        <div class="onepaquc-features-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 30px 0;">

            <div class="feature-card" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-left: 4px solid #667eea;">
                <h3 style="color: #333; margin-top: 0;">🎨 <?php esc_html_e('Advanced Customization', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
                <ul style="color: #666; line-height: 1.6;">
                    <li><?php esc_html_e('Customizable checkout layout', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Advanced customizable checkout form', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Quick view popup modal size customization', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Customizable notifications on add to cart', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                </ul>
            </div>

            <div class="feature-card" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-left: 4px solid #764ba2;">
                <h3 style="color: #333; margin-top: 0;">⚡ <?php esc_html_e('Enhanced Checkout', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
                <ul style="color: #666; line-height: 1.6;">
                    <li><?php esc_html_e('Direct checkout for grouped products', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Popup checkout', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('One click purchase', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Single checkout without clear cart', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Advanced checkout options', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                </ul>
            </div>

            <div class="feature-card" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-left: 4px solid #ff6b6b;">
                <h3 style="color: #333; margin-top: 0;">🛒 <?php esc_html_e('Smart Shopping Features', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
                <ul style="color: #666; line-height: 1.6;">
                    <li><?php esc_html_e('Express Checkout Options', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Multi-Step Checkout', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Address auto complete', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Default quantity change', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Quantity selector in archives', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                </ul>
            </div>

            <div class="feature-card" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-left: 4px solid #51cf66;">
                <h3 style="color: #333; margin-top: 0;">📱 <?php esc_html_e('Mobile & UX Optimization', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
                <ul style="color: #666; line-height: 1.6;">
                    <li><?php esc_html_e('Quick view mobile optimization', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Add to cart mobile optimization', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Quick view loading effects', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Quick view close on add to cart', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                </ul>
            </div>

            <div class="feature-card" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-left: 4px solid #ffd93d;">
                <h3 style="color: #333; margin-top: 0;">🔐 <?php esc_html_e('Security & Control', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
                <ul style="color: #666; line-height: 1.6;">
                    <li><?php esc_html_e('Force Login Before Checkout', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Enable captcha on checkout', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Remove Product Button in checkout form', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Trusted badge in checkout form', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                </ul>
            </div>

            <div class="feature-card" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-left: 4px solid #ff8cc8;">
                <h3 style="color: #333; margin-top: 0;">📊 <?php esc_html_e('Analytics & Sharing', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
                <ul style="color: #666; line-height: 1.6;">
                    <li><?php esc_html_e('Quick view analytics', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Quick view shortcode', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Social share in quick view popup', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                    <li><?php esc_html_e('Product attributes in quick view', 'one-page-quick-checkout-for-woocommerce'); ?></li>
                </ul>
            </div>

        </div>

        <div class="onepaquc-cta-section" style="text-align: center; margin: 40px 0; padding: 30px; background: #f8f9fa; border-radius: 10px;">
            <h2 style="color: #333;"><?php esc_html_e('Ready to Boost Your Sales?', 'one-page-quick-checkout-for-woocommerce'); ?></h2>
            <p style="font-size: 16px; color: #666; margin-bottom: 25px;"><?php esc_html_e('Join thousands of store owners who have increased their conversion rates with our pro features.', 'one-page-quick-checkout-for-woocommerce'); ?></p>
            <a target="_blank" href="https://plugincy.com/one-page-quick-checkout-for-woocommerce/" class="button button-primary button-hero" style="background: #667eea; border-color: #667eea; margin-right: 15px;"><?php esc_html_e('Upgrade Now', 'one-page-quick-checkout-for-woocommerce'); ?></a>
            <a target="_blank" href="https://demo.plugincy.com/one-page-quick-checkout-for-woocommerce/" class="button button-secondary button-hero"><?php esc_html_e('View Demo', 'one-page-quick-checkout-for-woocommerce'); ?></a>
        </div>

        <div class="onepaquc-testimonials" style="background: white; padding: 30px; border-radius: 10px; margin: 20px 0;">
            <h3 style="text-align: center; color: #333; margin-bottom: 30px;"><?php esc_html_e('What Our Customers Say', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                <div style="padding: 20px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #667eea;">
                    <p style="font-style: italic; color: #666;"><?php esc_html_e('"The one-click purchase feature increased our conversion rate by 35%!"', 'one-page-quick-checkout-for-woocommerce'); ?></p>
                    <strong style="color: #333;">- Sarah M.</strong>
                </div>
                <div style="padding: 20px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #764ba2;">
                    <p style="font-style: italic; color: #666;"><?php esc_html_e('"Mobile optimization is fantastic. Our mobile sales doubled!"', 'one-page-quick-checkout-for-woocommerce'); ?></p>
                    <strong style="color: #333;">- John D.</strong>
                </div>
                <div style="padding: 20px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #ff6b6b;">
                    <p style="font-style: italic; color: #666;"><?php esc_html_e('"The customizable checkout layout perfectly matches our brand."', 'one-page-quick-checkout-for-woocommerce'); ?></p>
                    <strong style="color: #333;"><?php esc_html_e('- Maria L.', 'one-page-quick-checkout-for-woocommerce'); ?></strong>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// Display the form for Side Cart and PopUp settings
function onepaquc_cart_text_change_form($textvariable)
{
    $onepaquc_helper = new onepaquc_helper();
    $option_names    = array_keys((array) $textvariable);
    $option_values   = !empty($option_names)
        ? array_combine(
            $option_names,
            array_map(static function ($name) {
                return get_option($name, '');
            }, $option_names)
        )
        : array();

    echo '<div class="plugincy_card">';
    $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<svg fill="#fff" width="18" height="18" viewBox="0 0 0.27 0.27" xmlns="http://www.w3.org/2000/svg"><path d="M.27.022v.045a.022.022 0 0 1-.045 0V.045H.158v.18H.18a.022.022 0 0 1 0 .045H.09a.022.022 0 0 1 0-.045h.022v-.18H.045v.022a.022.022 0 1 1-.045 0V.022A.02.02 0 0 1 .022 0h.225a.02.02 0 0 1 .022.022"/></svg>', esc_html__('Cart Text Changes', 'one-page-quick-checkout-for-woocommerce'));

    echo '<div class="plugincy_grid" style="row-gap:10px">';

    foreach (array_chunk($textvariable, 4, true) as $column) {
        foreach ($column as $name => $label) {
            $value = isset($option_values[$name]) ? esc_attr($option_values[$name]) : '';
    ?>
            <label>
                <?php $onepaquc_helper->sec_head('p', '', '', esc_html($label), 'You can find "' . esc_html($label) . '" in the checkout form or drawer' . ($name === "txt-complete_your_purchase" ? " on single product pages." : ".")); ?>
                <input type="text" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value); ?>" />
            </label>
    <?php
        }
    }

    echo '</div> </div>';
}

function onepaquc_get_floating_cart_pro_empty_icon_options()
{
    return array(
        'cart' => __('Cart', 'one-page-quick-checkout-for-woocommerce'),
        'basket' => __('Basket', 'one-page-quick-checkout-for-woocommerce'),
        'shopping-bag' => __('Shopping Bag', 'one-page-quick-checkout-for-woocommerce'),
        'package' => __('Package', 'one-page-quick-checkout-for-woocommerce'),
        'receipt' => __('Receipt', 'one-page-quick-checkout-for-woocommerce'),
    );
}

function onepaquc_get_floating_cart_pro_text_defaults()
{
    return array(
        'your_cart' => 'Your Cart',
        'txt_Select_All' => 'Select All',
        'txt_Selected' => 'selected',
        'txt_subtotal' => 'Subtotal',
        'txt_total' => 'Total',
        'onepaquc_txt_checkout' => 'Checkout',
        'txt_you_may_like' => 'You may also like',
        'rmenu_floating_cart_empty_title' => 'Your Cart is Empty',
        'rmenu_floating_cart_shop_button_text' => 'Shop Now',
        'rmenu_floating_cart_coupon_title' => 'Have a coupon?',
        'rmenu_floating_cart_coupon_placeholder' => 'Enter coupon code',
        'rmenu_floating_cart_coupon_button_text' => 'Apply',
        'rmenu_floating_cart_variation_update_text' => 'Update',
        'rmenu_floating_cart_variation_cancel_text' => 'Cancel',
        'rmenu_floating_cart_applied_coupons_heading' => 'Applied Coupons:',
        'rmenu_floating_cart_remove_coupon_text' => 'Remove',
        'rmenu_floating_cart_discount_label' => 'Discount',
        'rmenu_floating_cart_shipping_options_label' => 'Shipping options',
        'rmenu_floating_cart_shipping_label' => 'Shipping',
        'rmenu_floating_cart_tax_label' => 'Tax',
        'rmenu_floating_cart_related_add_to_cart_text' => 'Add to cart',
        'rmenu_floating_cart_applying_text' => 'Applying...',
        'rmenu_floating_cart_applying_coupon_text' => 'Applying coupon...',
        'rmenu_floating_cart_coupon_applied_message' => 'Coupon applied successfully!',
        'rmenu_floating_cart_invalid_coupon_message' => 'Invalid coupon code.',
        'rmenu_floating_cart_error_try_again_message' => 'Something went wrong. Please try again.',
        'rmenu_floating_cart_removing_text' => 'Removing...',
        'rmenu_floating_cart_removing_coupon_text' => 'Removing coupon...',
        'rmenu_floating_cart_coupon_removed_message' => 'Coupon removed successfully!',
        'rmenu_floating_cart_failed_remove_coupon_message' => 'Failed to remove coupon. Please try again.',
        'rmenu_floating_cart_preloader_message' => 'Bringing you the goods...',
        'rmenu_floating_cart_preloader_slow_message' => 'This is taking long. Something is wrong.',
        'rmenu_floating_cart_iframe_error_message' => 'Error loading checkout. Please try again.',
        'rmenu_floating_cart_select_variation_error_message' => 'Please choose a valid variation before updating.',
        'rmenu_floating_cart_update_variation_error_message' => 'Could not update the selected variation. Please try again.',
        'rmenu_floating_cart_variation_disabled_message' => 'Variation switching is not enabled.',
        'rmenu_floating_cart_item_not_found_message' => 'The selected cart item could not be found.',
        'rmenu_floating_cart_item_not_variable_message' => 'This cart item does not support variation switching.',
        'rmenu_floating_cart_invalid_variation_message' => 'The selected variation is invalid.',
        'rmenu_floating_cart_same_variation_message' => 'The selected variation is already in your cart.',
        'rmenu_floating_cart_unavailable_variation_message' => 'The selected variation cannot be added to the cart right now.',
        'rmenu_floating_cart_original_item_update_error_message' => 'The original cart item could not be updated.',
        'rmenu_floating_cart_variation_updated_message' => 'Variation updated successfully.',
        'rmenu_floating_cart_cart_unavailable_message' => 'WooCommerce cart is not available.',
        'rmenu_floating_cart_quantity_update_error_message' => 'Could not update quantity.',
        'rmenu_floating_cart_no_cart_item_key_message' => 'No cart item key provided.',
        'rmenu_floating_cart_remove_items_error_message' => 'Could not remove some items.',
        'rmenu_floating_cart_remove_item_aria_label' => 'Remove this item',
        'rmenu_floating_cart_decrease_quantity_label' => 'Decrease quantity',
        'rmenu_floating_cart_increase_quantity_label' => 'Increase quantity',
    );
}

function onepaquc_get_floating_cart_pro_element_groups()
{
    return array(
        __('Floating Button', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Controls for the sticky cart button shown outside the drawer.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_show_cart_icon' => __('Cart Button Icon', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_cart_count' => __('Cart Button Count', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Cart Items', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Controls for product rows, item actions, and product details.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_show_select_bar' => __('Select Bar', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_item_select' => __('Item Checkbox', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_remove_item' => __('Remove Item', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_product_image' => __('Product Image', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_product_title' => __('Product Title', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_product_price' => __('Product Price', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_quantity' => __('Quantity Controls', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_variation_editor' => __('Variation Selector', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_item_meta' => __('Cart Item Meta', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_group_items' => __('Group Cart Items', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Coupon', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Controls for the coupon form and coupon collapse behavior.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_show_coupon' => __('Coupon Form', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_coupon_title' => __('Coupon Title', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_coupon_collapsible' => __('Collapsible Coupon', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_coupon_initially_collapsed' => __('Coupon Initially Collapsed', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Recommendations', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Controls for suggested products shown inside the drawer.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_show_recommendations' => __('Related Products', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Summary & Shipping', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Controls for totals, shipping options, and summary collapse behavior.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_show_summary' => __('Cart Summary', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_summary_collapsible' => __('Collapsible Summary', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_summary_initially_collapsed' => __('Summary Initially Collapsed', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_subtotal' => __('Subtotal Row', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_discount' => __('Discount Row', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_shipping_options' => __('Shipping Options', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_shipping_total' => __('Shipping Row', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_tax_total' => __('Tax Row', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_total' => __('Total Row', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Checkout & Empty Cart', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Controls for the checkout action and empty-cart drawer state.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_show_checkout' => __('Checkout Button', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_empty_icon' => __('Empty Cart Icon', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_show_shop_button' => __('Shop Button', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
    );
}

function onepaquc_get_floating_cart_pro_text_groups()
{
    return array(
        __('Drawer Header & Selection', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Labels shown in the drawer header and selection bar.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'your_cart' => __('Drawer Title', 'one-page-quick-checkout-for-woocommerce'),
                'txt_Select_All' => __('Select All Label', 'one-page-quick-checkout-for-woocommerce'),
                'txt_Selected' => __('Selected Count Suffix', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Empty Cart', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Text shown when the floating cart drawer has no products.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_empty_title' => __('Empty Cart Title', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_shop_button_text' => __('Shop Button', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Coupon', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Coupon section labels and applied-coupon controls.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_coupon_title' => __('Coupon Title', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_coupon_placeholder' => __('Coupon Placeholder', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_coupon_button_text' => __('Coupon Button', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_applied_coupons_heading' => __('Applied Coupons Heading', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_remove_coupon_text' => __('Remove Coupon', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Variation Editor', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Button text used when changing a variable product inside the drawer.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_variation_update_text' => __('Variation Update Button', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_variation_cancel_text' => __('Variation Cancel Button', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Recommendations', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Text used for related products in the floating cart drawer.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'txt_you_may_like' => __('Related Products Heading', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_related_add_to_cart_text' => __('Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Summary & Checkout', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Labels used for totals, shipping, tax, and the checkout action.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'txt_subtotal' => __('Subtotal Label', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_discount_label' => __('Discount Label', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_shipping_options_label' => __('Shipping Options Heading', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_shipping_label' => __('Shipping Label', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_tax_label' => __('Tax Label', 'one-page-quick-checkout-for-woocommerce'),
                'txt_total' => __('Total Label', 'one-page-quick-checkout-for-woocommerce'),
                'onepaquc_txt_checkout' => __('Checkout Button', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
    );
}

function onepaquc_get_floating_cart_pro_feedback_text_groups()
{
    return array(
        __('General Status', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Shared loading, removing, and error messages used by drawer actions.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_applying_text' => __('Generic Loading Text', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_error_try_again_message' => __('Generic Error Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_removing_text' => __('Generic Removing Text', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_cart_unavailable_message' => __('Cart Unavailable Message', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Coupon Feedback', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Messages shown while applying or removing coupons in the drawer.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_applying_coupon_text' => __('Applying Coupon Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_coupon_applied_message' => __('Coupon Applied Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_invalid_coupon_message' => __('Invalid Coupon Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_removing_coupon_text' => __('Removing Coupon Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_coupon_removed_message' => __('Coupon Removed Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_failed_remove_coupon_message' => __('Coupon Remove Error Message', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Variation Feedback', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Messages for drawer variation selection and update flows.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_select_variation_error_message' => __('Variation Selection Error', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_update_variation_error_message' => __('Variation Update Error', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_variation_disabled_message' => __('Variation Disabled Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_item_not_variable_message' => __('Not Variable Item Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_invalid_variation_message' => __('Invalid Variation Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_same_variation_message' => __('Same Variation Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_unavailable_variation_message' => __('Unavailable Variation Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_original_item_update_error_message' => __('Original Item Update Error', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_variation_updated_message' => __('Variation Updated Message', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Cart Item & Quantity Feedback', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Messages for cart item lookup, quantity changes, and item removal.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_item_not_found_message' => __('Cart Item Missing Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_quantity_update_error_message' => __('Quantity Update Error', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_no_cart_item_key_message' => __('Missing Cart Item Key Message', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_remove_items_error_message' => __('Remove Items Error', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
        __('Accessibility Labels', 'one-page-quick-checkout-for-woocommerce') => array(
            'description' => __('Labels used by screen readers for item and quantity controls.', 'one-page-quick-checkout-for-woocommerce'),
            'settings' => array(
                'rmenu_floating_cart_remove_item_aria_label' => __('Remove Item Accessibility Label', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_decrease_quantity_label' => __('Decrease Quantity Accessibility Label', 'one-page-quick-checkout-for-woocommerce'),
                'rmenu_floating_cart_increase_quantity_label' => __('Increase Quantity Accessibility Label', 'one-page-quick-checkout-for-woocommerce'),
            ),
        ),
    );
}

function onepaquc_render_floating_cart_pro_badge()
{
    ?>
    <span class="onepaquc-pro-feature-badge"><?php esc_html_e('Pro Feature', 'one-page-quick-checkout-for-woocommerce'); ?></span>
    <?php
}

function onepaquc_render_floating_cart_pro_switch($name, $label)
{
    ?>
    <div class="onepaquc-floating-pro-field plugincy_row items_center pro-only">
        <label class="onepaquc-floating-pro-label"><?php echo esc_html($label); ?></label>
        <div class="onepaquc-floating-pro-control">
            <label class="switch">
                <input type="checkbox" name="<?php echo esc_attr('pro_' . $name); ?>" value="1" disabled />
                <span class="slider round"></span>
            </label>
            <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
        </div>
    </div>
    <?php
}

function onepaquc_render_floating_cart_pro_text_field($name, $label, $placeholder = '')
{
    ?>
    <label class="onepaquc-floating-pro-field onepaquc-floating-pro-field-text pro-only">
        <span class="onepaquc-floating-pro-label"><?php echo esc_html($label); ?></span>
        <span class="onepaquc-floating-pro-control">
            <input type="text" name="<?php echo esc_attr('pro_' . $name); ?>" value="" placeholder="<?php echo esc_attr($placeholder); ?>" disabled />
            <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
        </span>
    </label>
    <?php
}

function onepaquc_render_floating_cart_pro_select($name, $label, $options, $selected = '')
{
    ?>
    <div class="onepaquc-floating-pro-field plugincy_row items_center pro-only">
        <label class="onepaquc-floating-pro-label"><?php echo esc_html($label); ?></label>
        <div class="onepaquc-floating-pro-control">
            <select name="<?php echo esc_attr('pro_' . $name); ?>" class="rmenu-select" disabled>
                <?php foreach ($options as $option_value => $option_label) : ?>
                    <option value="<?php echo esc_attr($option_value); ?>" <?php selected($selected, $option_value); ?>><?php echo esc_html($option_label); ?></option>
                <?php endforeach; ?>
            </select>
            <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
        </div>
    </div>
    <?php
}

function onepaquc_render_floating_cart_pro_meta_rule_builder($name, $label)
{
    ?>
    <div class="onepaquc-floating-pro-field onepaquc-floating-pro-field-stack pro-only">
        <label class="onepaquc-floating-pro-label"><?php echo esc_html($label); ?></label>
        <div class="onepaquc-floating-pro-control onepaqucpro-meta-builder">
            <input type="hidden" name="<?php echo esc_attr('pro_' . $name); ?>" value="" disabled />
            <div class="onepaqucpro-meta-builder__head" aria-hidden="true">
                <span></span>
                <span><?php esc_html_e('Meta', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                <span><?php esc_html_e('Mode', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                <span><?php esc_html_e('Title', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                <span></span>
            </div>
            <div class="onepaqucpro-meta-builder__rows">
                <div class="onepaqucpro-meta-builder__row">
                    <button type="button" class="onepaqucpro-meta-builder__drag" aria-label="<?php esc_attr_e('Reorder meta data', 'one-page-quick-checkout-for-woocommerce'); ?>" disabled>
                        <span class="dashicons dashicons-menu"></span>
                    </button>
                    <select disabled>
                        <option value="onepaqucpro_variations"><?php esc_html_e('Variations', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                    </select>
                    <select disabled>
                        <option value="separate"><?php esc_html_e('Separate', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                        <option value="combine"><?php esc_html_e('Combine', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                    </select>
                    <input type="text" value="" placeholder="<?php esc_attr_e('Display title', 'one-page-quick-checkout-for-woocommerce'); ?>" disabled />
                    <button type="button" class="onepaqucpro-meta-builder__remove" aria-label="<?php esc_attr_e('Remove meta data', 'one-page-quick-checkout-for-woocommerce'); ?>" disabled>
                        <span class="dashicons dashicons-no-alt"></span>
                    </button>
                </div>
            </div>
            <button type="button" class="button onepaqucpro-meta-builder__add" disabled><?php esc_html_e('Add meta data', 'one-page-quick-checkout-for-woocommerce'); ?></button>
            <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
        </div>
    </div>
    <?php
}

function onepaquc_render_floating_cart_pro_meta_picker($name, $label)
{
    ?>
    <div class="onepaquc-floating-pro-field onepaquc-floating-pro-field-stack pro-only">
        <label class="onepaquc-floating-pro-label"><?php echo esc_html($label); ?></label>
        <div class="onepaquc-floating-pro-control onepaqucpro-meta-picker">
            <input type="hidden" name="<?php echo esc_attr('pro_' . $name); ?>" value="" disabled />
            <select disabled>
                <option value="onepaqucpro_variations"><?php esc_html_e('Variations', 'one-page-quick-checkout-for-woocommerce'); ?></option>
            </select>
            <div class="onepaqucpro-meta-picker__custom">
                <input type="text" placeholder="<?php esc_attr_e('Add custom meta key', 'one-page-quick-checkout-for-woocommerce'); ?>" disabled />
                <button type="button" class="button" disabled><?php esc_html_e('Add', 'one-page-quick-checkout-for-woocommerce'); ?></button>
            </div>
            <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
        </div>
    </div>
    <?php
}

function onepaquc_render_floating_cart_pro_general_rows($onepaquc_helper)
{
    $cart_icon_options = array(
        'cart' => __('Cart', 'one-page-quick-checkout-for-woocommerce'),
        'shopping-bag' => __('Shopping Bag', 'one-page-quick-checkout-for-woocommerce'),
        'basket' => __('Basket', 'one-page-quick-checkout-for-woocommerce'),
    );
    ?>
    <tr class="pro-only">
        <?php $onepaquc_helper->sec_head('th', '', '', __('Floating Cart Icon', 'one-page-quick-checkout-for-woocommerce'), __('Choose the icon shown on the floating cart launcher.', 'one-page-quick-checkout-for-woocommerce')); ?>
        <td class="rmenu-settings-control onepaquc-floating-pro-table-control">
            <select name="pro_rmenu_floating_cart_icon" class="rmenu-select" disabled>
                <?php foreach ($cart_icon_options as $icon_key => $icon_label) : ?>
                    <option value="<?php echo esc_attr($icon_key); ?>" <?php selected($icon_key, 'cart'); ?>><?php echo esc_html($icon_label); ?></option>
                <?php endforeach; ?>
            </select>
            <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
        </td>
    </tr>

    <tr class="pro-only">
        <?php $onepaquc_helper->sec_head('th', '', '', __('Empty Cart Icon', 'one-page-quick-checkout-for-woocommerce'), __('Choose the icon shown in the empty floating cart drawer.', 'one-page-quick-checkout-for-woocommerce')); ?>
        <td class="rmenu-settings-control onepaquc-floating-pro-table-control">
            <select name="pro_rmenu_floating_cart_empty_icon" class="rmenu-select" disabled>
                <?php foreach (onepaquc_get_floating_cart_pro_empty_icon_options() as $icon_key => $icon_label) : ?>
                    <option value="<?php echo esc_attr($icon_key); ?>" <?php selected($icon_key, 'cart'); ?>><?php echo esc_html($icon_label); ?></option>
                <?php endforeach; ?>
            </select>
            <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
        </td>
    </tr>

    <tr class="pro-only">
        <?php $onepaquc_helper->sec_head('th', '', '', __('Hide If Cart Empty', 'one-page-quick-checkout-for-woocommerce'), __('Hide the floating cart button while the cart is empty.', 'one-page-quick-checkout-for-woocommerce')); ?>
        <td class="rmenu-settings-control onepaquc-floating-pro-table-control">
            <label class="switch">
                <input type="checkbox" name="pro_rmenu_hide_empty_cart_button" value="1" disabled />
                <span class="slider round"></span>
            </label>
            <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
        </td>
    </tr>
    <?php
}

function onepaquc_render_floating_cart_pro_only_sections($onepaquc_helper)
{
    $text_defaults = onepaquc_get_floating_cart_pro_text_defaults();
    ?>
    <div class="rmenu-settings-section plugincy_card onepaquc-floating-pro-section pro-only mb-4">
        <div class="onepaquc-floating-pro-heading">
            <?php $onepaquc_helper->sec_head('h2', 'plugincy_sec_head', '<span class="dashicons dashicons-screenoptions"></span>', __('Drawer Elements', 'one-page-quick-checkout-for-woocommerce'), __('Manage which elements appear inside the floating cart drawer.', 'one-page-quick-checkout-for-woocommerce')); ?>
            <?php onepaquc_render_floating_cart_pro_badge(); ?>
        </div>
        <div class="onepaqucpro-floating-elements-groups">
            <?php foreach (onepaquc_get_floating_cart_pro_element_groups() as $group_title => $group_data) : ?>
                <fieldset class="onepaqucpro-floating-elements-group">
                    <legend class="onepaqucpro-floating-elements-group__title"><?php echo esc_html($group_title); ?></legend>
                    <p class="onepaqucpro-floating-elements-group__description"><?php echo esc_html($group_data['description']); ?></p>
                    <div class="onepaquc-floating-pro-columns onepaqucpro-floating-elements-group__controls">
                        <?php foreach ($group_data['settings'] as $field_name => $field_label) : ?>
                            <div class="onepaquc-floating-pro-column">
                                <?php onepaquc_render_floating_cart_pro_switch($field_name, $field_label); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </fieldset>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="rmenu-settings-section plugincy_card onepaquc-floating-pro-section pro-only mb-4">
        <div class="onepaquc-floating-pro-heading">
            <?php $onepaquc_helper->sec_head('h2', 'plugincy_sec_head', '<span class="dashicons dashicons-index-card"></span>', __('Cart Item Data & Grouping', 'one-page-quick-checkout-for-woocommerce'), __('Control cart item meta visibility and optional item grouping.', 'one-page-quick-checkout-for-woocommerce')); ?>
            <?php onepaquc_render_floating_cart_pro_badge(); ?>
        </div>
        <div class="onepaquc-floating-pro-columns">
            <div class="onepaquc-floating-pro-column">
                <?php onepaquc_render_floating_cart_pro_switch('rmenu_floating_cart_show_variation_in_title', __('Show Variation in Product Title', 'one-page-quick-checkout-for-woocommerce')); ?>
            </div>
        </div>
        <div class="onepaquc-floating-pro-row">
            <?php onepaquc_render_floating_cart_pro_meta_rule_builder('rmenu_floating_cart_meta_include', __('Meta Include', 'one-page-quick-checkout-for-woocommerce')); ?>
        </div>
        <div class="onepaquc-floating-pro-columns">
            <div class="onepaquc-floating-pro-column">
                <?php
                onepaquc_render_floating_cart_pro_select(
                    'rmenu_floating_cart_group_by',
                    __('Group Items By', 'one-page-quick-checkout-for-woocommerce'),
                    array(
                        'category' => __('Category', 'one-page-quick-checkout-for-woocommerce'),
                        'brand' => __('Brand', 'one-page-quick-checkout-for-woocommerce'),
                        'meta' => __('Cart Item Meta', 'one-page-quick-checkout-for-woocommerce'),
                    ),
                    'category'
                );
                ?>
            </div>
            <div class="onepaquc-floating-pro-column">
                <?php onepaquc_render_floating_cart_pro_meta_picker('rmenu_floating_cart_group_meta_key', __('Group Meta Key', 'one-page-quick-checkout-for-woocommerce')); ?>
            </div>
        </div>
        <div class="onepaquc-floating-pro-row">
            <?php
            onepaquc_render_floating_cart_pro_select(
                'rmenu_floating_cart_group_icon',
                __('Group Title Icon', 'one-page-quick-checkout-for-woocommerce'),
                array(
                    'none' => __('No Icon', 'one-page-quick-checkout-for-woocommerce'),
                    'tag' => __('Tag', 'one-page-quick-checkout-for-woocommerce'),
                    'folder' => __('Folder', 'one-page-quick-checkout-for-woocommerce'),
                    'star' => __('Star', 'one-page-quick-checkout-for-woocommerce'),
                    'location' => __('Location', 'one-page-quick-checkout-for-woocommerce'),
                ),
                'tag'
            );
            ?>
        </div>
    </div>

    <div class="rmenu-settings-section plugincy_card onepaquc-floating-pro-section pro-only mb-4">
        <div class="onepaquc-floating-pro-heading">
            <?php $onepaquc_helper->sec_head('h2', 'plugincy_sec_head', '<span class="dashicons dashicons-edit"></span>', __('Drawer Text', 'one-page-quick-checkout-for-woocommerce'), __('Manage text used inside the floating cart drawer.', 'one-page-quick-checkout-for-woocommerce')); ?>
            <?php onepaquc_render_floating_cart_pro_badge(); ?>
        </div>
        <div class="onepaqucpro-floating-text-groups">
            <?php foreach (onepaquc_get_floating_cart_pro_text_groups() as $group_title => $group_data) : ?>
                <fieldset class="onepaqucpro-floating-text-group">
                    <legend class="onepaqucpro-floating-text-group__title"><?php echo esc_html($group_title); ?></legend>
                    <p class="onepaqucpro-floating-text-group__description"><?php echo esc_html($group_data['description']); ?></p>
                    <div class="plugincy_grid onepaqucpro-floating-text-group__fields">
                        <?php foreach ($group_data['settings'] as $field_name => $field_label) : ?>
                            <?php onepaquc_render_floating_cart_pro_text_field($field_name, $field_label, isset($text_defaults[$field_name]) ? $text_defaults[$field_name] : ''); ?>
                        <?php endforeach; ?>
                    </div>
                </fieldset>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="rmenu-settings-section plugincy_card onepaquc-floating-pro-section pro-only mb-4">
        <div class="onepaquc-floating-pro-heading">
            <?php $onepaquc_helper->sec_head('h2', 'plugincy_sec_head', '<span class="dashicons dashicons-megaphone"></span>', __('Drawer Notices & Feedback Text', 'one-page-quick-checkout-for-woocommerce'), __('Customize coupon, cart item, quantity, and drawer variation messages used by the floating cart.', 'one-page-quick-checkout-for-woocommerce')); ?>
            <?php onepaquc_render_floating_cart_pro_badge(); ?>
        </div>
        <div class="onepaqucpro-floating-text-groups">
            <?php foreach (onepaquc_get_floating_cart_pro_feedback_text_groups() as $group_title => $group_data) : ?>
                <fieldset class="onepaqucpro-floating-text-group">
                    <legend class="onepaqucpro-floating-text-group__title"><?php echo esc_html($group_title); ?></legend>
                    <p class="onepaqucpro-floating-text-group__description"><?php echo esc_html($group_data['description']); ?></p>
                    <div class="plugincy_grid onepaqucpro-floating-text-group__fields">
                        <?php foreach ($group_data['settings'] as $field_name => $field_label) : ?>
                            <?php onepaquc_render_floating_cart_pro_text_field($field_name, $field_label, isset($text_defaults[$field_name]) ? $text_defaults[$field_name] : ''); ?>
                        <?php endforeach; ?>
                    </div>
                </fieldset>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
}

function onepaquc_render_floating_cart_visual_editor_preview()
{
    $text_defaults = onepaquc_get_floating_cart_pro_text_defaults();
    $primary_color = get_option('rmenu_cart_bg_color', '#96588a');
    $primary_text = get_option('rmenu_cart_text_color', '#ffffff');
    $primary_hover = get_option('rmenu_cart_hover_bg', '#f8f8f8');
    $primary_hover_text = get_option('rmenu_cart_hover_text', '#000000');
    $button_radius = get_option('rmenu_cart_border_radius', '5px 0 0 5px');
    ?>
    <div class="onepaquc-floating-visual-editor-ui plugincy_card pro-only mb-4" aria-label="<?php esc_attr_e('Visual Cart Editor preview', 'one-page-quick-checkout-for-woocommerce'); ?>">
        <div class="onepaqucpro-floating-preview-toolbar">
            <div>
                <h3><?php esc_html_e('Visual Cart Editor', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
                <p><?php esc_html_e('Preview the pro visual editor for text, visibility, and element settings inside the floating cart.', 'one-page-quick-checkout-for-woocommerce'); ?></p>
            </div>
            <div class="onepaqucpro-floating-preview-modes" role="group" aria-label="<?php esc_attr_e('Preview mode', 'one-page-quick-checkout-for-woocommerce'); ?>">
                <button type="button" class="button active" disabled><?php esc_html_e('Cart', 'one-page-quick-checkout-for-woocommerce'); ?></button>
                <button type="button" class="button" disabled><?php esc_html_e('Empty', 'one-page-quick-checkout-for-woocommerce'); ?></button>
            </div>
            <?php onepaquc_render_floating_cart_pro_badge(); ?>
        </div>

        <div class="onepaqucpro-floating-preview-stage" style="--onepaqucpro-floating-primary: <?php echo esc_attr($primary_color); ?>; --onepaqucpro-floating-primary-text: <?php echo esc_attr($primary_text); ?>; --onepaqucpro-floating-primary-hover: <?php echo esc_attr($primary_hover); ?>; --onepaqucpro-floating-primary-hover-text: <?php echo esc_attr($primary_hover_text); ?>; --onepaqucpro-floating-button-radius: <?php echo esc_attr($button_radius); ?>;">
            <button type="button" class="onepaqucpro-floating-preview-button">
                <span class="dashicons dashicons-cart"></span>
                <span class="onepaqucpro-floating-preview-count">2</span>
            </button>

            <div class="onepaqucpro-floating-preview-drawer">
                <div class="onepaqucpro-floating-preview-header">
                    <h2><?php echo esc_html($text_defaults['your_cart']); ?></h2>
                    <span class="dashicons dashicons-no-alt"></span>
                </div>
                <div class="onepaqucpro-floating-preview-select">
                    <span><input type="checkbox" checked disabled> <?php echo esc_html($text_defaults['txt_Select_All']); ?></span>
                    <span>2 <?php echo esc_html($text_defaults['txt_Selected']); ?></span>
                </div>
                <div class="onepaqucpro-floating-preview-group">
                    <h4><span class="dashicons dashicons-tag" aria-hidden="true"></span><span><?php esc_html_e('Gaming Accessories', 'one-page-quick-checkout-for-woocommerce'); ?></span></h4>
                </div>
                <div class="onepaqucpro-floating-preview-item">
                    <input type="checkbox" checked disabled>
                    <button type="button" class="onepaqucpro-floating-preview-remove" disabled>&times;</button>
                    <div class="onepaqucpro-floating-preview-image"><span class="dashicons dashicons-format-image"></span></div>
                    <div class="onepaqucpro-floating-preview-item-main">
                        <div class="onepaqucpro-floating-preview-title"><?php esc_html_e('B100 Pro Wireless Gaming Headset - Black', 'one-page-quick-checkout-for-woocommerce'); ?></div>
                        <dl class="onepaqucpro-floating-preview-meta">
                            <div>
                                <dt><?php esc_html_e('Color', 'one-page-quick-checkout-for-woocommerce'); ?></dt>
                                <dd><?php esc_html_e('Black', 'one-page-quick-checkout-for-woocommerce'); ?></dd>
                            </div>
                            <div>
                                <dt><?php esc_html_e('Size', 'one-page-quick-checkout-for-woocommerce'); ?></dt>
                                <dd><?php esc_html_e('Standard', 'one-page-quick-checkout-for-woocommerce'); ?></dd>
                            </div>
                        </dl>
                        <div class="onepaqucpro-floating-preview-actions">
                            <div class="onepaqucpro-floating-preview-qty"><button type="button" disabled>-</button><span>1</span><button type="button" disabled>+</button></div>
                            <div class="onepaqucpro-floating-preview-variation-editor">
                                <button type="button" class="onepaqucpro-floating-preview-variation-toggle" aria-expanded="false" disabled>
                                    <span class="dashicons dashicons-update"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <strong>500.00&#2547;</strong>
                </div>
                <div class="onepaqucpro-floating-preview-coupon">
                    <button type="button" class="onepaqucpro-floating-preview-coupon-toggle" aria-expanded="true" disabled>
                        <span><?php echo esc_html($text_defaults['rmenu_floating_cart_coupon_title']); ?></span>
                    </button>
                    <div class="onepaqucpro-floating-preview-coupon-content" aria-hidden="false">
                        <div class="onepaqucpro-floating-preview-coupon-form">
                            <span><?php echo esc_html($text_defaults['rmenu_floating_cart_coupon_placeholder']); ?></span>
                            <button type="button" disabled><?php echo esc_html($text_defaults['rmenu_floating_cart_coupon_button_text']); ?></button>
                        </div>
                    </div>
                </div>
                <div class="onepaqucpro-floating-preview-related">
                    <h4><?php echo esc_html($text_defaults['txt_you_may_like']); ?></h4>
                    <div class="onepaqucpro-floating-preview-products">
                        <div><span class="dashicons dashicons-format-image"></span><p><?php esc_html_e('Fastest MacBook', 'one-page-quick-checkout-for-woocommerce'); ?></p><strong>650.00&#2547;</strong><button type="button" disabled><?php echo esc_html($text_defaults['rmenu_floating_cart_related_add_to_cart_text']); ?></button></div>
                        <div><span class="dashicons dashicons-format-image"></span><p><?php esc_html_e('Desktop PC Core i5', 'one-page-quick-checkout-for-woocommerce'); ?></p><strong>570.00&#2547;</strong><button type="button" disabled><?php echo esc_html($text_defaults['rmenu_floating_cart_related_add_to_cart_text']); ?></button></div>
                    </div>
                </div>
                <div class="onepaqucpro-floating-preview-shipping">
                    <h4><?php echo esc_html($text_defaults['rmenu_floating_cart_shipping_options_label']); ?></h4>
                    <label><input type="radio" checked disabled> <?php esc_html_e('Flat rate: 60.00', 'one-page-quick-checkout-for-woocommerce'); ?>&#2547;</label>
                    <label><input type="radio" disabled> <?php esc_html_e('Local pickup', 'one-page-quick-checkout-for-woocommerce'); ?></label>
                </div>
                <div class="onepaqucpro-floating-preview-summary">
                    <div class="onepaqucpro-floating-preview-summary-content">
                        <div><span><?php echo esc_html($text_defaults['txt_subtotal']); ?></span><span>1,150.00&#2547;</span></div>
                        <div><span><?php echo esc_html($text_defaults['rmenu_floating_cart_discount_label']); ?></span><span>- 50.00&#2547;</span></div>
                        <div><span><?php echo esc_html($text_defaults['rmenu_floating_cart_shipping_label']); ?></span><span>60.00&#2547;</span></div>
                        <div><span><?php echo esc_html($text_defaults['rmenu_floating_cart_tax_label']); ?></span><span>50.00&#2547;</span></div>
                        <div class="total"><span><?php echo esc_html($text_defaults['txt_total']); ?></span><strong>1,210.00&#2547;</strong></div>
                    </div>
                </div>
                <button type="button" class="onepaqucpro-floating-preview-checkout" disabled><?php echo esc_html($text_defaults['onepaquc_txt_checkout']); ?></button>
            </div>
        </div>
    </div>
    <?php
}

// Dashboard page
function onepaquc_cart_dashboard()
{
    global $onepaquc_checkoutformfields,
        $onepaquc_productpageformfields;

    $onepaquc_helper = new onepaquc_helper();
    ?>

    <div class="welcome-banner">
        <div class="welcome-title"> <?php esc_html_e('Welcome to One Page Quick Checkout for WooCommerce', 'one-page-quick-checkout-for-woocommerce'); ?> <span class="version-tag">v<?php echo esc_html(ONEPAQUC_VERSION); ?></span>
        </div>
        <p style="max-width: 70%; margin:0 auto;"> <?php esc_html_e('Thank you for installing One Page Quick Checkout for WooCommerce! Streamline your WooCommerce checkout process and boost your conversion rates with our easy-to-configure solution.', 'one-page-quick-checkout-for-woocommerce'); ?> </p>

        <div class="feature-grid">
            <div class="feature-item">
                <div class="feature-icon">
                    <svg fill="#fff" width="30" height="30" viewBox="-0.282 -0.132 0.9 0.9" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin" class="jam jam-thunder-f">
                        <path d="M.214.186h.068a.057.057 0 0 1 .051.078L.184.611A.039.039 0 0 1 .109.596v-.26L.054.334A.06.06 0 0 1 0 .279V.057A.06.06 0 0 1 .057 0h.101a.06.06 0 0 1 .057.057z" />
                    </svg>
                </div>
                <h3>
                    <?php esc_html_e('Fast Setup', 'one-page-quick-checkout-for-woocommerce'); ?>

                </h3>
                <p>
                    <?php esc_html_e('Configure your checkout in minutes with our intuitive options.', 'one-page-quick-checkout-for-woocommerce'); ?>
                </p>
            </div>
            <div class="feature-item" style="background: #ebfcf1;">
                <div class="feature-icon" style="background: #22c55e;">
                    <svg width="30" height="30" viewBox="0 0 0.75 0.75" xmlns="http://www.w3.org/2000/svg">
                        <path fill="#fff" d="M.563 0a.075.075 0 0 1 .075.075v.6A.075.075 0 0 1 .563.75H.188A.075.075 0 0 1 .113.675v-.6A.075.075 0 0 1 .188 0zm.022.577h-.42v.098a.02.02 0 0 0 .022.022h.375A.02.02 0 0 0 .584.675zM.375.6a.037.037 0 1 1 0 .075.037.037 0 0 1 0-.075M.563.053H.188a.02.02 0 0 0-.022.022v.45h.42v-.45A.02.02 0 0 0 .564.053" />
                    </svg>
                </div>
                <h3><?php esc_html_e('Mobile Friendly', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
                <p><?php esc_html_e('Responsive design works perfectly on all devices.', 'one-page-quick-checkout-for-woocommerce'); ?></p>
            </div>
            <div class="feature-item" style="background: #f8f2ff;">
                <div class="feature-icon" style="background: #a855f7;">
                    <svg width="30" height="30" viewBox="0 0 0.9 0.9" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M.075.319h.75m-.6.3H.3m.094 0h.15" stroke="#fff" stroke-width=".056" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M.241.131h.417c.134 0 .167.033.167.165v.308c0 .132-.033.165-.167.165H.241C.108.769.074.736.074.605V.297c0-.132.033-.165.167-.165" stroke="#fff" stroke-width=".056" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </div>
                <h3><?php esc_html_e('Payment Gateways', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
                <p><?php esc_html_e('Supports all major payment processors.', 'one-page-quick-checkout-for-woocommerce'); ?></p>
            </div>
        </div>

        <div class="button-row">
            <a href="https://plugincy.com/one-page-quick-checkout-for-woocommerce/" target="_blank" class="button" style="background: #ff5a36; color: #fff;">
                <span class="dashicons dashicons-star-filled" style=" margin-right: 5px; "></span>
                <?php echo esc_html__('Upgrade to Pro', 'one-page-quick-checkout-for-woocommerce'); ?>
            </a>
            <a target="_blank" href="https://demo.plugincy.com/one-page-quick-checkout-for-woocommerce/" class="button" style="background: #ed8936;color: white;"><span class="dashicons dashicons-visibility" style=" margin-right: 5px; "></span> <?php esc_html_e('View Demo', 'one-page-quick-checkout-for-woocommerce'); ?></a>
            <a target="_blank" href="https://plugincy.com/documentations/one-page-quick-checkout-for-woocommerce/" class="button"><span class="dashicons dashicons-book" style=" margin-right: 5px; "></span> <?php esc_html_e('View Documentation', 'one-page-quick-checkout-for-woocommerce'); ?></a>
            <a href="https://plugincy.com/support" target="_blank" class="button button-secondary"><span class="dashicons dashicons-sos" style=" margin-right: 5px; "></span> <?php esc_html_e('Get Support', 'one-page-quick-checkout-for-woocommerce'); ?></a>
        </div>

    </div>

    <h1 style="padding-top: 3rem;">
        <?php esc_html_e('Dashboard', 'one-page-quick-checkout-for-woocommerce'); ?>
    </h1>

    <?php
    // if (get_option('onepaquc_validity_days') === "0" || !get_option('onepaquc_api_key')) {
    //     echo "<p style='color:red;'>To use the plugin please active your API key first.</p>";
    // } else { 
    ?>
    <div class="tab-container">
        <div class="tabs">
            <div class="tab active" data-tab="4">
                <span class="dashicons dashicons-cart"></span>
                <?php esc_html_e('Direct Checkout', 'one-page-quick-checkout-for-woocommerce'); ?>
            </div>

            <div class="tab" data-tab="2">
                <span class="dashicons dashicons-admin-page"></span>
                <?php esc_html_e('One Page Checkout', 'one-page-quick-checkout-for-woocommerce'); ?>
            </div>

            <div class="tab" data-tab="9">
                <span class="dashicons dashicons-archive"></span>
                <?php esc_html_e('Floating Cart', 'one-page-quick-checkout-for-woocommerce'); ?>
            </div>

            <div class="tab" data-tab="7">
                <span class="dashicons dashicons-visibility"></span>
                <?php esc_html_e('Quick View', 'one-page-quick-checkout-for-woocommerce'); ?>
            </div>

            <div class="tab" data-tab="5">
                <span class="dashicons dashicons-star-filled"></span>
                <?php esc_html_e('Features', 'one-page-quick-checkout-for-woocommerce'); ?>
            </div>

            <div class="tab" data-tab="8">
                <span class="dashicons dashicons-plus-alt"></span>
                <?php esc_html_e('Add To Cart', 'one-page-quick-checkout-for-woocommerce'); ?>
            </div>

            <div class="tab" data-tab="1"> <span class="dashicons dashicons-forms"></span> <?php esc_html_e('Checkout Form', 'one-page-quick-checkout-for-woocommerce'); ?> </div>
            <div class="tab" data-tab="3">
                <span class="dashicons dashicons-edit"></span>
                <?php esc_html_e('Text Manage', 'one-page-quick-checkout-for-woocommerce'); ?>
            </div>

            <div class="tab" data-tab="6">
                <span class="dashicons dashicons-admin-settings"></span>
                <?php esc_html_e('Advanced Settings', 'one-page-quick-checkout-for-woocommerce'); ?>
            </div>

            <div class="tab" data-tab="100">
                <span class="dashicons dashicons-admin-network"></span>
                <?php esc_html_e('Plugin License', 'one-page-quick-checkout-for-woocommerce'); ?>
            </div>
        </div>
        <div class="tab-content" id="tab-100">
            <?php
            $license_manager = new onepaquc_License_Manager();
            $license_manager->render_license_form();
            ?>
        </div>
        <form method="post" action="options.php">
            <!-- Add nonce field for security -->
            <?php wp_nonce_field('onepaquc_cart_settings'); ?>
            <?php settings_fields('onepaquc_cart_settings'); ?>
            <div class="tab-content plugincy_card" id="tab-1" style="margin-top: 20px;">
                <?php $onepaquc_helper->sec_head('h2', 'plugincy_sec_head', '<span class="dashicons dashicons-forms"></span>', __('Checkout Form Manage', 'one-page-quick-checkout-for-woocommerce'), __('Customize the checkout form fields and headings to enhance user experience.', 'one-page-quick-checkout-for-woocommerce')); ?>
                <table class="form-table plugincy_table mb-4">
                    <tbody class="plugincy_grid">
                        <tr valign="top">
                            <th scope="row">
                                <?php esc_html_e('Remove checkout fields', 'one-page-quick-checkout-for-woocommerce'); ?>
                            </th>

                            <td>
                                <!-- multiple select options -->
                                <select class="remove_checkout_fields chosen_select select2-hidden-accessible enhanced" name="onepaquc_checkout_fields[]" id="qlwcdc_remove_checkout_fields" multiple>
                                    <?php
                                    global $onepaquc_rcheckoutformfields;
                                    $selected_fields = get_option('onepaquc_checkout_fields', []) ?? [];
                                    foreach ($onepaquc_rcheckoutformfields as $key => $field) {
                                        echo '<option value="' . esc_attr($key) . '" ' . (is_array($selected_fields) && in_array($key, $selected_fields) ? 'selected' : '') . '>' . esc_html($field['title']) . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <?php foreach (onepaquc_rmenu_fields() as $key => $field) : ?>
                            <tr valign="top">
                                <th scope="row"><?php echo esc_html($field['title']); ?></th>
                                <td>
                                    <?php $onepaquc_helper->switcher(esc_attr($key), 0); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '', __('Heading Manage', 'one-page-quick-checkout-for-woocommerce'), __('Customize the headings of the checkout form fields to enhance user experience.', 'one-page-quick-checkout-for-woocommerce')); ?>
                <table class="form-table plugincy_table">
                    <?php foreach (onepaquc_onpcheckout_heading() as $key => $field) : ?>
                        <tr valign="top">
                            <th scope="row"><?php echo esc_html($field['title']); ?></th>
                            <td>
                                <?php $onepaquc_helper->switcher(esc_attr($key), 0); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
            <div class="tab-content" id="tab-2">
                <!-- Tooltip CSS -->

                <div class="plugincy_row">
                    <div class="plugincy_col-5 plugincy_card">
                        <?php
                        $onepaquc_helper->sec_head(
                            'h2',
                            'plugincy_sec_head',
                            '<svg fill="#fff" height="16" width="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10.24 10.24" xml:space="preserve">
        <path d="M8.424 2.56H7.57v.426a.855.855 0 0 1-1.708 0V2.56H4.156v.426a.855.855 0 0 1-1.708 0V2.56h-.85c0 4.266-.426 7.68-.426 7.68h7.68c-.002 0-.428-3.414-.428-7.68m-5.12.854c.236 0 .426-.19.426-.426v-.854c0-.708.572-1.28 1.28-1.28s1.28.572 1.28 1.28v.854a.425.425 0 1 0 .852 0v-.854C7.144.956 6.188 0 5.01 0S2.876.956 2.876 2.134v.854a.43.43 0 0 0 .428.426" />
    </svg>',
                            __('One Page Checkout in Single Product', 'one-page-quick-checkout-for-woocommerce'),
                            __('Configure one-page checkout for individual product pages. Enable one-page checkout for specific products from the WooCommerce product edit screen.', 'one-page-quick-checkout-for-woocommerce')
                        );
                        ?>

                        <table class="form-table plugincy_table">
                            <tr valign="top">
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Enable One Page Checkout', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Enable one-page checkout for single product page.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td>
                                    <?php
                                    $onepaquc_helper->switcher('onpage_checkout_enable');
                                    ?>
                                </td>
                            </tr>
                            <tr valign="top">
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Enable for All Products', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Enable one-page checkout for all products without individual selection.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td>
                                    <?php $onepaquc_helper->switcher('onpage_checkout_enable_all', 0); ?>

                                </td>
                            </tr>
                            <tr valign="top">
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Form Position', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Set the priority of the one-page checkout form. The default value is 9, but not all values work with every theme. So, adjust it based on your theme.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td>
                                    <?php
                                    // Get the saved value or default to 9 if not set or empty
                                    $onpage_checkout_position = get_option("onpage_checkout_position", '');
                                    if ($onpage_checkout_position === '' || $onpage_checkout_position === false) {
                                        $onpage_checkout_position = 9;
                                    }
                                    ?>
                                    <input type="number" name="onpage_checkout_position" value="<?php echo esc_attr($onpage_checkout_position); ?>" />
                                </td>
                            </tr>
                            <tr valign="top">
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Empty Cart on Page Load', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Clear existing cart items when the one-page checkout product page loads.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td>
                                    <?php $onepaquc_helper->switcher('onpage_checkout_cart_empty', 0); ?>
                                </td>
                            </tr>

                            </td>
                            </tr>
                            <tr valign="top">
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Add to Cart on Page Load', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Automatically add the product to cart when the page loads.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td>
                                    <?php $onepaquc_helper->switcher('onpage_checkout_cart_add', 1, "If you turn it off one page checkout will not work properly."); ?>
                                </td>
                            </tr>
                            <tr valign="top">
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Hide Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Hide the regular Add to Cart button on one-page checkout product pages.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td>
                                    <?php $onepaquc_helper->switcher('onpage_checkout_hide_cart_button', 0); ?>
                                </td>
                            </tr>
                            <tr valign="top">
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Checkout Layout', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Select the layout for the one-page checkout form.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td class="pro-only">
                                    <select disabled name="onpage_checkout_layout">
                                        <option value="two_column" <?php selected(get_option('onpage_checkout_layout', 'two_column'), 'two_column'); ?>><?php esc_html_e('Two Columns (Product & Checkout)', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                        <option value="one_column" <?php selected(get_option('onpage_checkout_layout', 'two_column'), 'one_column'); ?>><?php esc_html_e('One Column (Stacked)', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                        <option value="product_first" <?php selected(get_option('onpage_checkout_layout', 'two_column'), 'product_first'); ?>><?php esc_html_e('Product First, Then Checkout', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                    </select>
                                    <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="plugincy_col-5 plugincy_card">
                        <?php
                        $onepaquc_helper->sec_head(
                            'h2',
                            'plugincy_sec_head',
                            '<span class="dashicons dashicons-forms"></span>',
                            __('Multi-product One Page Checkout', 'one-page-quick-checkout-for-woocommerce'),
                            __('Configure settings for the multi-product one-page checkout shortcode. Use: [plugincy_one_page_checkout product_ids="152,153,151,142" template="product-tabs"]', 'one-page-quick-checkout-for-woocommerce')
                        );
                        ?>

                        <table class="form-table plugincy_table">
                            <tr valign="top">
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Empty Cart on Page Load', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Clear existing cart items when a multi-product one-page checkout page loads.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td>
                                    <?php $onepaquc_helper->switcher('onpage_checkout_widget_cart_empty'); ?>
                                </td>
                            </tr>
                            <tr valign="top">
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Add to Cart on Page Load', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Automatically add the first product to cart when the page loads.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td>
                                    <?php $onepaquc_helper->switcher('onpage_checkout_widget_cart_add'); ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-content" id="tab-9">
                <div class="mb-4 onepaquc-floating-editor-intro">
                    <?php
                    $onepaquc_helper->sec_head(
                        'h2',
                        '',
                        '<span class="dashicons dashicons-cart"></span>',
                        __('Floating Cart Settings', 'one-page-quick-checkout-for-woocommerce'),
                        ''
                    );
                    ?>
                    <p class="description">
                        <?php esc_html_e(
                            'Configure the appearance and behavior of your floating cart. Enable the floating cart to provide users with quick access to their cart from any page on your site.',
                            'one-page-quick-checkout-for-woocommerce'
                        ); ?>
                    </p>
                </div>

                

                <div id="onepaquc-floating-cart-editor" class="onepaquc-floating-editor " data-floating-cart-visual-editor-enabled="1">
                <div class="onepaquc-floating-editor-left">

                <div class="plugincy_row mb-4">
                    <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                        <?php $onepaquc_helper->sec_head('h2', 'plugincy_sec_head', '<span class="dashicons dashicons-admin-generic"></span>', __('General Settings', 'one-page-quick-checkout-for-woocommerce'), __('General settings for the floating cart.', 'one-page-quick-checkout-for-woocommerce')); ?>

                        <table class="form-table plugincy_table">
                            <tr>
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Enable Sticky Cart', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Enable or disable the sticky cart functionality.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td class="rmenu-settings-control">
                                    <?php $onepaquc_helper->switcher('rmenu_enable_sticky_cart', 0); ?>
                                </td>
                            </tr>

                            <?php onepaquc_render_floating_cart_pro_general_rows($onepaquc_helper); ?>

                            <tr>
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Cart Checkout Behavior', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Choose the behavior of the cart checkout process.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td class="pro-only">
                                    <select name="rmenu_cart_checkout_behavior" class="rmenu-select">
                                        <option value="direct_checkout" <?php selected(get_option('rmenu_cart_checkout_behavior', 'direct_checkout'), 'direct_checkout'); ?>><?php esc_html_e('Direct Checkout', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                        <option disabled value="pro" <?php selected(get_option('rmenu_cart_checkout_behavior', 'side_cart'), 'pro'); ?>>
                                            <?php esc_html_e('Popup Checkout (Pro Features)', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </option>

                                    </select>
                                    <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                        <?php
                        $onepaquc_helper->sec_head(
                            'h2',
                            'plugincy_sec_head',
                            '<span class="dashicons dashicons-move"></span>',
                            __('Position Settings', 'one-page-quick-checkout-for-woocommerce'),
                            __('Configure the position of the floating cart.', 'one-page-quick-checkout-for-woocommerce')
                        );
                        ?>


                        <table class="form-table plugincy_table">
                            <tr>
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Top Position', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Set the top position of the floating cart.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>
                                <td class="rmenu-settings-control">
                                    <input type="text" name="rmenu_cart_top_position" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_cart_top_position', '50%')); ?>"  />
                                </td>
                            </tr>
                            <tr>
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    '',
                                    '',
                                    __('Left Position', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Set the left position of the floating cart.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td class="rmenu-settings-control">
                                    <input type="text" name="rmenu_cart_left_position" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_cart_left_position', '100%')); ?>"  />
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="rmenu-settings-section plugincy_card mb-4">
                    <?php
                    $onepaquc_helper->sec_head(
                        'h2',
                        'plugincy_sec_head',
                        '<span class="dashicons dashicons-admin-appearance"></span>',
                        __('Button Style Settings', 'one-page-quick-checkout-for-woocommerce'),
                        __('Configure the style of the floating cart button.', 'one-page-quick-checkout-for-woocommerce')
                    );
                    ?>


                    <div class="rmenu-settings-row rmenu-settings-row-columns">
                        <div class="rmenu-settings-column">
                            <div class="rmenu-settings-field plugincy_row items_center">
                                <label class="rmenu-settings-label">
                                    <?php esc_html_e('Background Color', 'one-page-quick-checkout-for-woocommerce'); ?>
                                </label>
                                <div class="rmenu-settings-control">
                                    <input type="color"
                                        name="rmenu_cart_bg_color"
                                        value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_cart_bg_color', '#96588a')); ?>"
                                        class="rmenu-color-picker" />
                                </div>
                            </div>

                        </div>

                        <div class="rmenu-settings-column">
                            <div class="rmenu-settings-field plugincy_row items_center">
                                <label class="rmenu-settings-label">
                                    <?php esc_html_e('Text Color', 'one-page-quick-checkout-for-woocommerce'); ?>
                                </label>
                                <div class="rmenu-settings-control">
                                    <input type="color"
                                        name="rmenu_cart_text_color"
                                        value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_cart_text_color', '#ffffff')); ?>"
                                        class="rmenu-color-picker" />
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="rmenu-settings-row rmenu-settings-row-columns">
                        <div class="rmenu-settings-column">
                            <div class="rmenu-settings-field plugincy_row items_center">
                                <label class="rmenu-settings-label">
                                    <?php esc_html_e('Hover Background', 'one-page-quick-checkout-for-woocommerce'); ?>
                                </label>
                                <div class="rmenu-settings-control">
                                    <input type="color"
                                        name="rmenu_cart_hover_bg"
                                        value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_cart_hover_bg', '#f8f8f8')); ?>"
                                        class="rmenu-color-picker" />
                                </div>
                            </div>

                        </div>

                        <div class="rmenu-settings-column">
                            <div class="rmenu-settings-field plugincy_row items_center">
                                <label class="rmenu-settings-label">
                                    <?php esc_html_e('Hover Text Color', 'one-page-quick-checkout-for-woocommerce'); ?>
                                </label>
                                <div class="rmenu-settings-control">
                                    <input type="color"
                                        name="rmenu_cart_hover_text"
                                        value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_cart_hover_text', '#000000')); ?>"
                                        class="rmenu-color-picker" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="rmenu-settings-row">
                        <div class="rmenu-settings-field plugincy_row items_center">
                            <label class="rmenu-settings-label">
                                <?php esc_html_e('Border Radius', 'one-page-quick-checkout-for-woocommerce'); ?>
                            </label>

                            <div class="rmenu-settings-control">
                                <input type="text" name="rmenu_cart_border_radius" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_cart_border_radius', '5px 0 0 5px')); ?>" placeholder="0px 0px 0px 0px" />
                            </div>
                        </div>
                    </div>
                </div>

                <?php onepaquc_render_floating_cart_pro_only_sections($onepaquc_helper); ?>

                <!-- <div class="rmenu-settings-section">
                    <div class="rmenu-settings-section-header">
                        <h3><span class="dashicons dashicons-admin-settings"></span> Additional Settings (coming soon)</h3>
                    </div>

                    <div class="rmenu-settings-row">
                        <div class="rmenu-settings-field">
                            <label class="rmenu-settings-label">Show Cart Icon</label>
                            <div class="rmenu-settings-control">
                                <label class="rmenu-toggle-switch">
                                    <input type="checkbox" name="rmenu_show_cart_icon" value="1" <?php //checked(1, get_option("rmenu_show_cart_icon", 1), true); 
                                                                                                    ?> />
                                    <span class="rmenu-toggle-slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="rmenu-settings-row">
                        <div class="rmenu-settings-field">
                            <label class="rmenu-settings-label">Show Cart Count</label>
                            <div class="rmenu-settings-control">
                                <label class="rmenu-toggle-switch">
                                    <input type="checkbox" name="rmenu_show_cart_count" value="1" <?php //checked(1, get_option("rmenu_show_cart_count", 1), true); 
                                                                                                    ?> />
                                    <span class="rmenu-toggle-slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div> -->
            </div>
                <div class="onepaqucpro-floating-editor-right" aria-label="Floating cart visual preview">
                    <?php onepaquc_render_floating_cart_visual_editor_preview(); ?>
                </div>
            </div>
            </div>

            <div class="tab-content" id="tab-3">
                <!-- <div class="d-flex space-between">
                    <h2>Checkout Form Text</h2> <button id="reset-defaults" class="button button-primary" style="background:red;">Reset Default</button>
                </div> -->
                <?php
                onepaquc_cart_text_change_form($onepaquc_checkoutformfields);

                ?>
            </div>
            <div class="tab-content active" id="tab-4">
                <div class="plugincy_nav_card mb-4">
                    <?php
                    $onepaquc_helper->sec_head(
                        'h2',
                        'plugincy_sec_head2',
                        '<svg fill="#fff" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" xml:space="preserve" width="16" height="16">
        <path d="M13.984 5.25a.73.73 0 0 0-.65-.402H9.662l1.898-3.796A.727.727 0 0 0 10.909 0H6.545a.73.73 0 0 0-.65.402L2.016 8.16a.727.727 0 0 0 .65 1.052h3.949L5.349 15.12a.726.726 0 0 0 .41.814.73.73 0 0 0 .883-.226l7.273-9.697a.73.73 0 0 0 .069-.762" />
    </svg>',
                        __('WooCommerce Direct Checkout', 'one-page-quick-checkout-for-woocommerce'),
                        '',
                        __('Enable direct checkout to allow customers to bypass the cart and proceed directly to checkout, streamlining the purchasing process.', 'one-page-quick-checkout-for-woocommerce')
                    );
                    ?>

                    <div class="rmenu-settings-tabs">
                        <ul class="rmenu-settings-tab-list">
                            <li class="rmenu-settings-tab-item active" data-tab="direct-general-settings"> <span class="dashicons dashicons-admin-generic"></span> <?php esc_html_e('General Settings', 'one-page-quick-checkout-for-woocommerce'); ?> </li>
                            <li class="rmenu-settings-tab-item" data-tab="direct-advanced"> <span class="dashicons dashicons-admin-tools"></span> <?php esc_html_e('Advanced', 'one-page-quick-checkout-for-woocommerce'); ?> </li>
                        </ul>
                    </div>
                </div>

                <div class="tab-content" id="direct-general-settings" style="padding: 0;">
                    <div class="plugincy_row mb-4">
                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<span class="dashicons dashicons-admin-generic"></span>', __('General Settings', 'one-page-quick-checkout-for-woocommerce'), ''); ?>
                            <table class="form-table plugincy_table">
                                <tr valign="top">
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Enable Direct Checkout', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Enable or disable the direct checkout functionality across your WooCommerce store.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td><?php $onepaquc_helper->switcher('rmenu_add_direct_checkout_button'); ?></td>
                                </tr>
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Button Text', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Customize the text displayed on the direct checkout button.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    </th>
                                    <td>
                                        <div class="rmenu-settings-control">
                                            <?php
                                            $direct_checkout_text = get_option('txt-direct-checkout', '');
                                            if (empty($direct_checkout_text)) {
                                                $direct_checkout_text = 'Buy Now';
                                            }
                                            ?>
                                            <input type="text" name="txt-direct-checkout" value="<?php echo esc_attr($direct_checkout_text); ?>"  />
                                        </div>
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Button Position on Archive Page', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Choose where to display the direct checkout button on product pages.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td>
                                        <div class="rmenu-settings-control">
                                            <select name="rmenu_wc_direct_checkout_position" class="rmenu-select">
                                                <option value="overlay_thumbnail" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'overlay_thumbnail'); ?>>
                                                    <?php esc_html_e('Overlay on Product Image', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="overlay_thumbnail_hover" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'overlay_thumbnail_hover'); ?>>
                                                    <?php esc_html_e('Overlay on Product Image Hover', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="after_product" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'after_product'); ?>>
                                                    <?php esc_html_e('After Product', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="after_product_title" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'after_product_title'); ?>>
                                                    <?php esc_html_e('After Product Title', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="before_product_title" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'before_product_title'); ?>>
                                                    <?php esc_html_e('Before Product Title', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="after_product_excerpt" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'after_product_excerpt'); ?>>
                                                    <?php esc_html_e('After Product Excerpt', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="after_product_rating" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'after_product_rating'); ?>>
                                                    <?php esc_html_e('After Product Rating', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="after_product_price" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'after_product_price'); ?>>
                                                    <?php esc_html_e('After Product Price', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="after_add_to_cart" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'after_add_to_cart'); ?>>
                                                    <?php esc_html_e('After Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="before_add_to_cart" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'before_add_to_cart'); ?>>
                                                    <?php esc_html_e('Before Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="bottom_add_to_cart" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'bottom_add_to_cart'); ?>>
                                                    <?php esc_html_e('Bottom of Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="replace_add_to_cart" <?php selected(get_option('rmenu_wc_direct_checkout_position', 'after_add_to_cart'), 'replace_add_to_cart'); ?>>
                                                    <?php esc_html_e('Replace Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                            </select>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Button Position on Single Page', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Choose where to display the direct checkout button on single pages.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    </th>
                                    <td>
                                        <div class="rmenu-settings-control">
                                            <select name="rmenu_wc_direct_checkout_single_position" class="rmenu-select">
                                                <option value="after_add_to_cart" <?php selected(get_option('rmenu_wc_direct_checkout_single_position', 'after_add_to_cart'), 'after_add_to_cart'); ?>>
                                                    <?php esc_html_e('After Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="before_add_to_cart" <?php selected(get_option('rmenu_wc_direct_checkout_single_position', 'after_add_to_cart'), 'before_add_to_cart'); ?>>
                                                    <?php esc_html_e('Before Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="bottom_add_to_cart" <?php selected(get_option('rmenu_wc_direct_checkout_single_position', 'after_add_to_cart'), 'bottom_add_to_cart'); ?>>
                                                    <?php esc_html_e('Bottom of Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="replace_add_to_cart" <?php selected(get_option('rmenu_wc_direct_checkout_single_position', 'after_add_to_cart'), 'replace_add_to_cart'); ?>>
                                                    <?php esc_html_e('Replace Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            </select>


                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="rmenu-settings-section plugincy_col-5 plugincy_card" id="rmenu-direct-button-display-section">
                            <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<span class="dashicons dashicons-visibility"></span>', __('Display Settings', 'one-page-quick-checkout-for-woocommerce'), ''); ?>

                            <div class="rmenu-settings-row">
                                <div class="rmenu-settings-field">
                                    <label class="rmenu-settings-label">
                                        <?php esc_html_e('Product Types', 'one-page-quick-checkout-for-woocommerce'); ?>
                                    </label>

                                    <?php
                                    $product_types_option = get_option(
                                        'rmenu_show_quick_checkout_by_types',
                                        ["simple", "variable", "external"]
                                    );
                                    $product_types_option = onepaquc_normalize_key_list($product_types_option, ["simple", "variable", "external"]);
                                    ?>

                                    <div class="rmenu-settings-control rmenu-checkbox-group">
                                        <label class="rmenu-checkbox-container">
                                            <input type="checkbox" name="rmenu_show_quick_checkout_by_types[]" value="simple" <?php checked(in_array('simple', $product_types_option)); ?> />
                                            <span class="rmenu-checkbox-label">
                                                <?php esc_html_e('Simple Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </span>
                                        </label>

                                        <label class="rmenu-checkbox-container">
                                            <input type="checkbox" name="rmenu_show_quick_checkout_by_types[]" value="variable" <?php checked(in_array('variable', $product_types_option)); ?> />
                                            <span class="rmenu-checkbox-label">
                                                <?php esc_html_e('Variable Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </span>
                                        </label>


                                        <!-- <label class="rmenu-checkbox-container pro-only">
                                        <input disabled type="checkbox" name="rmenu_show_quick_checkout_by_types[]" value="coming_grouped" <?php //checked(in_array('grouped', $product_types_option)); 
                                                                                                                                            ?> />
                                        <span class="rmenu-checkbox-label">Grouped Products (Pro Feature)</span>
                                    </label> -->

                                        <!-- <label class="rmenu-checkbox-container">
                                            <input type="checkbox" name="rmenu_show_quick_checkout_by_types[]" value="external" <?php //checked(in_array('external', $product_types_option)); 
                                                                                                                                ?> />
                                            <span class="rmenu-checkbox-label">External/Affiliate Products</span>
                                        </label> -->
                                    </div>
                                </div>
                            </div>

                            <div class="rmenu-settings-row">
                                <div class="rmenu-settings-field">
                                    <?php
                                    $product_types_option = onepaquc_normalize_key_list(
                                        get_option('rmenu_show_quick_checkout_by_page', ["single", "related", "upsells", "shop-page", "category-archives", "tag-archives", "featured-products", "on-sale", "recent", "widgets", "shortcodes"]),
                                        ["single", "related", "upsells", "shop-page", "category-archives", "tag-archives", "featured-products", "on-sale", "recent", "widgets", "shortcodes"]
                                    );
                                    ?>
                                    <div class="rmenu-settings-control rmenu-checkbox-group">
                                        <div class="rmenu-checkbox-column">
                                            <h4><?php esc_html_e('Product Pages', 'one-page-quick-checkout-for-woocommerce'); ?></h4>
                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_checkout_by_page[]" value="single" <?php checked(in_array('single', $product_types_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Single Product Pages', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_checkout_by_page[]" value="upsells" <?php checked(in_array('upsells', $product_types_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Upsells', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <!-- Example for Pro-only option -->
                                            <!--
    <label class="rmenu-checkbox-container pro-only">
        <input disabled type="checkbox" name="rmenu_show_quick_checkout_by_page[]" value="cross-sells" <?php //checked(in_array('cross-sells', $product_types_option)); 
                                                                                                        ?> />
        <span class="rmenu-checkbox-label">
            <?php esc_html_e('Cross-sells (Pro Features)', 'one-page-quick-checkout-for-woocommerce'); ?>
        </span>
    </label>
    -->
                                        </div>


                                        <div class="rmenu-checkbox-column">
                                            <h4><?php esc_html_e('Archive Pages', 'one-page-quick-checkout-for-woocommerce'); ?></h4>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_checkout_by_page[]" value="shop-page" <?php checked(in_array('shop-page', $product_types_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Main Shop Page', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_checkout_by_page[]" value="category-archives" <?php checked(in_array('category-archives', $product_types_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Product Category Archives', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_checkout_by_page[]" value="tag-archives" <?php checked(in_array('tag-archives', $product_types_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Product Tag Archives', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>
                                        </div>


                                        <div class="rmenu-checkbox-column">
                                            <h4><?php esc_html_e('Others', 'one-page-quick-checkout-for-woocommerce'); ?></h4>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_checkout_by_page[]" value="featured-products" <?php checked(in_array('featured-products', $product_types_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Featured Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_checkout_by_page[]" value="on-sale" <?php checked(in_array('on-sale', $product_types_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('On-Sale Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_checkout_by_page[]" value="recent" <?php checked(in_array('recent', $product_types_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Recent Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_checkout_by_page[]" value="shortcodes" <?php checked(in_array('shortcodes', $product_types_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Other Pages', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="plugincy_row">
                        <div class="plugincy_col-5 items_center  space_between plugincy_card">
                            <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<span class="dashicons dashicons-cart"></span>', __('Quick Checkout Behavior', 'one-page-quick-checkout-for-woocommerce'), ''); ?>

                            <table class="form-table plugincy_table">
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Checkout Method', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Choose how the quick checkout process should behave when a customer clicks the button.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    </th>
                                    <td class="rmenu-settings-control">
                                        <select name="rmenu_wc_checkout_method" class="rmenu-select" id="rmenu-checkout-method">
                                            <option value="direct_checkout" <?php selected(get_option('rmenu_wc_checkout_method', 'direct_checkout'), 'direct_checkout'); ?>>
                                                <?php esc_html_e('Redirect to Checkout', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </option>

                                            <option value="ajax_add" <?php selected(get_option('rmenu_wc_checkout_method', 'direct_checkout'), 'ajax_add'); ?>>
                                                <?php esc_html_e('AJAX Add to Cart', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </option>

                                            <?php
                                            $disable_cart_page = get_option('rmenu_disable_cart_page', '0');
                                            ?>
                                            <?php if (!$disable_cart_page) : ?>
                                                <option value="cart_redirect" <?php selected(get_option('rmenu_wc_checkout_method', 'direct_checkout'), 'cart_redirect'); ?>>
                                                    <?php esc_html_e('Redirect to Cart Page', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            <?php else : ?>
                                                <option value="cart_redirect" disabled <?php selected(get_option('rmenu_wc_checkout_method', 'direct_checkout'), 'cart_redirect'); ?>>
                                                    <?php esc_html_e('Redirect to Cart Page (Disabled)', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            <?php endif; ?>

                                            <option disabled value="popup_checkout_pro" <?php selected(get_option('rmenu_wc_checkout_method', 'direct_checkout'), 'popup_checkout_pro'); ?>>
                                                <?php esc_html_e('Popup Checkout (Pro Features)', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </option>

                                            </option>

                                            <!-- <option disabled value="advanced_pro" <?php //selected(get_option('rmenu_wc_checkout_method', 'direct_checkout'), 'advanced_pro'); 
                                                                                        ?>>
    <?php //esc_html_e('Advanced Checkout (Pro Features)', 'one-page-quick-checkout-for-woocommerce'); 
    ?>
</option> -->

                                            <option value="side_cart" <?php selected(get_option('rmenu_wc_checkout_method', 'direct_checkout'), 'side_cart'); ?>>
                                                <?php esc_html_e('Side Cart Slide-in', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </option>

                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Clear Cart Before Adding', 'one-page-quick-checkout-for-woocommerce'),
                                        __('When enabled, the cart will be emptied before adding the new product. This creates a single-product checkout experience.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td class="rmenu-settings-control">
                                        <?php $onepaquc_helper->switcher('rmenu_wc_clear_cart', 0); ?>
                                    </td>
                                </tr>

                                <!-- <div class="rmenu-settings-row">
                        <div class="rmenu-settings-field">
                            <label class="rmenu-settings-label">Single Checkout without Clear Cart</label>
                            <div class="rmenu-settings-control pro-only">
                                <label class="rmenu-toggle-switch">
                                    <input disabled type="checkbox" name="rmenu_wc_single_checkout" value="1" <?php //checked(1, get_option("rmenu_wc_single_checkout", 0), true); 
                                                                                                                ?> />
                                    <span class="rmenu-toggle-slider"></span>
                                </label>
                                <p class="rmenu-field-description">When enabled, the cart will not be emptied before adding the new product.</p>
                            </div>
                        </div>
                    </div> -->

                                <!-- <div class="rmenu-settings-row">
                        <div class="rmenu-settings-field">
                            <label class="rmenu-settings-label">One-Click Purchase</label>
                            <div class="rmenu-settings-control pro-only">
                                <label class="rmenu-toggle-switch">
                                    <input disabled type="checkbox" name="rmenu_wc_one_click_purchase" value="1" <?php //checked(1, get_option("rmenu_wc_one_click_purchase", 0), true); 
                                                                                                                    ?> />
                                    <span class="rmenu-toggle-slider"></span>
                                </label>
                                <p class="rmenu-field-description">When enabled, returning customers can bypass the checkout form and use their last saved payment method. Requires WooCommerce Payments or compatible gateway.</p>
                            </div>
                        </div>
                    </div> -->

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Show Confirmation Dialog', 'one-page-quick-checkout-for-woocommerce'),
                                        __('When enabled, customers will see a confirmation dialog before proceeding to checkout.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td class="rmenu-settings-control">
                                        <?php $onepaquc_helper->switcher('rmenu_wc_add_confirmation', 0); ?>
                                    </td>
                                </tr>
                            </table>

                        </div>
                        <div class="rmenu-settings-section direct-button-style-section plugincy_card plugincy_col-5">
                            <?php
                            $onepaquc_helper->sec_head(
                                'h3',
                                'plugincy_sec_head',
                                '<span class="dashicons dashicons-admin-appearance"></span>',
                                __('Button Style', 'one-page-quick-checkout-for-woocommerce'),
                                ''
                            );
                            ?>


                            <table class="form-table plugincy_table">
                                <tbody class="plugincy_grid">
                                    <tr style="grid-column: span 2;">
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Button Style', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>

                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_wc_checkout_style" class="rmenu-select" id="rmenu-style-select">
                                                <option value="default" <?php selected(get_option('rmenu_wc_checkout_style', 'default'), 'default'); ?>>
                                                    <?php esc_html_e('Default WooCommerce Style', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="alt" <?php selected(get_option('rmenu_wc_checkout_style', 'default'), 'alt'); ?>>
                                                    <?php esc_html_e('Alternative Style', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="custom" <?php selected(get_option('rmenu_wc_checkout_style', 'default'), 'custom'); ?>>
                                                    <?php esc_html_e('Custom Style', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Button Color', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>

                                        <td class="rmenu-settings-control">
                                            <input type="color" name="rmenu_wc_checkout_color" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_wc_checkout_color', '#000')); ?>" class="rmenu-color-picker" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Text Color', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>

                                        <td class="rmenu-settings-control">
                                            <input type="color" name="rmenu_wc_checkout_text_color" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_wc_checkout_text_color', '#ffffff')); ?>" class="rmenu-color-picker" />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Hover Background Color', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>
                                        <td class="rmenu-settings-control">
                                            <input type="color" name="rmenu_wc_checkout_hover_bg_color" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_wc_checkout_hover_bg_color', '#222222')); ?>" class="rmenu-color-picker" />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Hover Text Color', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>
                                        <td class="rmenu-settings-control">
                                            <input type="color" name="rmenu_wc_checkout_hover_text_color" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_wc_checkout_hover_text_color', '#ffffff')); ?>" class="rmenu-color-picker" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Border Radius', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>

                                        <td class="rmenu-settings-control">
                                            <input type="number" name="rmenu_wc_checkout_border_radius" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_wc_checkout_border_radius', '4')); ?>" class="small-text" min="0" max="50" step="1" />
                                            <span class="rmenu-unit">px</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Button Font Size', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>
                                        <td class="rmenu-settings-control">
                                            <input type="number" name="rmenu_wc_checkout_font_size" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_wc_checkout_font_size', '14')); ?>" class="small-text" min="10" max="30" step="1" />
                                            <span class="rmenu-unit">px</span>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Button Width', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>
                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_wc_checkout_width" class="rmenu-select">
                                                <option value="auto" <?php selected(get_option('rmenu_wc_checkout_width', 'auto'), 'auto'); ?>>
                                                    <?php esc_html_e('Auto', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="full" <?php selected(get_option('rmenu_wc_checkout_width', 'auto'), 'full'); ?>>
                                                    <?php esc_html_e('Full Width', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="custom" <?php selected(get_option('rmenu_wc_checkout_width', 'auto'), 'custom'); ?>>
                                                    <?php esc_html_e('Custom Width', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                            </select>
                                        </td>
                                    </tr>
                                    <tr id="rmenu-checkout-custom-width-row" style="<?php echo (get_option('rmenu_wc_checkout_width', 'auto') == 'custom') ? 'display:flex;' : 'display:none;'; ?>">
                                        <th class="rmenu-settings-label">Custom Width Value</th>
                                        <td class="rmenu-settings-control">
                                            <input type="number" name="rmenu_wc_checkout_custom_width" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_wc_checkout_custom_width', '220')); ?>" class="small-text" min="50" max="500" step="1" />
                                            <span class="rmenu-unit">px</span>
                                        </td>
                                    </tr>


                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Button Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>
                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_wc_checkout_icon" class="rmenu-select">
                                                <option value="none" <?php selected(get_option('rmenu_wc_checkout_icon', 'none'), 'none'); ?>>
                                                    <?php esc_html_e('No Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="cart" <?php selected(get_option('rmenu_wc_checkout_icon', 'none'), 'cart'); ?>>
                                                    <?php esc_html_e('Cart Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="checkout" <?php selected(get_option('rmenu_wc_checkout_icon', 'none'), 'checkout'); ?>>
                                                    <?php esc_html_e('Checkout Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="arrow" <?php selected(get_option('rmenu_wc_checkout_icon', 'none'), 'arrow'); ?>>
                                                    <?php esc_html_e('Arrow Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            </select>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Icon Position', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>
                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_wc_checkout_icon_position" class="rmenu-select">
                                                <option value="left" <?php selected(get_option('rmenu_wc_checkout_icon_position', 'left'), 'left'); ?>>
                                                    <?php esc_html_e('Left', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="right" <?php selected(get_option('rmenu_wc_checkout_icon_position', 'left'), 'right'); ?>>
                                                    <?php esc_html_e('Right', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="top" <?php selected(get_option('rmenu_wc_checkout_icon_position', 'left'), 'top'); ?>>
                                                    <?php esc_html_e('Top', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="bottom" <?php selected(get_option('rmenu_wc_checkout_icon_position', 'left'), 'bottom'); ?>>
                                                    <?php esc_html_e('Bottom', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            </select>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>



                <div class="tab-content" id="direct-advanced" style="padding: 0;">
                    <div class="plugincy_row">
                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php
                            $onepaquc_helper->sec_head(
                                'h3',
                                'plugincy_sec_head',
                                '<span class="dashicons dashicons-category"></span>',
                                __('Checkout in Variable Product', 'one-page-quick-checkout-for-woocommerce')
                            );
                            ?>

                            <table class="form-table plugincy_table variable-product-table">
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Show Variation Selection in Archive pages', 'one-page-quick-checkout-for-woocommerce'),
                                        __('When enabled, the variation selection will be shown on archive pages.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td class="rmenu-settings-control">
                                        <?php $onepaquc_helper->switcher('rmenu_variation_show_archive', 1); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Variation Selection Layout', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Choose variation selection Layout.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td>
                                        <div class="rmenu-settings-control">
                                            <select name="rmenu_variation_layout" class="rmenu-select">
                                                <option value="combine" <?php selected(get_option('rmenu_variation_layout', 'separate'), 'combine'); ?>>
                                                    <?php esc_html_e('Combine', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="separate" <?php selected(get_option('rmenu_variation_layout', 'separate'), 'separate'); ?>>
                                                    <?php esc_html_e('Separate', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            </select>
                                        </div>
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Show Variation Title', 'one-page-quick-checkout-for-woocommerce'),
                                        __('When enabled, the variation title will be shown on archive pages.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td class="rmenu-settings-control">
                                        <?php $onepaquc_helper->switcher('rmenu_show_variation_title', 0); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Hide Select Option Button', 'one-page-quick-checkout-for-woocommerce'),
                                        __('When enabled, the select option button will be hidden on variable product pages.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td class="rmenu-settings-control">
                                        <div class="rmenu-settings-control pro-only">
                                            <?php $onepaquc_helper->switcher('rmenu_wc_hide_select_option', 0, '', true); ?>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<span class="dashicons dashicons-admin-tools"></span>', __('Advanced Options', 'one-page-quick-checkout-for-woocommerce')); ?>

                            <!-- <div class="rmenu-settings-row">
                            <div class="rmenu-settings-field">
                                <label class="rmenu-settings-label">Mobile Optimization</label>
                                <div class="rmenu-settings-control pro-only">
                                    <label class="rmenu-toggle-switch">
                                        <input disabled type="checkbox" name="rmenu_wc_checkout_mobile_optimize" value="1" <?php //checked(1, get_option("rmenu_wc_checkout_mobile_optimize", 1), true); 
                                                                                                                            ?> />
                                        <span class="rmenu-toggle-slider"></span>
                                    </label>
                                    <p class="rmenu-field-description">When enabled, the direct checkout button will be optimized for mobile devices.</p>
                                </div>
                            </div>
                        </div> -->
                            <table class="form-table plugincy_table">
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Enable for Guest Checkout', 'one-page-quick-checkout-for-woocommerce'),
                                        __('When enabled, the direct checkout button will be available for guest users. When disabled, only logged-in users will see the button.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td class="rmenu-settings-control">
                                        <?php $onepaquc_helper->switcher('rmenu_wc_checkout_guest_enabled', 1); ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-content plugincy_card" id="tab-5" style="margin-top: 20px;">
                <?php
                $onepaquc_helper->sec_head(
                    'h2',
                    'plugincy_sec_head',
                    '<span class="dashicons dashicons-star-filled"></span>',
                    __('Manage Features', 'one-page-quick-checkout-for-woocommerce'),
                    __('Enhance your WooCommerce checkout experience with these powerful features.', 'one-page-quick-checkout-for-woocommerce')
                );
                ?>

                <table class="form-table plugincy_table">
                    <tbody style="display: grid; grid-template-columns: repeat(auto-fill, minmax(410px, 1fr));">
                        <tr valign="top">
                            <?php
                            $onepaquc_helper->sec_head(
                                'th',
                                '',
                                '',
                                __('Product Quantity Controller', 'one-page-quick-checkout-for-woocommerce'),
                                __('Enable "Product Quantity Controller" to manage product quantities in the checkout form.', 'one-page-quick-checkout-for-woocommerce')
                            );
                            ?>
                            <td>
                                <?php $onepaquc_helper->switcher('rmenu_quantity_control', 1); ?>
                            </td>
                        </tr>

                        <tr valign="top" class="pro-only top-50">
                            <?php
                            $onepaquc_helper->sec_head(
                                'th',
                                '',
                                '',
                                __('Remove Product Button', 'one-page-quick-checkout-for-woocommerce'),
                                __('Enable "Remove Product Button" to allow customers to remove products from the checkout form.', 'one-page-quick-checkout-for-woocommerce')
                            );
                            ?>
                            <td>
                                <?php $onepaquc_helper->switcher('rmenu_remove_product', 0); ?>
                            </td>
                        </tr>
                        <tr valign="top" class="pro-only">
                            <?php $onepaquc_helper->sec_head('th', '', '', __('Variation Switcher in Cart & Checkout', 'one-page-quick-checkout-for-woocommerce'), __('Enable this Pro feature to let customers switch variable-product options directly from the cart drawer, cart page, and checkout instead of adding a new variation and removing the old one manually.', 'one-page-quick-checkout-for-woocommerce')); ?>
                            <td>
                                <label class="switch">
                                    <input disabled type="checkbox" name="pro_cart_checkout_variation_switch" value="1" />
                                    <span class="slider round"></span>
                                </label>
                            </td>
                        </tr>
                        <tr valign="top">
                            <?php
                            $onepaquc_helper->sec_head(
                                'th',
                                '',
                                '',
                                __('Add Image Before Product', 'one-page-quick-checkout-for-woocommerce'),
                                __('Enable "Add Image Before Product" to display product images before their titles in the checkout form.', 'one-page-quick-checkout-for-woocommerce')
                            );
                            ?>
                            <td>
                                <?php $onepaquc_helper->switcher('rmenu_add_img_before_product', 0); ?>
                            </td>
                        </tr>

                        <tr valign="top">
                            <?php
                            $onepaquc_helper->sec_head(
                                'th',
                                '',
                                '',
                                __('At Least One Product in Cart', 'one-page-quick-checkout-for-woocommerce'),
                                __('Enable "At Least One Product in Cart" to add at least one product in the cart.', 'one-page-quick-checkout-for-woocommerce')
                            );
                            ?>
                            <td>
                                <?php $onepaquc_helper->switcher('rmenu_at_one_product_cart', 0); ?>
                            </td>
                        </tr>

                        <tr valign="top">
                            <?php
                            $onepaquc_helper->sec_head(
                                'th',
                                '',
                                '',
                                __('Disable Cart Page', 'one-page-quick-checkout-for-woocommerce'),
                                __('Enable "Disable Cart Page" to remove the cart page from your WooCommerce store. This will redirect customers directly to the checkout page.', 'one-page-quick-checkout-for-woocommerce')
                            );
                            ?>
                            <td>
                                <?php $onepaquc_helper->switcher('rmenu_disable_cart_page', 0); ?>
                            </td>
                        </tr>
                        <!-- <tr valign="top" class="pro-only top-50">
                        <th scope="row">Express Checkout Options</th>
                        <td>
                            <label class="switch">
                                <input disabled type="checkbox" name="rmenu_express_checkout" value="1" <?php //checked(1, get_option("rmenu_express_checkout", 0), true); 
                                                                                                        ?> />
                                <span class="slider round"></span>
                            </label>
                            <span class="tooltip">
                                <span class="question-mark">?</span>
                                <span class="tooltip-text">Enable "Express Checkout Options" to allow customers to use express checkout methods like PayPal, Stripe, etc.</span>
                            </span>
                        </td>
                    </tr> -->
                        <!-- <tr valign="top" class="pro-only top-50">
                        <th scope="row">Address Auto-Complete</th>
                        <td>
                            <label class="switch">
                                <input disabled type="checkbox" name="rmenu_address_auto_complete" value="1" <?php //checked(1, get_option("rmenu_address_auto_complete", 0), true); 
                                                                                                                ?> />
                                <span class="slider round"></span>
                            </label>
                            <span class="tooltip">
                                <span class="question-mark">?</span>
                                <span class="tooltip-text">Enable "Address Auto-Complete" to automatically fill in the address fields based on the customer's input.</span>
                            </span>
                        </td>
                    </tr> -->
                        <!-- <tr valign="top" class="pro-only top-50">
                        <th scope="row">Multi-Step Checkout </th>
                        <td>
                            <label class="switch">
                                <input disabled type="checkbox" name="rmenu_multi_step_checkout" value="1" <?php //checked(1, get_option("rmenu_multi_step_checkout", 0), true); 
                                                                                                            ?> />
                                <span class="slider round"></span>
                            </label>
                            <span class="tooltip">
                                <span class="question-mark">?</span>
                                <span class="tooltip-text">Enable "Multi-Step Checkout " to split the checkout process into multiple steps for a better user experience.</span>
                            </span>
                        </td>
                    </tr> -->
                        <tr valign="top" class="pro-only top-50">
                            <?php
                            $onepaquc_helper->sec_head(
                                'th',
                                '',
                                '',
                                __('Force Login Before Checkout', 'one-page-quick-checkout-for-woocommerce'),
                                __('Enable "Force Login Before Checkout" to require customers to log in before they can access the checkout page.', 'one-page-quick-checkout-for-woocommerce')
                            );
                            ?>
                            <td>
                                <?php $onepaquc_helper->switcher('rmenu_force_login', 0); ?>
                            </td>
                        </tr>

                        <tr valign="top">
                            <?php
                            $onepaquc_helper->sec_head(
                                'th',
                                '',
                                '',
                                __('Link Product Name in Checkout Page', 'one-page-quick-checkout-for-woocommerce'),
                                __('Enable "Link Product Name in Checkout Page" to make the product names clickable, redirecting customers to the product page.', 'one-page-quick-checkout-for-woocommerce')
                            );
                            ?>
                            <td>
                                <?php $onepaquc_helper->switcher('rmenu_link_product', 1); ?>
                            </td>
                        </tr>

                        <!-- <tr valign="top" class="pro-only top-50">
                        <th scope="row">Enable Captcha on Checkout Page</th>
                        <td>
                            <label class="switch">
                                <input disabled type="checkbox" name="rmenu_enable_captcha" value="1" <?php //checked(1, get_option("rmenu_enable_captcha", 0), true); 
                                                                                                        ?> />
                                <span class="slider round"></span>
                            </label>
                            <span class="tooltip">
                                <span class="question-mark">?</span>
                                <span class="tooltip-text">Enable "Enable Captcha on Checkout Page" to add a captcha verification step to the checkout process, helping to prevent spam and automated submissions.</span>
                            </span>
                        </td>
                    </tr> -->
                    </tbody>
                </table>
            </div>
            <div class="tab-content plugincy_card" id="tab-6" style="margin-top: 20px;">
                <?php onepaquc_trust_badges_settings_content(); ?>
                <table style="padding-top: 1rem;">
                    <tr valign="top" style="display: flex; gap: 51px;">
                        <?php
                        $onepaquc_helper->sec_head(
                            'th',
                            '',
                            '',
                            __('Contribute to Plugincy', 'one-page-quick-checkout-for-woocommerce'),
                            __('We collect non-sensitive technical details from your website, like the PHP version and features usage, to help us troubleshoot issues faster, make informed development decisions, and build features that truly benefit you. <a href="https://plugincy.com/usage-tracking/" target="_blank" style="color:#fff;">Learn more…</a>', 'one-page-quick-checkout-for-woocommerce')
                        );
                        ?>

                        <td>
                            <?php $onepaquc_helper->switcher('rmenu_allow_analytics', 1); ?>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="tab-content" id="tab-7">
                <div class="plugincy_nav_card mb-4">
                    <?php
                    $onepaquc_helper->sec_head(
                        'h2',
                        'plugincy_sec_head2',
                        '<span class="dashicons dashicons-visibility"></span>',
                        __('WooCommerce Quick View', 'one-page-quick-checkout-for-woocommerce'),
                        '',
                        __('Manage the quick view settings for your WooCommerce products.', 'one-page-quick-checkout-for-woocommerce')
                    );
                    ?>

                    <div class="rmenu-settings-tabs">
                        <ul class="rmenu-settings-tab-list">
                            <li class="rmenu-settings-tab-item active" data-tab="quick-general-settings">
                                <span class="dashicons dashicons-admin-generic"></span>
                                <?php esc_html_e('General Settings', 'one-page-quick-checkout-for-woocommerce'); ?>
                            </li>
                            <li class="rmenu-settings-tab-item" data-tab="quick-popup">
                                <span class="dashicons dashicons-admin-comments"></span>
                                <?php esc_html_e('Popup Manage', 'one-page-quick-checkout-for-woocommerce'); ?>
                            </li>
                            <li class="rmenu-settings-tab-item" data-tab="quick-advanced">
                                <span class="dashicons dashicons-admin-tools"></span>
                                <?php esc_html_e('Advanced', 'one-page-quick-checkout-for-woocommerce'); ?>
                            </li>
                        </ul>
                    </div>

                </div>
                <div class="tab-content" id="quick-general-settings" style="padding: 0;">
                    <div class="plugincy_row">
                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php
                            $onepaquc_helper->sec_head(
                                'h3',
                                'plugincy_sec_head',
                                '<span class="dashicons dashicons-admin-generic"></span>',
                                __('General Settings', 'one-page-quick-checkout-for-woocommerce'),
                                ''
                            );
                            ?>

                            <table class="form-table plugincy_table">
                                <tr id="rmenu-quick-view-enable-field">
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Enable Quick View', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Enable or disable the quick view functionality across your WooCommerce store.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td class="rmenu-settings-control">
                                        <?php $onepaquc_helper->switcher('rmenu_enable_quick_view', 0); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Button Text', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Customize the text displayed on the quick view button.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td class="rmenu-settings-control">
                                        <?php
                                        $quick_view_button_text = get_option('rmenu_quick_view_button_text', '');
                                        if (empty($quick_view_button_text)) {
                                            $quick_view_button_text = 'Quick View';
                                        }
                                        ?>
                                        <input type="text" name="rmenu_quick_view_button_text" value="<?php echo esc_attr($quick_view_button_text); ?>"  />
                                    </td>
                                </tr>
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Button Position', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Choose where to display the quick view button on product listings.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td class="rmenu-settings-control">
                                        <select name="rmenu_quick_view_button_position" class="rmenu-select">
                                            <option value="after_image" <?php selected(get_option('rmenu_quick_view_button_position', 'image_overlay'), 'after_image'); ?>>
                                                <?php esc_html_e('After Product Image', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </option>

                                            <!-- <option disabled value="before_title" <?php //selected(get_option('rmenu_quick_view_button_position', 'image_overlay'), 'before_title'); 
                                                                                        ?>>Before Product Title (Pro Features)</option>
                                        <option disabled value="after_title" <?php //selected(get_option('rmenu_quick_view_button_position', 'image_overlay'), 'after_title'); 
                                                                                ?>>After Product Title (Pro Features)</option>
                                        <option disabled value="before_price" <?php //selected(get_option('rmenu_quick_view_button_position', 'image_overlay'), 'before_price'); 
                                                                                ?>>Before Product Price (Pro Features)</option>
                                        <option disabled value="after_price" <?php //selected(get_option('rmenu_quick_view_button_position', 'image_overlay'), 'after_price'); 
                                                                                ?>>After Product Price (Pro Features)</option>
                                        <option disabled value="before_add_to_cart" <?php //selected(get_option('rmenu_quick_view_button_position', 'image_overlay'), 'before_add_to_cart'); 
                                                                                    ?>>Before Add to Cart Button (Pro Features)</option> -->
                                            <option value="after_add_to_cart"
                                                <?php selected(get_option('rmenu_quick_view_button_position', 'image_overlay'), 'after_add_to_cart'); ?>>
                                                <?php esc_html_e('After Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </option>

                                            <option value="image_overlay"
                                                <?php selected(get_option('rmenu_quick_view_button_position', 'image_overlay'), 'image_overlay'); ?>>
                                                <?php esc_html_e('Overlay on Product Image', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </option>

                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Display Type', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Choose how the quick view trigger should appear to customers.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>

                                    <td class="rmenu-settings-control">
                                        <select name="rmenu_quick_view_display_type" class="rmenu-select">
                                            <option value="button" <?php selected(get_option('rmenu_quick_view_display_type', 'icon'), 'button'); ?>>
                                                <?php esc_html_e('Button', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </option>

                                            <option value="icon" <?php selected(get_option('rmenu_quick_view_display_type', 'icon'), 'icon'); ?>>
                                                <?php esc_html_e('Icon Only', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </option>


                                            <option value="text_icon" <?php selected(get_option('rmenu_quick_view_display_type', 'icon'), 'text_icon'); ?>>
                                                <?php esc_html_e('Text with Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </option>

                                            <!-- <option value="hover_icon" <?php //selected(get_option('rmenu_quick_view_display_type', 'icon'), 'hover_icon'); 
                                                                            ?>>Hover Icon</option> -->
                                        </select>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <div class="rmenu-settings-section quick-view-button-style plugincy_card plugincy_col-5">
                            <?php
                            $onepaquc_helper->sec_head(
                                'h3',
                                'plugincy_sec_head',
                                '<span class="dashicons dashicons-admin-appearance"></span>',
                                __('Button Style', 'one-page-quick-checkout-for-woocommerce'),
                                ''
                            );
                            ?>


                            <table class="form-table plugincy_table">
                                <tbody class="plugincy_grid">
                                    <tr style="grid-column: span 2;">
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            '',
                                            '',
                                            __('Button Style', 'one-page-quick-checkout-for-woocommerce'),
                                            ''
                                        );
                                        ?>

                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_quick_view_button_style" class="rmenu-select" id="rmenu-qv-style-select">
                                                <option value="default" <?php selected(get_option('rmenu_quick_view_button_style', 'default'), 'default'); ?>>
                                                    <?php esc_html_e('Default WooCommerce Style', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="alt" <?php selected(get_option('rmenu_quick_view_button_style', 'default'), 'alt'); ?>>
                                                    <?php esc_html_e('Alternative Style', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="custom" <?php selected(get_option('rmenu_quick_view_button_style', 'default'), 'custom'); ?>>
                                                    <?php esc_html_e('Custom Style', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                            </select>
                                        </td>
                                    </tr>

                                    <tr>
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            '',
                                            '',
                                            __('Button Color', 'one-page-quick-checkout-for-woocommerce'),
                                            ''
                                        );
                                        ?>

                                        <td class="rmenu-settings-control">
                                            <input type="color" name="rmenu_quick_view_button_color" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_quick_view_button_color', '#000')); ?>" class="rmenu-color-picker" />
                                        </td>
                                    </tr>

                                    <tr>
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            '',
                                            '',
                                            __('Text Color', 'one-page-quick-checkout-for-woocommerce'),
                                            ''
                                        );
                                        ?>

                                        <td class="rmenu-settings-control">
                                            <input type="color" name="rmenu_quick_view_text_color" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_quick_view_text_color', '#ffffff')); ?>" class="rmenu-color-picker" />
                                        </td>
                                    </tr>

                                    <tr>
                                        <?php $onepaquc_helper->sec_head('th', '', '', __('Button Icon', 'one-page-quick-checkout-for-woocommerce'), ''); ?>
                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_quick_view_button_icon" class="rmenu-select">
                                                <option value="none" <?php selected(get_option('rmenu_quick_view_button_icon', 'eye'), 'none'); ?>><?php esc_html_e('No Icon', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                                <option value="eye" <?php selected(get_option('rmenu_quick_view_button_icon', 'eye'), 'eye'); ?>><?php esc_html_e('Eye Icon', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                                <option value="search" <?php selected(get_option('rmenu_quick_view_button_icon', 'eye'), 'search'); ?>><?php esc_html_e('Search Icon', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                                <option value="zoom" <?php selected(get_option('rmenu_quick_view_button_icon', 'eye'), 'zoom'); ?>><?php esc_html_e('Zoom Icon', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                                <option value="preview" <?php selected(get_option('rmenu_quick_view_button_icon', 'eye'), 'preview'); ?>><?php esc_html_e('Preview Icon', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                            </select>
                                        </td>
                                    </tr>

                                    <tr>
                                        <?php $onepaquc_helper->sec_head('th', '', '', __('Icon Position', 'one-page-quick-checkout-for-woocommerce'), ''); ?>
                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_quick_view_icon_position" class="rmenu-select">
                                                <option value="left" <?php selected(get_option('rmenu_quick_view_icon_position', 'left'), 'left'); ?>><?php esc_html_e('Left', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                                <option value="right" <?php selected(get_option('rmenu_quick_view_icon_position', 'left'), 'right'); ?>><?php esc_html_e('Right', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                            </select>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="tab-content" id="quick-popup" style="padding: 0;">
                    <div class="plugincy_row mb-4">
                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php
                            $onepaquc_helper->sec_head(
                                'h3',
                                'plugincy_sec_head',
                                '<span class="dashicons dashicons-visibility"></span>',
                                __('Quick View Content', 'one-page-quick-checkout-for-woocommerce'),
                                ''
                            );
                            ?>

                            <div class="rmenu-settings-row" id="rmenu-quick-view-content-elements">
                                <div class="rmenu-settings-field">
                                    <label class="rmenu-settings-label">
                                        <?php esc_html_e('Content Elements', 'one-page-quick-checkout-for-woocommerce'); ?>
                                    </label>

                                    <?php
                                    $content_elements_option = onepaquc_normalize_key_list(
                                        get_option('rmenu_quick_view_content_elements', ['image', 'title', 'rating', 'price', 'excerpt', 'add_to_cart', 'meta']),
                                        ['image', 'title', 'rating', 'price', 'excerpt', 'add_to_cart', 'meta']
                                    );
                                    ?>
                                    <div class="rmenu-settings-control rmenu-checkbox-group">
                                        <div class="rmenu-checkbox-column">
                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_quick_view_content_elements[]" value="image" <?php checked(in_array('image', $content_elements_option)); ?> />
                                                <span class="rmenu-checkbox-label"><?php esc_html_e('Product Image', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_quick_view_content_elements[]" value="gallery" <?php checked(in_array('gallery', $content_elements_option)); ?> />
                                                <span class="rmenu-checkbox-label"><?php esc_html_e('Product Gallery', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_quick_view_content_elements[]" value="title" <?php checked(in_array('title', $content_elements_option)); ?> />
                                                <span class="rmenu-checkbox-label"><?php esc_html_e('Product Title', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_quick_view_content_elements[]" value="rating" <?php checked(in_array('rating', $content_elements_option)); ?> />
                                                <span class="rmenu-checkbox-label"><?php esc_html_e('Product Rating', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                            </label>
                                        </div>


                                        <div class="rmenu-checkbox-column">
                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_quick_view_content_elements[]" value="price" <?php checked(in_array('price', $content_elements_option)); ?> />
                                                <span class="rmenu-checkbox-label"><?php esc_html_e('Product Price', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_quick_view_content_elements[]" value="excerpt" <?php checked(in_array('excerpt', $content_elements_option)); ?> />
                                                <span class="rmenu-checkbox-label"><?php esc_html_e('Short Description', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_quick_view_content_elements[]" value="add_to_cart" <?php checked(in_array('add_to_cart', $content_elements_option)); ?> />
                                                <span class="rmenu-checkbox-label"><?php esc_html_e('Add to Cart Button', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                            </label>


                                            <!-- <label class="rmenu-checkbox-container">
                                        <input type="checkbox" name="rmenu_quick_view_content_elements[]" value="quantity" <?php //checked(in_array('quantity', $content_elements_option)); 
                                                                                                                            ?> />
                                        <span class="rmenu-checkbox-label">Quantity Selector</span>
                                    </label> -->
                                        </div>

                                        <div class="rmenu-checkbox-column">
                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_quick_view_content_elements[]" value="meta" <?php checked(in_array('meta', $content_elements_option)); ?> />
                                                <span class="rmenu-checkbox-label"><?php esc_html_e('Product Meta', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                            </label>

                                            <label class="rmenu-checkbox-container pro-only">
                                                <input disabled type="checkbox" name="rmenu_quick_view_content_elements[]" value="sharing" <?php checked(in_array('sharing', $content_elements_option)); ?> />
                                                <span class="rmenu-checkbox-label"><?php esc_html_e('Social Sharing', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" id="view_details_checkbox" name="rmenu_quick_view_content_elements[]" value="view_details" <?php checked(in_array('view_details', $content_elements_option)); ?> />
                                                <span class="rmenu-checkbox-label"><?php esc_html_e('View Details Link', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                            </label>


                                            <!-- <label class="rmenu-checkbox-container pro-only">
                                        <input disabled type="checkbox" name="rmenu_quick_view_content_elements[]" value="attributes" <?php //checked(in_array('attributes', $content_elements_option)); 
                                                                                                                                        ?> />
                                        <span class="rmenu-checkbox-label">Product Attributes</span>
                                    </label> -->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <table class="form-table plugincy_table">
                                <tbody class="plugincy_grid">
                                    <tr>
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            'rmenu-settings-label',
                                            '',
                                            __('Modal Size', 'one-page-quick-checkout-for-woocommerce'),
                                            __('Choose the size of the quick view modal popup.', 'one-page-quick-checkout-for-woocommerce')
                                        );
                                        ?>

                                        <td class="rmenu-settings-control pro-only">
                                            <select disabled name="rmenu_quick_view_modal_size" class="rmenu-select">
                                                <option value="small" <?php selected(get_option('rmenu_quick_view_modal_size', 'medium'), 'small'); ?>>
                                                    <?php esc_html_e('Small', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="medium" <?php selected(get_option('rmenu_quick_view_modal_size', 'medium'), 'medium'); ?>>
                                                    <?php esc_html_e('Medium', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="large" <?php selected(get_option('rmenu_quick_view_modal_size', 'medium'), 'large'); ?>>
                                                    <?php esc_html_e('Large', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="full" <?php selected(get_option('rmenu_quick_view_modal_size', 'medium'), 'full'); ?>>
                                                    <?php esc_html_e('Full Width', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="custom" <?php selected(get_option('rmenu_quick_view_modal_size', 'medium'), 'custom'); ?>>
                                                    <?php esc_html_e('Custom', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            </select>
                                        </td>
                                    </tr>


                                    <tr id="rmenu-custom-size-row" style="<?php echo (get_option('rmenu_quick_view_modal_size', 'medium') == 'custom') ? 'display:flex;' : 'display:none;'; ?>">
                                        <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', 'Custom Width', 'Custom width in pixels (e.g., 800).'); ?>
                                        <td class="rmenu-settings-control pro-only">
                                            <input disabled type="text" name="rmenu_quick_view_custom_width" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_quick_view_custom_width', '800')); ?>"  />
                                        </td>
                                    </tr>
                                    <tr id="rmenu-custom-size-row" style="<?php echo (get_option('rmenu_quick_view_modal_size', 'medium') == 'custom') ? 'display:flex;' : 'display:none;'; ?>">
                                        <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', 'Custom Height', 'Custom height in pixels (e.g., 600) or \'auto\'.'); ?>
                                        <td class="rmenu-settings-control pro-only">
                                            <input disabled type="text" name="rmenu_quick_view_custom_height" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_quick_view_custom_height', '600')); ?>"  />
                                        </td>
                                    </tr>

                                    <tr>
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            'rmenu-settings-label',
                                            '',
                                            __('Loading Effect', 'one-page-quick-checkout-for-woocommerce'),
                                            __('Choose the animation effect when opening the quick view modal.', 'one-page-quick-checkout-for-woocommerce')
                                        );
                                        ?>
                                        <td class="rmenu-settings-control pro-only">
                                            <select disabled name="rmenu_quick_view_loading_effect" class="rmenu-select">
                                                <option value="fade" <?php selected(get_option('rmenu_quick_view_loading_effect', 'fade'), 'fade'); ?>>
                                                    <?php esc_html_e('Fade', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="slide" <?php selected(get_option('rmenu_quick_view_loading_effect', 'fade'), 'slide'); ?>>
                                                    <?php esc_html_e('Slide', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="zoom" <?php selected(get_option('rmenu_quick_view_loading_effect', 'fade'), 'zoom'); ?>>
                                                    <?php esc_html_e('Zoom', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="none" <?php selected(get_option('rmenu_quick_view_loading_effect', 'fade'), 'none'); ?>>
                                                    <?php esc_html_e('None', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            </select>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php
                            $onepaquc_helper->sec_head(
                                'h3',
                                'plugincy_sec_head',
                                '<span class="dashicons dashicons-layout"></span>',
                                __('Display Settings', 'one-page-quick-checkout-for-woocommerce'),
                                ''
                            );
                            ?>

                            <div class="rmenu-settings-row">
                                <div class="rmenu-settings-field">
                                    <label class="rmenu-settings-label">
                                        <?php esc_html_e('Product Types', 'one-page-quick-checkout-for-woocommerce'); ?>
                                    </label>

                                    <?php
                                    $product_types_option = onepaquc_normalize_key_list(
                                        get_option('rmenu_show_quick_view_by_types', ['simple', 'variable', "grouped", "external"]),
                                        ['simple', 'variable', "grouped", "external"]
                                    );
                                    ?>
                                    <div class="rmenu-settings-control rmenu-checkbox-group">
                                        <label class="rmenu-checkbox-container">
                                            <input type="checkbox" name="rmenu_show_quick_view_by_types[]" value="simple" <?php checked(in_array('simple', $product_types_option)); ?> />
                                            <span class="rmenu-checkbox-label">
                                                <?php esc_html_e('Simple Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </span>
                                        </label>

                                        <label class="rmenu-checkbox-container">
                                            <input type="checkbox" name="rmenu_show_quick_view_by_types[]" value="variable" <?php checked(in_array('variable', $product_types_option)); ?> />
                                            <span class="rmenu-checkbox-label">
                                                <?php esc_html_e('Variable Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </span>
                                        </label>

                                        <label class="rmenu-checkbox-container">
                                            <input type="checkbox" name="rmenu_show_quick_view_by_types[]" value="grouped" <?php checked(in_array('grouped', $product_types_option)); ?> />
                                            <span class="rmenu-checkbox-label">
                                                <?php esc_html_e('Grouped Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </span>
                                        </label>

                                        <label class="rmenu-checkbox-container">
                                            <input type="checkbox" name="rmenu_show_quick_view_by_types[]" value="external" <?php checked(in_array('external', $product_types_option)); ?> />
                                            <span class="rmenu-checkbox-label">
                                                <?php esc_html_e('External/Affiliate Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                            </span>
                                        </label>

                                    </div>
                                </div>
                            </div>

                            <div class="rmenu-settings-row">
                                <div class="rmenu-settings-field">
                                    <?php
                                    $product_pages_option = onepaquc_normalize_key_list(
                                        get_option('rmenu_show_quick_view_by_page', ['shop-page', 'category-archives', 'tag-archives', 'brand-archives', 'attribute-archives', 'single', 'search', 'featured-products', 'on-sale', 'recent', 'widgets', 'shortcodes']),
                                        ['shop-page', 'category-archives', 'tag-archives', 'brand-archives', 'attribute-archives', 'single', 'search', 'featured-products', 'on-sale', 'recent', 'widgets', 'shortcodes']
                                    );
                                    ?>
                                    <div class="rmenu-settings-control rmenu-checkbox-group">
                                        <div class="rmenu-checkbox-column">
                                            <h4><?php esc_html_e('Archive Pages', 'one-page-quick-checkout-for-woocommerce'); ?></h4>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="shop-page" <?php checked(in_array('shop-page', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Main Shop Page', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="category-archives" <?php checked(in_array('category-archives', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Product Category Archives', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="tag-archives" <?php checked(in_array('tag-archives', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Product Tag Archives', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="brand-archives" <?php checked(in_array('brand-archives', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Product Brand Archives', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="attribute-archives" <?php checked(in_array('attribute-archives', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Product Attribute Archives', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>
                                        </div>


                                        <div class="rmenu-checkbox-column">
                                            <h4><?php esc_html_e('Other Pages', 'one-page-quick-checkout-for-woocommerce'); ?></h4>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="single" <?php checked(in_array('single', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Single Product Page', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="search" <?php checked(in_array('search', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Search Results', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="featured-products" <?php checked(in_array('featured-products', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Featured Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="on-sale" <?php checked(in_array('on-sale', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('On-Sale Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="recent" <?php checked(in_array('recent', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Recent Products', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>
                                        </div>


                                        <div class="rmenu-checkbox-column">
                                            <h4><?php esc_html_e('Widgets & Shortcodes', 'one-page-quick-checkout-for-woocommerce'); ?></h4>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="widgets" <?php checked(in_array('widgets', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Widgets', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>

                                            <label class="rmenu-checkbox-container">
                                                <input type="checkbox" name="rmenu_show_quick_view_by_page[]" value="shortcodes" <?php checked(in_array('shortcodes', $product_pages_option)); ?> />
                                                <span class="rmenu-checkbox-label">
                                                    <?php esc_html_e('Shortcodes', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </span>
                                            </label>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rmenu-settings-section plugincy_card">
                        <?php
                        $onepaquc_helper->sec_head(
                            'h3',
                            'plugincy_sec_head',
                            '<span class="dashicons dashicons-translation"></span>',
                            __('Translations', 'one-page-quick-checkout-for-woocommerce'),
                            ''
                        );
                        ?>

                        <table class="form-table plugincy_table">
                            <tr>
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    'rmenu-settings-label',
                                    '',
                                    __('"View Full Details" Button Text', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Change the text shown on the "View Full Details" button inside the Quick View popup.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>

                                <td class="rmenu-settings-control">
                                    <?php
                                    $details_text = get_option('rmenu_quick_view_details_text', '');
                                    if (empty($details_text)) {
                                        $details_text = 'View Full Details';
                                    }
                                    ?>
                                    <input type="text" id="view_details_text" name="rmenu_quick_view_details_text" value="<?php echo esc_attr($details_text); ?>"  />
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="tab-content" id="quick-advanced" style="padding: 0;">
                    <div class="plugincy_row mb-4">
                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php
                            $onepaquc_helper->sec_head(
                                'h3',
                                'plugincy_sec_head',
                                '<span class="dashicons dashicons-admin-tools"></span>',
                                __('Advanced Options', 'one-page-quick-checkout-for-woocommerce'),
                                ''
                            );
                            ?>


                            <table class="form-table plugincy_table">
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Mobile Optimization', 'one-page-quick-checkout-for-woocommerce'),
                                        __('When enabled, the quick view functionality will be optimized for mobile devices.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <?php $onepaquc_helper->switcher('rmenu_quick_view_mobile_optimize', 1); ?>
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Close on Add to Cart', 'one-page-quick-checkout-for-woocommerce'),
                                        __('When enabled, the quick view popup will automatically close after adding a product to cart.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <?php $onepaquc_helper->switcher('rmenu_quick_view_close_on_add', 0); ?>
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Keyboard Navigation', 'one-page-quick-checkout-for-woocommerce'),
                                        __('When enabled, customers can use keyboard arrows to navigate between products in quick view and ESC to close.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control">
                                        <?php $onepaquc_helper->switcher('rmenu_quick_view_keyboard_nav', 1); ?>
                                    </td>
                                </tr>
                            </table>

                        </div>
                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php
                            $onepaquc_helper->sec_head(
                                'h3',
                                'plugincy_sec_head',
                                '<span class="dashicons dashicons-analytics"></span>',
                                __('Analytics Integration', 'one-page-quick-checkout-for-woocommerce'),
                                ''
                            );
                            ?>


                            <table class="form-table plugincy_table">
                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Track Quick View Events', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Track when customers use quick view in Google Analytics or other analytics tools.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <?php $onepaquc_helper->switcher('rmenu_quick_view_track_events', 0); ?>
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Event Category', 'one-page-quick-checkout-for-woocommerce'),
                                        __('The event category name used for analytics tracking.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <input disabled type="text" name="rmenu_quick_view_event_category" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_quick_view_event_category', 'one-page-quick-checkout-for-woocommerce')); ?>"  />
                                        <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Event Action', 'one-page-quick-checkout-for-woocommerce'),
                                        __('The event action name used for analytics tracking.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <input disabled type="text" name="rmenu_quick_view_event_action" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_quick_view_event_action', 'Quick View')); ?>"  />
                                        <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                    </td>
                                </tr>
                            </table>

                        </div>
                    </div>

                    <div class="rmenu-settings-section plugincy_card">
                        <?php
                        $onepaquc_helper->sec_head(
                            'h3',
                            'plugincy_sec_head',
                            '<span class="dashicons dashicons-admin-generic"></span>',
                            __('Compatibility Settings', 'one-page-quick-checkout-for-woocommerce')
                        );
                        ?>

                        <table class="form-table plugincy_table">
                            <tr>
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    'rmenu-settings-label',
                                    '',
                                    __('Load Scripts On', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Control where quick view scripts are loaded to improve compatibility and performance.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>
                                <td class="rmenu-settings-control pro-only">
                                    <select disabled name="rmenu_quick_view_load_scripts" class="rmenu-select">
                                        <option value="all" <?php selected(get_option('rmenu_quick_view_load_scripts', 'wc-only'), 'all'); ?>>
                                            <?php esc_html_e('All Pages', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </option>
                                        <option value="wc-only" <?php selected(get_option('rmenu_quick_view_load_scripts', 'wc-only'), 'wc-only'); ?>>
                                            <?php esc_html_e('WooCommerce Pages Only', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </option>
                                        <option value="specific" <?php selected(get_option('rmenu_quick_view_load_scripts', 'wc-only'), 'specific'); ?>>
                                            <?php esc_html_e('Specific Pages Only', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </option>
                                    </select>
                                    <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                </td>
                            </tr>

                            <tr class="rmenu-settings-row" id="rmenu-specific-pages-row" style="<?php echo (get_option('rmenu_quick_view_load_scripts', 'wc-only') == 'specific') ? 'display:block;' : 'display:none;'; ?>">
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    'rmenu-settings-label',
                                    '',
                                    __('Specific Pages IDs', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Enter the IDs of the specific pages where you want to load the quick view.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>
                                <td class="rmenu-settings-control pro-only">
                                    <input disabled type="text" name="rmenu_quick_view_specific_pages" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_quick_view_specific_pages', '')); ?>"  />
                                </td>
                            </tr>

                            <tr>
                                <?php
                                $onepaquc_helper->sec_head(
                                    'th',
                                    'rmenu-settings-label',
                                    '',
                                    __('Theme Compatibility Mode', 'one-page-quick-checkout-for-woocommerce'),
                                    __('Enable this if you experience display issues with your theme.', 'one-page-quick-checkout-for-woocommerce')
                                );
                                ?>
                                <td class="rmenu-settings-control">
                                    <?php $onepaquc_helper->switcher('rmenu_quick_view_theme_compat', 0); ?>
                                </td>
                            </tr>
                        </table>

                    </div>
                </div>
            </div>
            <div class="tab-content" id="tab-8">
                <div class="plugincy_nav_card mb-4">
                    <?php
                    $onepaquc_helper->sec_head(
                        'h2',
                        'plugincy_sec_head2',
                        '<span class="dashicons dashicons-cart"></span>',
                        __('WooCommerce Add To Cart', 'one-page-quick-checkout-for-woocommerce'),
                        '',
                        __('Easily modify the Add to Cart button text, style, and functionality for a more engaging shopping experience.', 'one-page-quick-checkout-for-woocommerce')
                    );
                    ?>

                    <div class="rmenu-settings-tabs">
                        <ul class="rmenu-settings-tab-list">
                            <li class="rmenu-settings-tab-item active" data-tab="general-settings">
                                <span class="dashicons dashicons-admin-generic"></span>
                                <?php esc_html_e('General Settings', 'one-page-quick-checkout-for-woocommerce'); ?>
                            </li>
                            <li class="rmenu-settings-tab-item" data-tab="button-behavior">
                                <span class="dashicons dashicons-controls-play"></span>
                                <?php esc_html_e('Button Behavior', 'one-page-quick-checkout-for-woocommerce'); ?>
                            </li>

                            <li class="rmenu-settings-tab-item" data-tab="advanced">
                                <span class="dashicons dashicons-admin-tools"></span>
                                <?php esc_html_e('Advanced', 'one-page-quick-checkout-for-woocommerce'); ?>
                            </li>

                        </ul>
                    </div>

                </div>

                <div class="tab-content" id="general-settings" style="padding: 0;">
                    <div class="plugincy_row">
                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php
                            $onepaquc_helper->sec_head(
                                'h3',
                                'plugincy_sec_head',
                                '<span class="dashicons dashicons-admin-generic"></span>',
                                __('General Settings', 'one-page-quick-checkout-for-woocommerce'),
                                ''
                            );
                            ?>

                            <table class="form-table plugincy_table">
                                <tr id="rmenu-enable-custom-add-to-cart">
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        '',
                                        '',
                                        __('Customizable Add to Cart', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Enable or disable custom Add to Cart styling and functionality.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control">
                                        <?php $onepaquc_helper->switcher('rmenu_enable_custom_add_to_cart', 1); ?>
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Button Text', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Customize the text displayed on the Add to Cart button for simple products.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control">
                                        <input type="text" name="txt-add-to-cart" value="<?php echo esc_attr(onepaquc_get_text_option('txt-add-to-cart', __('Add to Cart', 'one-page-quick-checkout-for-woocommerce'))); ?>"  />
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Variable Product Button Text', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Customize the text displayed on the Add to Cart button for variable products.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control">
                                        <input type="text" name="txt-select-options" value="<?php echo esc_attr(onepaquc_get_text_option('txt-select-options', __('Select Options', 'one-page-quick-checkout-for-woocommerce'))); ?>"  />
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Read More Button Text', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Customize the text displayed on the Read More button.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control">
                                        <input type="text" name="txt-read-more" value="<?php echo esc_attr(onepaquc_get_text_option('txt-read-more', __('Read More', 'one-page-quick-checkout-for-woocommerce'))); ?>"  />
                                    </td>
                                </tr>

                                <tr>
                                    <?php
                                    $onepaquc_helper->sec_head(
                                        'th',
                                        'rmenu-settings-label',
                                        '',
                                        __('Grouped Product Button Text', 'one-page-quick-checkout-for-woocommerce'),
                                        __('Customize the text displayed on the Add to Cart button for grouped products.', 'one-page-quick-checkout-for-woocommerce')
                                    );
                                    ?>
                                    <td class="rmenu-settings-control">
                                        <input type="text" name="rmenu_grouped_add_to_cart_text" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_grouped_add_to_cart_text', __('View Products', 'one-page-quick-checkout-for-woocommerce'))); ?>"  />
                                    </td>
                                </tr>
                            </table>
                        </div>


                        <div class="rmenu-settings-section button-style-section plugincy_card plugincy_col-5">
                            <?php
                            $onepaquc_helper->sec_head(
                                'h3',
                                'plugincy_sec_head',
                                '<span class="dashicons dashicons-admin-appearance"></span>',
                                __('Button Style', 'one-page-quick-checkout-for-woocommerce'),
                                ''
                            );
                            ?>


                            <table class="form-table plugincy_table">
                                <tbody class="plugincy_grid">
                                    <tr style="grid-column: span 2;">
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            'rmenu-settings-label',
                                            '',
                                            __('Button Style', 'one-page-quick-checkout-for-woocommerce'),
                                            ''
                                        );
                                        ?>
                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_add_to_cart_style" class="rmenu-select" id="rmenu-atc-style-select">
                                                <option value="default" <?php selected(get_option('rmenu_add_to_cart_style', 'default'), 'default'); ?>>
                                                    <?php esc_html_e('Default WooCommerce Style', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option disabled value="modern" <?php selected(get_option('rmenu_add_to_cart_style', 'default'), 'modern'); ?>>
                                                    <?php esc_html_e('Modern Style (Pro Feature)', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="rounded" <?php selected(get_option('rmenu_add_to_cart_style', 'default'), 'rounded'); ?>>
                                                    <?php esc_html_e('Rounded Style', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option disabled value="minimal" <?php selected(get_option('rmenu_add_to_cart_style', 'default'), 'minimal'); ?>>
                                                    <?php esc_html_e('Minimal Style (Pro Feature)', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="custom" <?php selected(get_option('rmenu_add_to_cart_style', 'default'), 'custom'); ?>>
                                                    <?php esc_html_e('Custom Style', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            </select>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Button Color', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>

                                        <td class="rmenu-settings-control">
                                            <input type="color" name="rmenu_add_to_cart_bg_color" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_add_to_cart_bg_color', '#000')); ?>" class="rmenu-color-picker" />
                                        </td>
                                    </tr>

                                    <tr>
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            'rmenu-settings-label',
                                            '',
                                            __('Text Color', 'one-page-quick-checkout-for-woocommerce'),
                                            ''
                                        );
                                        ?>
                                        <td class="rmenu-settings-control">
                                            <input type="color"
                                                name="rmenu_add_to_cart_text_color"
                                                value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_add_to_cart_text_color', '#ffffff')); ?>"
                                                class="rmenu-color-picker" />
                                        </td>
                                    </tr>


                                    <tr>
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            'rmenu-settings-label',
                                            '',
                                            __('Hover Background Color', 'one-page-quick-checkout-for-woocommerce'),
                                            ''
                                        );
                                        ?>
                                        <td class="rmenu-settings-control">
                                            <input type="color"
                                                name="rmenu_add_to_cart_hover_bg_color"
                                                value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_add_to_cart_hover_bg_color', '#7f4579')); ?>"
                                                class="rmenu-color-picker" />
                                        </td>
                                    </tr>


                                    <tr>
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            'rmenu-settings-label',
                                            '',
                                            __('Hover Text Color', 'one-page-quick-checkout-for-woocommerce'),
                                            ''
                                        );
                                        ?>
                                        <td class="rmenu-settings-control">
                                            <input type="color"
                                                name="rmenu_add_to_cart_hover_text_color"
                                                value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_add_to_cart_hover_text_color', '#ffffff')); ?>"
                                                class="rmenu-color-picker" />
                                        </td>
                                    </tr>


                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Border Radius', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>

                                        <td class="rmenu-settings-control">
                                            <input type="number" name="rmenu_add_to_cart_border_radius" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_add_to_cart_border_radius', '3')); ?>" class="small-text" min="0" max="50" step="1" />
                                            <span class="rmenu-unit">px</span>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Button Font Size', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>
                                        <td class="rmenu-settings-control">
                                            <input type="number" name="rmenu_add_to_cart_font_size" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_add_to_cart_font_size', '14')); ?>" class="small-text" min="10" max="24" step="1" />
                                            <span class="rmenu-unit">px</span>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th class="rmenu-settings-label">
                                            <?php esc_html_e('Button Width', 'one-page-quick-checkout-for-woocommerce'); ?>
                                        </th>
                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_add_to_cart_width" class="rmenu-select">
                                                <option value="auto" <?php selected(get_option('rmenu_add_to_cart_width', 'auto'), 'auto'); ?>>
                                                    <?php esc_html_e('Auto', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="full" <?php selected(get_option('rmenu_add_to_cart_width', 'auto'), 'full'); ?>>
                                                    <?php esc_html_e('Full Width', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                                <option value="custom" <?php selected(get_option('rmenu_add_to_cart_width', 'auto'), 'custom'); ?>>
                                                    <?php esc_html_e('Custom Width', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>

                                            </select>
                                        </td>
                                    </tr>

                                    <tr id="rmenu-atc-custom-width-row" style="<?php echo (get_option('rmenu_add_to_cart_width', 'auto') == 'custom') ? 'display:block;' : 'display:none;'; ?>">
                                        <th class="rmenu-settings-label">Custom Width Value</th>
                                        <td class="rmenu-settings-control">
                                            <input type="number" name="rmenu_add_to_cart_custom_width" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_add_to_cart_custom_width', '150')); ?>" class="small-text" min="50" max="500" step="1" />
                                            <span class="rmenu-unit">px</span>
                                        </td>
                                    </tr>

                                    <tr>
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            'rmenu-settings-label',
                                            '',
                                            __('Button Icon', 'one-page-quick-checkout-for-woocommerce'),
                                            ''
                                        );
                                        ?>
                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_add_to_cart_icon" class="rmenu-select">
                                                <option value="none" <?php selected(get_option('rmenu_add_to_cart_icon', 'none'), 'none'); ?>>
                                                    <?php esc_html_e('No Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="cart" <?php selected(get_option('rmenu_add_to_cart_icon', 'none'), 'cart'); ?>>
                                                    <?php esc_html_e('Cart Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="plus" <?php selected(get_option('rmenu_add_to_cart_icon', 'none'), 'plus'); ?>>
                                                    <?php esc_html_e('Plus Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="bag" <?php selected(get_option('rmenu_add_to_cart_icon', 'none'), 'bag'); ?>>
                                                    <?php esc_html_e('Shopping Bag Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="basket" <?php selected(get_option('rmenu_add_to_cart_icon', 'none'), 'basket'); ?>>
                                                    <?php esc_html_e('Basket Icon', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            </select>
                                        </td>

                                    </tr>
                                    <tr id="rmenu-atc-icon-position-row" style="<?php echo (get_option('rmenu_add_to_cart_icon', 'none') == 'none') ? 'display:none;' : 'display:block;'; ?>">
                                        <?php
                                        $onepaquc_helper->sec_head(
                                            'th',
                                            'rmenu-settings-label',
                                            '',
                                            __('Icon Position', 'one-page-quick-checkout-for-woocommerce'),
                                            ''
                                        );
                                        ?>

                                        <td class="rmenu-settings-control">
                                            <select name="rmenu_add_to_cart_icon_position" class="rmenu-select">
                                                <option value="left" <?php selected(get_option('rmenu_add_to_cart_icon_position', 'left'), 'left'); ?>>
                                                    <?php esc_html_e('Left', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="right" <?php selected(get_option('rmenu_add_to_cart_icon_position', 'left'), 'right'); ?>>
                                                    <?php esc_html_e('Right', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="top" <?php selected(get_option('rmenu_add_to_cart_icon_position', 'left'), 'top'); ?>>
                                                    <?php esc_html_e('Top', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                                <option value="bottom" <?php selected(get_option('rmenu_add_to_cart_icon_position', 'left'), 'bottom'); ?>>
                                                    <?php esc_html_e('Bottom', 'one-page-quick-checkout-for-woocommerce'); ?>
                                                </option>
                                            </select>
                                        </td>

                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="tab-content" id="button-behavior" style="padding: 0;">
                    <div class="rmenu-settings-section plugincy_card mb-4">
                        <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<span class="dashicons dashicons-visibility"></span>', __('Display Settings', 'one-page-quick-checkout-for-woocommerce'), __('Control how Add to Cart buttons appear on product archive pages.', 'one-page-quick-checkout-for-woocommerce')); ?>


                        <div class="rmenu-settings-row">
                            <div class="rmenu-settings-field" style="display: flex; align-items: center; justify-content: space-between; gap: 20px;">
                                <label class="rmenu-settings-label"><?php echo esc_html__('Button Display', 'one-page-quick-checkout-for-woocommerce'); ?>
                                    <span class="tooltip">
                                        <span class="question-mark">?</span>
                                        <span class="tooltip-text"><?php echo esc_html__('Control how Add to Cart buttons appear on product archive pages.', 'one-page-quick-checkout-for-woocommerce'); ?></span>
                                    </span>
                                </label>
                                <div class="rmenu-settings-control">
                                    <select name="rmenu_add_to_cart_catalog_display" class="rmenu-select">
                                        <option value="default" <?php selected(get_option('rmenu_add_to_cart_catalog_display', 'default'), 'default'); ?>><?php echo esc_html__('Default (WooCommerce Setting)', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                        <option value="show" <?php selected(get_option('rmenu_add_to_cart_catalog_display', 'default'), 'show'); ?>><?php echo esc_html__('Always Show', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                        <option value="hide" <?php selected(get_option('rmenu_add_to_cart_catalog_display', 'default'), 'hide'); ?>><?php echo esc_html__('Always Hide', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="plugincy_row">
                        <div class="rmenu-settings-section plugincy_card plugincy_col-5" id="add_to_cart_behave">
                            <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<span class="dashicons dashicons-controls-play"></span>', __('Add To Cart Behavior', 'one-page-quick-checkout-for-woocommerce'), __('Control how Add to Cart buttons behave on product archive pages.', 'one-page-quick-checkout-for-woocommerce')); ?>
                            <table class="form-table plugincy_table">
                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Enable AJAX Add to Cart', 'one-page-quick-checkout-for-woocommerce'), __('Add products to cart without page reload using AJAX.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td>
                                        <?php $onepaquc_helper->switcher('rmenu_enable_ajax_add_to_cart', 1); ?>
                                    </td>
                                </tr>

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Default Quantity', 'one-page-quick-checkout-for-woocommerce'), __('Set the default quantity when adding products to cart from archive pages.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td>
                                        <div class="rmenu-settings-control pro-only">
                                            <input disabled type="number" name="rmenu_add_to_cart_default_qty" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_add_to_cart_default_qty', '1')); ?>" class="small-text" min="1" max="100" step="1" />
                                            <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                        </div>
                                    </td>
                                </tr>

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Quantity Selector on Archives', 'one-page-quick-checkout-for-woocommerce'), __('Display quantity selector on shop/archive pages before adding to cart.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <?php $onepaquc_helper->switcher('rmenu_show_quantity_archive', 0); ?>
                                    </td>
                                </tr>

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Redirect After Add to Cart', 'one-page-quick-checkout-for-woocommerce'), __('Choose whether to redirect customers after adding products to cart.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control">
                                        <select name="rmenu_redirect_after_add" class="rmenu-select">
                                            <option value="none" <?php selected(get_option('rmenu_redirect_after_add', 'none'), 'none'); ?>><?php echo esc_html__('No Redirect', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                            <!-- rmenu_disable_cart_page is it's on disable below option & show cart page is disabled -->
                                            <?php
                                            $disable_cart_page = get_option('rmenu_disable_cart_page', '0');
                                            ?>
                                            <option value="cart" <?php selected(get_option('rmenu_redirect_after_add', 'none'), 'cart'); ?> <?php echo ($disable_cart_page == '1') ? 'disabled' : ''; ?>><?php echo esc_html__('Cart Page', 'one-page-quick-checkout-for-woocommerce'); ?> <?php echo ($disable_cart_page == '1') ? '(Disabled)' : ''; ?></option>
                                            <option value="checkout" <?php selected(get_option('rmenu_redirect_after_add', 'none'), 'checkout'); ?>><?php echo esc_html__('Checkout Page', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                        </select>
                                    </td>
                                </tr>

                                <!-- <tr>
                                    <?php //$onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', 'Add to Cart Animation', 'Choose the animation effect when products are added to cart.'); 
                                    ?>
                                    <td class="rmenu-settings-control">
                                        <select name="rmenu_add_to_cart_animation" class="rmenu-select">
                                            <option value="none" <?php //selected(get_option('rmenu_add_to_cart_animation', 'none'), 'none'); 
                                                                    ?>>None</option>
                                            <option value="slide" <?php //selected(get_option('rmenu_add_to_cart_animation', 'none'), 'slide'); 
                                                                    ?>>Slide Effect</option>
                                            <option value="fade" <?php //selected(get_option('rmenu_add_to_cart_animation', 'none'), 'fade'); 
                                                                    ?>>Fade Effect</option>
                                            <option value="fly" <?php //selected(get_option('rmenu_add_to_cart_animation', 'none'), 'fly'); 
                                                                ?>>Fly to Cart Effect</option>
                                        </select>
                                    </td>
                                </tr> -->
                            </table>
                        </div>


                        <div class="rmenu-settings-section plugincy_card plugincy_col-5" id="add_to_cart_notification">
                            <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<span class="dashicons dashicons-bell"></span>', __('Notifications', 'one-page-quick-checkout-for-woocommerce'), __('Customize how notifications are displayed when products are added to cart.', 'one-page-quick-checkout-for-woocommerce')); ?>
                            <table class="form-table plugincy_table">
                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Notification Style', 'one-page-quick-checkout-for-woocommerce'), __('Choose how to display notifications when products are added to cart.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <select disabled name="rmenu_add_to_cart_notification_style" class="rmenu-select">
                                            <option value="default" <?php selected(get_option('rmenu_add_to_cart_notification_style', 'default'), 'default'); ?>><?php echo esc_html__('Default WooCommerce Notices', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                            <option value="popup" <?php selected(get_option('rmenu_add_to_cart_notification_style', 'default'), 'popup'); ?>><?php echo esc_html__('Popup Message', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                            <option value="toast" <?php selected(get_option('rmenu_add_to_cart_notification_style', 'default'), 'toast'); ?>><?php echo esc_html__('Toast Notification', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                            <option value="mini_cart" <?php selected(get_option('rmenu_add_to_cart_notification_style', 'default'), 'mini_cart'); ?>><?php echo esc_html__('Mini Cart Preview', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                        </select>
                                        <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                    </td>
                                </tr>

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Success Message', 'one-page-quick-checkout-for-woocommerce'), __('Customize the success message shown after adding to cart. Use {product} as a placeholder for the product name.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <input disabled type="text" name="rmenu_add_to_cart_success_message" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_add_to_cart_success_message', '{product} has been added to your cart.')); ?>"  />
                                        <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                    </td>
                                </tr>

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Show View Cart Link', 'one-page-quick-checkout-for-woocommerce'), __('Display a "View Cart" link in the notification message.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <?php $onepaquc_helper->switcher('rmenu_show_view_cart_link', 1); ?>
                                    </td>
                                </tr>

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Show Checkout Link', 'one-page-quick-checkout-for-woocommerce'), __('Display a "Checkout" link in the notification message.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <?php $onepaquc_helper->switcher('rmenu_show_checkout_link', 0); ?>
                                    </td>
                                </tr>

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Notification Duration', 'one-page-quick-checkout-for-woocommerce'), __('How long to display the notification for (in milliseconds).', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <input disabled type="number" name="rmenu_add_to_cart_notification_duration" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_add_to_cart_notification_duration', '3000')); ?>" class="small-text" min="1000" max="10000" step="500" />
                                        <span class="rmenu-unit">ms</span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="tab-content" id="advanced" style="padding: 0;">
                    <div class="plugincy_row mb-4">
                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<span class="dashicons dashicons-smartphone"></span>', __('Mobile Settings', 'one-page-quick-checkout-for-woocommerce')); ?>

                            <table class="form-table plugincy_table">
                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '',  __('Sticky Add to Cart on Mobile', 'one-page-quick-checkout-for-woocommerce'), __('Keep the Add to Cart button visible at the bottom of the screen on mobile devices.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <?php $onepaquc_helper->switcher('rmenu_sticky_add_to_cart_mobile', 0, true); ?>
                                    </td>
                                </tr>

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Mobile Button Text', 'one-page-quick-checkout-for-woocommerce'), __('Set a different button text for mobile devices. Leave empty to use the default text.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <input disabled type="text" name="rmenu_mobile_add_to_cart_text" value="<?php echo esc_attr(onepaquc_get_text_option('rmenu_mobile_add_to_cart_text', '')); ?>"  />
                                        <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                    </td>
                                </tr>

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Mobile Button Size', 'one-page-quick-checkout-for-woocommerce'), __('Choose button size optimization for mobile devices.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <select disabled name="rmenu_mobile_button_size" class="rmenu-select">
                                            <option value="default" <?php selected(get_option('rmenu_mobile_button_size', 'default'), 'default'); ?>> <?php esc_html_e('Same as Desktop', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                            <option value="larger" <?php selected(get_option('rmenu_mobile_button_size', 'default'), 'larger'); ?>> <?php esc_html_e('Larger', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                            <option value="smaller" <?php selected(get_option('rmenu_mobile_button_size', 'default'), 'smaller'); ?>> <?php esc_html_e('Smaller', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                            <option value="full" <?php selected(get_option('rmenu_mobile_button_size', 'default'), 'full'); ?>> <?php esc_html_e('Full Width', 'one-page-quick-checkout-for-woocommerce'); ?></option>
                                        </select>
                                        <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                    </td>
                                </tr>

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Mobile Button Icon Only', 'one-page-quick-checkout-for-woocommerce'), __('Show only the icon (without text) on mobile devices to save space.', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <?php $onepaquc_helper->switcher('rmenu_mobile_icon_only', 0, true); ?>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <div class="rmenu-settings-section plugincy_card plugincy_col-5">
                            <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<span class="dashicons dashicons-welcome-widgets-menus"></span>', __('Advanced Options', 'one-page-quick-checkout-for-woocommerce')); ?>

                            <table class="form-table plugincy_table">
                                <!-- <tr>
                                    <?php //$onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', 'Add to Cart Load Effect', 'Choose an animation effect while adding to cart is in progress.'); 
                                    ?>
                                    <td class="rmenu-settings-control pro-only">
                                        <select disabled name="rmenu_add_to_cart_loading_effect" class="rmenu-select">
                                            <option value="none" <?php //selected(get_option('rmenu_add_to_cart_loading_effect', 'spinner'), 'none'); 
                                                                    ?>>None</option>
                                            <option value="spinner" <?php //selected(get_option('rmenu_add_to_cart_loading_effect', 'spinner'), 'spinner'); 
                                                                    ?>>Spinner</option>
                                            <option value="dots" <?php //selected(get_option('rmenu_add_to_cart_loading_effect', 'spinner'), 'dots'); 
                                                                    ?>>Dots</option>
                                            <option value="pulse" <?php //selected(get_option('rmenu_add_to_cart_loading_effect', 'spinner'), 'pulse'); 
                                                                    ?>>Pulse</option>
                                        </select>
                                        <span class="dashicons dashicons-lock plugincy_lock-icon"></span>
                                    </td>
                                </tr> -->

                                <tr>
                                    <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Disable continue shopping button', 'one-page-quick-checkout-for-woocommerce'), __('WooCommerce shows a continue shopping button after a product is added to cart, with this option you can disable that link so user remain on checkout page', 'one-page-quick-checkout-for-woocommerce')); ?>
                                    <td class="rmenu-settings-control">
                                        <?php $onepaquc_helper->switcher('rmenu_disable_btn_out_of_stock', 1); ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="rmenu-settings-section plugincy_card">
                        <?php $onepaquc_helper->sec_head('h3', 'plugincy_sec_head', '<span class="dashicons dashicons-translation"></span>', __('Compatibility Settings', 'one-page-quick-checkout-for-woocommerce'), __('Settings to ensure compatibility with various themes and plugins.', 'one-page-quick-checkout-for-woocommerce')); ?>

                        <table class="form-table plugincy_table">
                            <tr>
                                <?php $onepaquc_helper->sec_head('th', 'rmenu-settings-label', '', __('Force Button CSS', 'one-page-quick-checkout-for-woocommerce'), __('Use !important CSS rules to override theme styling (use only if needed).', 'one-page-quick-checkout-for-woocommerce')); ?>
                                <td class="rmenu-settings-control">
                                    <?php $onepaquc_helper->switcher('rmenu_force_button_css', 0); ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

            </div>
            <div style="text-align: right;display: flex;justify-content: flex-end;width: 98.5%;margin-top: 42px;align-items: center;padding: 20px;box-sizing: border-box;">
                <button type="submit" class="button button-primary" style="padding: 4px 20px;border: none;display: flex;gap: 5px;align-items: center;">
                    <span style="margin-bottom: -7px;"><svg fill="#fff" width="16" height="16" viewBox="0 0 0.48 0.48" xmlns="http://www.w3.org/2000/svg">
                            <path d="M.474.124.356.006A.03.03 0 0 0 .341 0H.022A.02.02 0 0 0 0 .022v.436c0 .013.01.023.022.023h.436A.022.022 0 0 0 .481.459v-.32A.02.02 0 0 0 .475.124zM.131.044h.131V.16H.131zm0 .393V.32h.218v.116zm.306 0H.393V.299A.022.022 0 0 0 .371.276H.109a.02.02 0 0 0-.022.022v.138H.044V.044h.044v.139q.001.02.021.021h.174A.022.022 0 0 0 .306.182V.044h.027l.104.104z" />
                        </svg></span>
                    <span>
                        <?php esc_html_e('Save Changes', 'one-page-quick-checkout-for-woocommerce'); ?>
                    </span>

                </button>
            </div>
        </form>
        <form method="post" action="" onsubmit="return confirm('Are you sure you want to reset all settings to default? This action cannot be undone.');" style="display: none;">
            <!-- nonces -->
            <?php wp_nonce_field('onepaquc_reset_settings', 'onepaquc_reset_settings_nonce'); ?>
            <input type="hidden" name="onepaquc_reset_settings" value="1">
            <?php
            submit_button('Reset Settings', 'button-primary', '', false, array_merge(array('style' => 'margin-left: 20px;background:#dc3545;color:#fff;border-color:#dc3545;')));
            ?>
        </form>

        <div>
            <div class="plugincy_nav_card mb-4" style="padding-bottom: 1px;">
                <?php
                $onepaquc_helper->sec_head(
                    'h2',
                    'plugincy_sec_head2',
                    '<span class="dashicons dashicons-video-alt3"></span>',
                    __('Tutorials', 'one-page-quick-checkout-for-woocommerce'),
                    '',
                    __('Learn how to use our plugin features with these step-by-step video tutorials.', 'one-page-quick-checkout-for-woocommerce')
                );
                ?>
            </div>


            <div class="tutorial-container">
                <!-- Tutorial Topic 1 -->
                <div class="tutorial-topic">
                    <div class="tutorial-video">
                        <iframe
                            width="100%"
                            height="200"
                            src="https://www.youtube.com/embed/IJU9EEIT8MA?autoplay=1&mute=1&loop=1&playlist=IJU9EEIT8MA"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen>
                        </iframe>
                    </div>
                    <h3><?php esc_html_e('Buy Now Button', 'one-page-quick-checkout-for-woocommerce'); ?></h3>

                    <p>
                        <?php esc_html_e('Transform your WooCommerce store with instant purchase buttons that bypass the traditional cart process. Our plugin automatically adds buy now buttons on single product and archive pages, but you have complete control over placement and customization.', 'one-page-quick-checkout-for-woocommerce'); ?>
                    </p>
                    <div class="tutorial-shortcode">
                        <h4><?php esc_html_e('Basic Shortcode:', 'one-page-quick-checkout-for-woocommerce'); ?></h4>

                        <code>[onepaquc_button]</code>
                        <p>
                            <?php
                            echo esc_html__(
                                'This shortcode will display a buy now button for the current product when used on product pages.',
                                'one-page-quick-checkout-for-woocommerce'
                            );
                            ?>
                        </p>

                    </div>
                </div>

                <!-- Tutorial Topic 2 -->
                <div class="tutorial-topic">
                    <div class="tutorial-video">
                        <iframe
                            width="100%"
                            height="200"
                            src="https://www.youtube.com/embed/FY_-CSI03vk?autoplay=1&mute=1&loop=1&playlist=FY_-CSI03vk"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen>
                        </iframe>
                    </div>
                    <h3>
                        <?php esc_html_e('Buy Now Button Anywhere', 'one-page-quick-checkout-for-woocommerce'); ?>
                    </h3>

                    <p>
                        <?php
                        echo wp_kses_post(
                            __(
                                'You can use <strong>buy now button</strong> anywhere on your <strong>site</strong> with this <strong>shortcode</strong>.',
                                'one-page-quick-checkout-for-woocommerce'
                            )
                        );
                        ?>
                    </p>
                    <div class="tutorial-shortcode">
                        <h4><?php esc_html_e('Shortcode:', 'one-page-quick-checkout-for-woocommerce'); ?></h4>
                        <code>[onepaquc_button product_id="123" variation_id="456" qty="2"]</code>
                    </div>
                    <div class="tutorial-tips">
                        <h4>
                            <?php esc_html_e('Tips:', 'one-page-quick-checkout-for-woocommerce'); ?>
                        </h4>
                        <p>
                            <?php esc_html_e(
                                'Use our widget or block (Buy Now Button) for easier implementation.',
                                'one-page-quick-checkout-for-woocommerce'
                            ); ?>
                        </p>
                    </div>

                </div>

                <!-- Tutorial Topic 3 -->
                <div class="tutorial-topic">
                    <div class="tutorial-video">
                        <iframe
                            width="100%"
                            height="200"
                            src="https://www.youtube.com/embed/nXmUvcNzDb8?autoplay=1&mute=1&loop=1&playlist=nXmUvcNzDb8"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen>
                        </iframe>
                    </div>
                    <h3><?php esc_html_e('One Page Checkout', 'one-page-quick-checkout-for-woocommerce'); ?></h3>
                    <p>
                        <?php
                        echo wp_kses_post(
                            __(
                                'You can use <strong>buy now button</strong> anywhere on your <strong>site</strong> with this <strong>shortcode</strong>.',
                                'one-page-quick-checkout-for-woocommerce'
                            )
                        );
                        ?>
                    </p>
                    <div class="tutorial-shortcode">
                        <h4><?php esc_html_e('Shortcode:', 'one-page-quick-checkout-for-woocommerce'); ?></h4>
                        <code>[onepaquc_checkout product_id="123" variation_id="456" qty="2" clear_cart="yes" auto_add="yes"]</code>
                    </div>

                    <div class="tutorial-tips">
                        <h4><?php esc_html_e('Tips:', 'one-page-quick-checkout-for-woocommerce'); ?></h4>
                        <p><?php esc_html_e('Use our widget or block (One-page checkout) for easier implementation.', 'one-page-quick-checkout-for-woocommerce'); ?></p>
                    </div>
                </div>

                <div class="tutorial-topic">
                    <div class="tutorial-video">
                        <iframe
                            width="100%"
                            height="200"
                            src="https://www.youtube.com/embed/S96e1Nj5Kxc?autoplay=1&mute=1&loop=1&playlist=S96e1Nj5Kxc"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen>
                        </iframe>
                    </div>
                    <h3><?php esc_html_e('Floating Cart', 'one-page-quick-checkout-for-woocommerce'); ?></h3>

                    <p>
                        <?php
                        echo wp_kses_post(
                            __(
                                'A <strong>modern</strong>, <strong>stylish</strong> <strong>side-drawer cart</strong> that users can access from <strong>any page</strong> for improved convenience.',
                                'one-page-quick-checkout-for-woocommerce'
                            )
                        );
                        ?>
                    </p>
                    <div class="tutorial-tips">
                        <h4><?php esc_html_e('Floating Cart Benefits:', 'one-page-quick-checkout-for-woocommerce'); ?></h4>

                        <ul>
                            <li>
                                <?php
                                echo wp_kses_post(
                                    __(
                                        '<strong>Reduced Abandonment:</strong>Customers can review their cart without losing their place on your site',
                                        'one-page-quick-checkout-for-woocommerce'
                                    )
                                );
                                ?>
                            </li>
                            <li>
                                <?php
                                echo wp_kses_post(
                                    __(
                                        '<strong>Improved UX:</strong> No page reloads or redirects needed to manage cart contents',
                                        'one-page-quick-checkout-for-woocommerce'
                                    )
                                );
                                ?>
                            </li>
                            <li>
                                <?php
                                echo wp_kses_post(
                                    __(
                                        '<strong>Mobile Friendly:</strong> Touch-optimized interface perfect for mobile shopping',
                                        'one-page-quick-checkout-for-woocommerce'
                                    )
                                );
                                ?>
                            </li>
                            <li>
                                <?php
                                echo wp_kses_post(
                                    __(
                                        '<strong>Sales Boost:</strong> Easy access to cart encourages completion of purchases',
                                        'one-page-quick-checkout-for-woocommerce'
                                    )
                                );
                                ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php
    // }
}
add_action('admin_init', 'onepaquc_cart_settings');
// add_action('wp_head', 'onepaquc_cart_custom_css');

function onepaquc_handle_reset_settings()
{
    // verify nonce
    if (!isset($_POST['onepaquc_reset_settings_nonce']) || !is_scalar($_POST['onepaquc_reset_settings_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['onepaquc_reset_settings_nonce'])), 'onepaquc_reset_settings')) {
        return;
    }
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['onepaquc_reset_settings']) && is_scalar($_POST['onepaquc_reset_settings']) && '1' === sanitize_text_field(wp_unslash($_POST['onepaquc_reset_settings']))) {
        global $onepaquc_string_settings_fields;
        foreach (onepaquc_rmenu_fields() as $key => $field) {
            delete_option($key);
        }
        foreach (onepaquc_onpcheckout_heading() as $key => $field) {
            delete_option($key);
        }

        foreach (is_array($onepaquc_string_settings_fields) ? $onepaquc_string_settings_fields : array() as $field) {
            delete_option($field);
        }

        global $onepaquc_checkoutformfields, $onepaquc_productpageformfields;
        $checkout_fields = is_array($onepaquc_checkoutformfields) ? $onepaquc_checkoutformfields : array();
        $product_fields  = is_array($onepaquc_productpageformfields) ? $onepaquc_productpageformfields : array();
        $settings = array_merge(array_keys($checkout_fields), array_keys($product_fields));

        foreach ($settings as $setting) {
            delete_option($setting);
        }

        // List of settings to reset
        $settings_to_reset = [
            'onepaquc_checkout_fields',
            'rmenu_show_quick_checkout_by_types',
            'rmenu_show_quick_checkout_by_page',
            'rmenu_add_to_cart_by_types',
            'rmenu_quick_view_content_elements',
            'rmenu_show_quick_view_by_types',
            'rmenu_show_quick_view_by_page',
            'onepaquc_my_trust_badges_items',
            'checkout_form_setup',
            'onepaquc_trust_badge_custom_html',
        ];

        // Reset each setting
        foreach ($settings_to_reset as $setting) {
            delete_option($setting);
        }

        // Redirect to the same page to avoid resubmission
        $current_url = isset($_SERVER['REQUEST_URI']) && is_string($_SERVER['REQUEST_URI']) ? esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'])) : admin_url('admin.php?page=onepaquc_cart');

        // Check if the URL already has a query string
        if (strpos($current_url, '?') !== false) {
            // Append the new action parameter
            $redirect_url = $current_url . '&action=reset_success';
        } else {
            // Add the action parameter as the first query parameter
            $redirect_url = $current_url . '?action=reset_success';
        }
        wp_safe_redirect($redirect_url);
        exit;
    }
}
add_action('admin_init', 'onepaquc_handle_reset_settings');


function onepaquc_cart_settings()
{
    global $onepaquc_string_settings_fields;
    foreach (onepaquc_rmenu_fields() as $key => $field) {
        register_setting('onepaquc_cart_settings', $key, 'sanitize_text_field');
    }
    foreach (onepaquc_onpcheckout_heading() as $key => $field) {
        register_setting('onepaquc_cart_settings', $key, 'sanitize_text_field');
    }

    foreach ($onepaquc_string_settings_fields as $field) {
        register_setting('onepaquc_cart_settings', $field, 'sanitize_text_field');
    }

    global $onepaquc_checkoutformfields, $onepaquc_productpageformfields;
    $settings = array_merge(array_keys($onepaquc_checkoutformfields), array_keys($onepaquc_productpageformfields));

    foreach ($settings as $setting) {
        register_setting('onepaquc_cart_settings', $setting, 'sanitize_text_field');
    }
    // Register the setting for the checkout fields values of array
    register_setting('onepaquc_cart_settings', "onepaquc_checkout_fields", 'onepaquc_sanitize_array_of_text');
    register_setting('onepaquc_cart_settings', "rmenu_show_quick_checkout_by_types", 'onepaquc_sanitize_array_of_text');
    register_setting('onepaquc_cart_settings', "rmenu_show_quick_checkout_by_page", 'onepaquc_sanitize_array_of_text');
    register_setting('onepaquc_cart_settings', "rmenu_add_to_cart_by_types", 'onepaquc_sanitize_array_of_text');
    register_setting('onepaquc_cart_settings', "rmenu_quick_view_content_elements", 'onepaquc_sanitize_array_of_text');
    register_setting('onepaquc_cart_settings', "rmenu_show_quick_view_by_types", 'onepaquc_sanitize_array_of_text');
    register_setting('onepaquc_cart_settings', "rmenu_show_quick_view_by_page", 'onepaquc_sanitize_array_of_text');
    register_setting('onepaquc_cart_settings', "onepaquc_my_trust_badges_items", 'onepaquc_sanitize_trust_badges_items');
}

function onepaquc_sanitize_trust_badges_items($items)
{
    // Only accept an array
    if (!is_array($items)) {
        return [];
    }

    // Remove empty items and sanitize
    $sanitized = [];
    foreach ($items as $item) {
        // Only accept arrays with at least 'icon' or 'text'
        if (!is_array($item)) {
            continue;
        }
        // Remove empty trust badge rows (all fields empty)
        $has_content = false;
        foreach ($item as $value) {
            if (is_scalar($value) && trim((string) $value) !== '') {
                $has_content = true;
                break;
            }
        }
        if (!$has_content) {
            continue;
        }
        // Remove if text is "New Badge"
        if (isset($item['text']) && is_scalar($item['text']) && trim((string) $item['text']) === 'New Badge') {
            continue;
        }
        // Sanitize each field
        $sanitized_item = [];
        foreach ($item as $key => $value) {
            if (!is_scalar($key) || !is_scalar($value)) {
                continue;
            }
            $sanitized_item[sanitize_key((string) $key)] = sanitize_text_field((string) $value);
        }
        $sanitized_item = wp_parse_args($sanitized_item, array('icon' => '', 'text' => ''));
        $sanitized[] = $sanitized_item;
    }

    // Remove duplicates (same icon and text)
    $unique = [];
    foreach ($sanitized as $item) {
        $hash = md5($item['icon'] . '|' . $item['text']);
        $unique[$hash] = $item;
    }

    // Re-index array
    return array_values($unique);
}

function onepaquc_sanitize_array_of_text($value)
{
    if (!is_array($value)) {
        return [];
    }

    return array_values(array_filter(array_map('sanitize_text_field', array_filter($value, 'is_scalar'))));
}


function onepaquc_cart_custom_css()
{
    global $onepaquc_rcheckoutformfields;
    $onepaquc_rcheckoutformfields = is_array($onepaquc_rcheckoutformfields) ? $onepaquc_rcheckoutformfields : array();

    // Initialize an empty string for the custom CSS
    $custom_css = '';

    // Loop through the fields to generate CSS
    foreach (onepaquc_rmenu_fields() as $key => $field) {
        if (get_option($key)) {
            $custom_css .= "{$field['selector']} { display: none !important; }";
        }
    }

    $checkout_fields = onepaquc_normalize_key_list(get_option('onepaquc_checkout_fields', array()));
    if ($checkout_fields) {
        foreach ($checkout_fields as $field) {
            if (isset($onepaquc_rcheckoutformfields[$field])) {
                $selector = $onepaquc_rcheckoutformfields[$field]['selector'];
                $custom_css .= "{$selector} { display: none !important; }";
            }
        }
    }

    // Add the inline styles
    wp_add_inline_style('rmenu-cart-style', $custom_css);
}

// Hook to enqueue the styles
add_action('wp_enqueue_scripts', 'onepaquc_cart_custom_css', 9999999);

function onepaquc_rmenu_fields()
{
    return [
        'hide_coupon_toggle' => [
            'selector' => '.woocommerce-form-coupon-toggle, .col-form-coupon,.woocommerce-form-coupon-toggle, .col-form-coupon',
            'title'    => __('Hide Top Coupon', 'one-page-quick-checkout-for-woocommerce'),
        ],
        'hide_customer_details_col2' => [
            'selector' => ' .woocommerce-shipping-fields, .woocommerce-shipping-fields',
            'title'    => __('Hide Shipping Address', 'one-page-quick-checkout-for-woocommerce'),
        ],
        'hide_privacy_policy_text' => [
            'selector' => '.woocommerce-privacy-policy-text, .woocommerce-privacy-policy-text, .wp-block-woocommerce-checkout-terms-block .wc-block-checkout__terms .wc-block-components-checkbox__label, .wc-block-checkout__terms .wc-block-components-checkbox__label',
            'title'    => __('Hide Privacy Policy Text', 'one-page-quick-checkout-for-woocommerce'),
        ],
        'hide_payment' => [
            'selector' => 'div#payment ul, div#payment ul, .wp-block-woocommerce-checkout-payment-block, .wc-block-checkout__payment-method, .wc-block-components-checkout-payment-methods, .wc-block-checkout__no-payment-methods-notice',
            'title'    => __('Hide Payment Options', 'one-page-quick-checkout-for-woocommerce'),
        ],
        'hide_product' => [
            'selector' => 'table.shop_table, table.shop_table, .wp-block-woocommerce-checkout-order-summary-block, .wp-block-woocommerce-checkout-order-summary-cart-items-block, .wp-block-woocommerce-checkout-order-summary-totals-block, .wc-block-components-order-summary',
            'title'    => __('Hide Product Table', 'one-page-quick-checkout-for-woocommerce'),
        ],
    ];
}

function onepaquc_onpcheckout_heading()
{
    return [
        'hide_billing_details'          => ['selector' => '.woocommerce-billing-fields h3,.woocommerce-billing-fields h3,.wc-block-checkout__billing-fields .wc-block-components-checkout-step__title,.wc-block-checkout__billing-fields .wc-block-components-checkout-step__description,.wp-block-woocommerce-checkout-billing-address-block .wc-block-components-checkout-step__title,.wp-block-woocommerce-checkout-billing-address-block .wc-block-components-checkout-step__description', 'title' => __('Hide Billing details', 'one-page-quick-checkout-for-woocommerce')],
        'hide_additional_details'          => ['selector' => ' .woocommerce-additional-fields h3,.woocommerce-additional-fields h3', 'title' => __('Hide Additional Details', 'one-page-quick-checkout-for-woocommerce')],
        'hide_order_review_heading'   => ['selector' => 'h3#order_review_heading, h3#order_review_heading, .wc-block-components-checkout-order-summary__title, .wc-block-components-checkout-order-summary__title-text, .wp-block-woocommerce-checkout-order-summary-heading-block', 'title' => __('Hide Order Review Heading', 'one-page-quick-checkout-for-woocommerce')],
    ];
}
