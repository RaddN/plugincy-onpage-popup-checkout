<?php

/**
 * Plugin Name: One Page Quick Checkout for WooCommerce
 * Plugin URI:  https://plugincy.com/one-page-quick-checkout-for-woocommerce/
 * Description: Enhance WooCommerce with popup checkout, cart drawer, and flexible checkout templates to boost conversions.
 * Version:  1.3.7
 * Author: plugincy
 * Author URI: https://plugincy.com
 * license: GPL2
 * Text Domain: one-page-quick-checkout-for-woocommerce
 * Domain Path: /languages
 * Requires Plugins: woocommerce
 */


if (! defined('ABSPATH')) exit; // Exit if accessed directly

define('ONEPAQUC_PLUGIN_URL', plugin_dir_url(__FILE__));

define("RMENU_VERSION", "1.3.7");

function onepaquc_is_enabled_option($option_name, $default = '0')
{
    $value = get_option($option_name, $default);

    if (is_bool($value)) {
        return $value;
    }

    if (is_numeric($value)) {
        return (int) $value === 1;
    }

    return in_array(strtolower(trim((string) $value)), array('1', 'true', 'yes', 'on'), true);
}

// Include the admin notice file
require_once plugin_dir_path(__FILE__) . 'includes/admin-notice.php';

// admin menu
require_once plugin_dir_path(__FILE__) . 'includes/admin.php';

// include one page checkout shortcode
require_once plugin_dir_path(__FILE__) . 'includes/one-page-checkout-shortcode.php';
require_once plugin_dir_path(__FILE__) . 'includes/add-to-cart-button.php';
require_once plugin_dir_path(__FILE__) . 'includes/class_helper.php';
require_once plugin_dir_path(__FILE__) . 'includes/blocks/checkout-form-block.php';


global $onepaquc_checkoutformfields, $onepaquc_productpageformfields, $onepaquc_rcheckoutformfields, $onepaquc_string_settings_fields;

$onepaquc_string_settings_fields = [
    "rmsg_editor",
    "onpage_checkout_position",
    "onpage_checkout_cart_empty",
    "onpage_checkout_enable",
    "onpage_checkout_enable_all",
    "onpage_checkout_cart_add",
    "onpage_checkout_widget_cart_empty",
    "onpage_checkout_widget_cart_add",
    "onpage_checkout_hide_cart_button",
    "rmenu_quantity_control",
    "rmenu_at_one_product_cart",
    "rmenu_disable_cart_page",
    "rmenu_link_product",
    "rmenu_allow_analytics",
    "rmenu_remove_product",
    "rmenu_add_img_before_product",
    "rmenu_add_direct_checkout_button",
    "rmenu_enable_custom_add_to_cart",
    "rmenu_wc_checkout_guest_enabled",
    "rmenu_wc_checkout_mobile_optimize",
    "rmenu_wc_direct_checkout_position",
    "rmenu_wc_direct_checkout_single_position",
    "rmenu_variation_show_archive",
    "rmenu_variation_layout",
    "rmenu_show_variation_title",
    "rmenu_wc_hide_select_option",
    "txt-direct-checkout",
    "rmenu_wc_checkout_color",
    "rmenu_add_to_cart_bg_color",
    "rmenu_wc_checkout_text_color",
    "rmenu_wc_checkout_hover_bg_color",
    "rmenu_wc_checkout_hover_text_color",
    "rmenu_wc_checkout_border_radius",
    "rmenu_wc_checkout_font_size",
    "rmenu_wc_checkout_width",
    "rmenu_wc_checkout_custom_width",
    "rmenu_wc_checkout_custom_css",
    "rmenu_add_to_cart_text_color",
    "rmenu_add_to_cart_hover_bg_color",
    "rmenu_add_to_cart_hover_text_color",
    "rmenu_add_to_cart_border_radius",
    "rmenu_add_to_cart_font_size",
    "rmenu_add_to_cart_width",
    "rmenu_add_to_cart_custom_width",
    "rmenu_add_to_cart_custom_css",
    "rmenu_add_to_cart_icon",
    "rmenu_add_to_cart_icon_position",
    "rmenu_add_to_cart_catalog_display",
    "rmenu_wc_checkout_style",
    "rmenu_add_to_cart_style",
    "rmenu_wc_checkout_icon",
    "rmenu_wc_checkout_icon_position",
    "rmenu_wc_checkout_method",
    "rmenu_wc_clear_cart",
    "rmenu_wc_one_click_purchase",
    "rmenu_wc_add_confirmation",
    "rmenu_enable_ajax_add_to_cart",
    "rmenu_add_to_cart_default_qty",
    "rmenu_show_quantity_archive",
    "rmenu_redirect_after_add",
    "rmenu_add_to_cart_animation",
    "rmenu_add_to_cart_notification_style",
    "rmenu_add_to_cart_success_message",
    "rmenu_show_view_cart_link",
    "rmenu_add_to_cart_notification_duration",
    "rmenu_show_checkout_link",
    "rmenu_sticky_add_to_cart_mobile",
    "rmenu_mobile_add_to_cart_text",
    "rmenu_mobile_button_size",
    "rmenu_hide_on_mobile_options",
    "rmenu_mobile_icon_only",
    "rmenu_add_to_cart_loading_effect",
    "rmenu_disable_btn_out_of_stock",
    "rmenu_force_button_css",
    "rmenu_enable_quick_view",
    "rmenu_quick_view_button_text",
    "rmenu_quick_view_button_position",
    "rmenu_quick_view_display_type",
    "rmenu_quick_view_modal_size",
    "rmenu_quick_view_enable_lightbox",
    "rmenu_quick_view_loading_effect",
    "rmenu_quick_view_button_style",
    "rmenu_quick_view_button_color",
    "rmenu_quick_view_text_color",
    "rmenu_quick_view_button_icon",
    "rmenu_quick_view_icon_position",
    "rmenu_quick_view_custom_css",
    "rmenu_quick_view_ajax_add_to_cart",
    "rmenu_quick_view_direct_checkout",
    "rmenu_quick_view_mobile_optimize",
    "rmenu_quick_view_close_on_add",
    "rmenu_quick_view_keyboard_nav",
    "rmenu_quick_view_preload",
    "rmenu_quick_view_enable_cache",
    "rmenu_quick_view_cache_expiration",
    "rmenu_quick_view_lazy_load",
    "rmenu_quick_view_details_text",
    "rmenu_quick_view_close_text",
    "rmenu_quick_view_prev_text",
    "rmenu_quick_view_next_text",
    "rmenu_quick_view_track_events",
    "rmenu_quick_view_event_category",
    "rmenu_quick_view_event_action",
    "rmenu_quick_view_load_scripts",
    "rmenu_quick_view_theme_compat",
    "onepaquc_trust_badges_enabled",
    "onepaquc_trust_badge_position",
    "onepaquc_trust_badge_style",
    "show_custom_html",
    "rmenu_enable_sticky_cart",
    "rmenu_cart_checkout_behavior",
    "rmenu_cart_top_position",
    "rmenu_cart_left_position",
    "rmenu_cart_bg_color",
    "rmenu_cart_text_color",
    "rmenu_cart_hover_bg",
    "rmenu_cart_hover_text",
    "rmenu_cart_border_radius",
    "rmenu_show_cart_icon",
    "rmenu_show_cart_count",
    "rmenu_show_cart_total",
    "rmenu_cart_animation",
];

require_once plugin_dir_path(__FILE__) . 'includes/global-values.php';
require_once plugin_dir_path(__FILE__) . 'includes/quickview.php';
require_once plugin_dir_path(__FILE__) . 'admin/license-tab.php';
require_once plugin_dir_path(__FILE__) . 'includes/analytics.php';

// Enqueue scripts and styles
function onepaquc_cart_enqueue_scripts()
{
    $checkout_page_id = wc_get_page_id('checkout');

    // Check if checkout page exists and has [woocommerce_checkout] shortcode
    if ($checkout_page_id === -1) {
        // Create a new checkout page if it doesn't exist
        $new_checkout_id = wp_insert_post([
            'post_title'   => esc_html__('Checkout', 'one-page-quick-checkout-for-woocommerce'),
            'post_content' => '[woocommerce_checkout]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ]);
        if ($new_checkout_id && !is_wp_error($new_checkout_id)) {
            update_option('woocommerce_checkout_page_id', $new_checkout_id);
        }
    }

    $cart_script_version = RMENU_VERSION . '.' . filemtime(plugin_dir_path(__FILE__) . 'assets/js/cart.js');

    wp_enqueue_style('rmenu-cart-style', plugin_dir_url(__FILE__) . 'assets/css/rmenu-cart.css', array(), "1.3.7");
    wp_enqueue_style('checkout-form-two-column', plugin_dir_url(__FILE__) . 'assets/css/checkout-form-two-column.css', array(), "1.3.7");
    wp_enqueue_script('rmenu-cart-script', plugin_dir_url(__FILE__) . 'assets/js/rmenu-cart.js', array('jquery'), "1.3.7", true);
    wp_enqueue_script('cart-script', plugin_dir_url(__FILE__) . 'assets/js/cart.js', array('jquery'), $cart_script_version, true);
    $direct_checkout_behave = [
        'rmenu_wc_checkout_method' => get_option('rmenu_wc_checkout_method', 'direct_checkout'),
        'rmenu_wc_clear_cart' => get_option('rmenu_wc_clear_cart', 0),
        'rmenu_wc_one_click_purchase' => 0,
        'rmenu_wc_add_confirmation' => get_option('rmenu_wc_add_confirmation', 0),
    ];
    // Localize script for AJAX URL and WooCommerce cart variables
    wp_localize_script('cart-script', 'onepaquc_wc_cart_params', array(
        'ajax_url' => esc_url(admin_url('admin-ajax.php')),
        'get_cart_content_none' => esc_js(wp_create_nonce('get_cart_content_none')),
        'update_cart_item_quantity' => esc_js(wp_create_nonce('update_cart_item_quantity')),
        'remove_cart_item' => esc_js(wp_create_nonce('remove_cart_item')),
        'onepaquc_refresh_checkout_product_list' => esc_js(wp_create_nonce('onepaquc_refresh_checkout_product_list')),
        'get_variations_nonce' => esc_js(wp_create_nonce('get_variations_nonce')), // Add this line
        'direct_checkout_behave' => $direct_checkout_behave,
        'blocks_quantity_control' => onepaquc_is_enabled_option('rmenu_quantity_control', '1') ? '1' : '0',
        'blocks_link_product' => onepaquc_is_enabled_option('rmenu_link_product', '0') ? '1' : '0',
        'checkout_url' => wc_get_checkout_url(),
        'cart_url'     => wc_get_cart_url(),
        'nonce' => esc_js(wp_create_nonce('rmenu-ajax-nonce')),
    ));
    // Retrieve the rmsg_editor value
    $rmsg_editor_value = get_option('rmsg_editor', '');
    $currency_symbol = get_woocommerce_currency_symbol();

    $plugincy_all_settings = [];
    $others_settings = [
        'onepaquc_checkout_fields',
        'rmenu_show_quick_checkout_by_types',
        'rmenu_show_quick_checkout_by_page',
        'rmenu_add_to_cart_by_types',
        'rmenu_quick_view_content_elements',
        'rmenu_show_quick_view_by_types',
        'rmenu_show_quick_view_by_page',
        'onepaquc_my_trust_badges_items',
        'checkout_form_setup',
        'onepaquc_trust_badge_custom_html',
    ];
    foreach ($GLOBALS['onepaquc_string_settings_fields'] as $field) {
        $plugincy_all_settings[$field] = get_option($field, '');
    }
    foreach ($others_settings as $field) {
        $plugincy_all_settings[$field] = get_option($field, []);
    }

    // Localize the script with the rmsg_editor value
    wp_localize_script('rmenu-cart-script', 'onepaquc_rmsgValue', array(
        'rmsgEditor' => $rmsg_editor_value,
        'checkout_url' => wc_get_checkout_url(),
        'apply_coupon' => esc_js(wp_create_nonce('apply-coupon')),
        'currency_symbol' => $currency_symbol,
        'plugincy_all_settings' => $plugincy_all_settings,
        'ajax_url' => esc_url(admin_url('admin-ajax.php'))
    ));
}
add_action('wp_enqueue_scripts', 'onepaquc_cart_enqueue_scripts', 20);

add_action('admin_enqueue_scripts', 'onepaquc_cart_admin_styles');

// Enqueue the admin stylesheet only for this settings page
function onepaquc_cart_admin_styles($hook)
{
    if ($hook === 'toplevel_page_onepaquc_cart') {
        wp_enqueue_style('onepaquc_cart_admin_css', plugin_dir_url(__FILE__) . 'assets/css/admin-style.css', array(), "1.3.7");
        wp_enqueue_style('select2-css', plugin_dir_url(__FILE__) . 'assets/css/select2.min.css', array(), "1.3.7");
        wp_enqueue_script('select2-js', plugin_dir_url(__FILE__) . 'assets/js/select2.min.js', array('jquery'), "1.3.7", true);
    }
    wp_enqueue_style('onepaquc_cart_admin_css', plugin_dir_url(__FILE__) . 'assets/css/admin-documentation.css', array(), "1.3.7");
    wp_enqueue_script('rmenu-admin-script', plugin_dir_url(__FILE__) . 'assets/js/admin-documentation.js', array('jquery'), "1.3.7", true);
}

// add shortcode
// if (get_option('onepaquc_api_key') && get_option('onepaquc_validity_days')!=="0"){
require_once plugin_dir_path(__FILE__) . 'includes/rmenu-shortcode.php';
require_once plugin_dir_path(__FILE__) . 'includes/ajaxhandler.php';
require_once plugin_dir_path(__FILE__) . 'includes/label-change.php';



// }else{
//     require_once plugin_dir_path(__FILE__) . 'includes/without_api_short_code';
// }


function onepaquc_editor_script()
{
    if (wp_script_is('onepaquc_editor_script', 'enqueued')) {
        return;
    }
    wp_enqueue_script(
        'onepaquc_editor_script',
        plugin_dir_url(__FILE__) . 'includes/blocks/editor.js',
        array('wp-blocks', 'wp-element', 'wp-edit-post', 'wp-dom-ready', 'wp-plugins'),
        '1.3.7',
        true
    );
}
add_action('enqueue_block_editor_assets', 'onepaquc_editor_script');


require_once plugin_dir_path(__FILE__) . 'includes/cart-template.php';
require_once plugin_dir_path(__FILE__) . 'includes/popup-template.php';
require_once plugin_dir_path(__FILE__) . 'includes/documentation.php';
require_once plugin_dir_path(__FILE__) . 'includes/blocks/plugincy-cart-blocks.php';
require_once plugin_dir_path(__FILE__) . 'includes/blocks/one-page-checkout.php';

// checkout popup form

function onepaquc_rmenu_checkout_popup($isonepagewidget = false)
{
    // Return if this is the cart or checkout page
    if (is_cart()) {
        return;
    }

    // Global setting: popup checkout
    $checkout_method   = get_option('rmenu_wc_checkout_method', 'direct_checkout');
    $is_popup_checkout = ($checkout_method === 'popup_checkout');

    if(onepaquc_is_checkout_rendered() || !$is_popup_checkout){
        return true;
    }

    // Return if the current page content already has a WooCommerce checkout form
    global $post;
    if ($post && has_shortcode($post->post_content, 'woocommerce_checkout')) {
        return;
    }

?>
    <div class="checkout-popup <?php echo $isonepagewidget ? 'onepagecheckoutwidget' : ''; ?>" data-isonepagewidget="<?php echo esc_attr($isonepagewidget); ?>" style="<?php echo $isonepagewidget ? 'display: block; position: unset; transform: unset; box-shadow: none; background: unset; width: 100%; max-width: 100%; height: 100%;overflow: hidden;' : 'display:none'; ?>;">
        <?php
        onepaquc_rmenu_checkout($isonepagewidget);
        ?>
    </div>
<?php
}

require_once plugin_dir_path(__FILE__) . 'admin/product_edit_page_setup.php';


function onepaquc_display_checkout_on_single_product()
{
    // if(is_checkout()){
    //     return;
    // }
    // Only run on single product pages
    if (!is_product()) {
        // global $post;
        // if (isset($post) && is_object($post) && strpos($post->post_content, 'plugincy_one_page_checkout') === false) {
        //     add_action('wp_head', 'onepaquc_rmenu_checkout_popup');
        // }
        return;
    }

    $product_id = get_the_ID();
    $product = wc_get_product($product_id);

    if(!$product->is_purchasable() || (!$product->is_in_stock() && !$product->is_on_backorder())){
        return;
    }

    if (!$product || !is_a($product, 'WC_Product')) {
        // global $post;
        // if (isset($post) && is_object($post) && strpos($post->post_content, 'plugincy_one_page_checkout') === false) {
        //     add_action('wp_head', 'onepaquc_rmenu_checkout_popup');
        // }
        return;
    }

    $one_page_checkout = get_post_meta($product_id, '_one_page_checkout', true);
    $isallproduct_checkout_enable = get_option("onpage_checkout_enable_all", 0);

    if ($one_page_checkout === 'yes' || $isallproduct_checkout_enable) {

        if (!WC()->cart->is_empty() && get_option("onpage_checkout_cart_empty", "1") === "1") {
            WC()->cart->empty_cart();
        }

        if (get_option("onpage_checkout_cart_add", "1") === "1") {
            if ($product->is_type('variable')) {
                $available_variations = onepaquc_get_validated_variations( $product );
                if (!empty($available_variations)) {
                    $variation = $available_variations[0];
                    $variation_id = $variation['variation_id'];
                    $variation_attributes = $variation['attributes'];
                    WC()->cart->add_to_cart($product_id, 1, $variation_id, $variation_attributes);
                }
            } elseif ($product->is_type('grouped')) {
                $children_ids = $product->get_children();
                foreach ($children_ids as $child_id) {
                    $child_product = wc_get_product($child_id);
                    if ($child_product && $child_product->is_purchasable() && $child_product->is_in_stock()) {
                        WC()->cart->add_to_cart($child_id, 1);
                    }
                }
            } else {
                // Simple, downloadable, etc.
                WC()->cart->add_to_cart($product_id, 1);
            }
        } else {
            add_action('wp_footer', 'onepaquc_cart_add_disabled_notice');
        }



        add_action('wp_enqueue_scripts', 'onepaquc_add_checkout_inline_styles', 99);
        if (get_option("onpage_checkout_enable", "1") === "1") {

            add_filter('woocommerce_product_tabs', 'onepaquc_add_checkout_tab_to_product_page', get_option("onpage_checkout_position", '9'));

            add_action('woocommerce_after_single_product_summary', 'onepaquc_display_one_page_checkout_form',  get_option("onpage_checkout_position", '9'));
            // Fallback hooks for themes that don't use the standard hook
            add_action('wp', function () {
                // Product tabs area hooks
                add_action('woocommerce_before_product_tabs', 'onepaquc_display_one_page_checkout_form', get_option("onpage_checkout_position", '9'));
                add_action('woocommerce_after_product_tabs', 'onepaquc_display_one_page_checkout_form', get_option("onpage_checkout_position", '9'));

                // Related products
                add_action('woocommerce_output_related_products', 'onepaquc_display_one_page_checkout_form', get_option("onpage_checkout_position", '9'));
                add_action('woocommerce_before_related_products', 'onepaquc_display_one_page_checkout_form', get_option("onpage_checkout_position", '9'));
                add_action('woocommerce_after_related_products', 'onepaquc_display_one_page_checkout_form', get_option("onpage_checkout_position", '9'));

                // After single product
                add_action('woocommerce_after_single_product', 'onepaquc_display_one_page_checkout_form', get_option("onpage_checkout_position", '9'));

                // WooCommerce content hooks (broader scope)
                add_action('woocommerce_after_main_content', 'onepaquc_display_one_page_checkout_form', get_option("onpage_checkout_position", '9'));

                add_action('wp_footer', 'onepaquc_display_one_page_checkout_form', 10);
            });
        }
        if (get_option("onpage_checkout_hide_cart_button") === "1") {
            remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);
            // add_filter('woocommerce_is_purchasable', function ($is_purchasable, $product) {
            //     return false;
            // }, 10, 2);
            add_action('wp_head', function () {
                echo '<style>
                    .quantity, 
                    button.single_add_to_cart_button.button {
                        display: none !important;
                    }
                </style>';
            });
        }
    }
    // else {
    //     global $post;
    //     if (isset($post) && is_object($post) && strpos($post->post_content, 'plugincy_one_page_checkout') === false) {
    //         add_action('wp_head', 'onepaquc_rmenu_checkout_popup');
    //     }
    // }
}


add_action('wp', 'onepaquc_display_checkout_on_single_product', 99);



/**
 * Display admin notice when "Add to Cart on Page Load" is disabled
 * Shows in wp_footer for logged-in administrators on product pages
 */
function onepaquc_cart_add_disabled_notice() {
    // Only show to administrators
    if (!current_user_can('manage_options')) {
        return;
    }

    // Only show on single product pages
    if (!is_product()) {
        return;
    }

    ?>
    <div id="onepaquc-admin-notice" style="
        position: fixed;
        bottom: 20px;
        right: 20px;
        max-width: 400px;
        background: linear-gradient(135deg, #fff5e6 0%, #ffffff 100%);
        border-left: 5px solid #f39c12;
        border-radius: 8px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.15);
        padding: 20px;
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
        animation: slideInRight 0.5s ease-out;
    ">
        <button onclick="document.getElementById('onepaquc-admin-notice').style.display='none'" style="
            position: absolute;
            top: 10px;
            right: 10px;
            background: transparent;
            border: none;
            font-size: 20px;
            color: #999;
            cursor: pointer;
            padding: 0;
            width: 24px;
            height: 24px;
            line-height: 1;
        " title="Dismiss">×</button>
        
        <div style="display: flex; align-items: start; gap: 12px;">
            <div style="
                background: #f39c12;
                color: white;
                border-radius: 50%;
                width: 36px;
                height: 36px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                font-size: 20px;
                font-weight: bold;
            ">⚠</div>
            
            <div style="flex: 1;">
                <div style="
                align-self: center;
                font-size: 12px;
                font-weight: 600;
                color: #f39c12;
                white-space: nowrap;
            ">This notice is only visible to administrators.</div>
                <h4 style="
                    margin: 0 0 8px 0;
                    font-size: 16px;
                    font-weight: 600;
                    color: #333;
                ">Add to Cart is Disabled</h4>
                
                <p style="
                    margin: 0 0 12px 0;
                    font-size: 13px;
                    line-height: 1.5;
                    color: #555;
                ">
                    <strong>One page checkout is enabled </strong> for this product but Current product will not be added to cart automatically.
                    <strong>One Page Checkout will not respond properly.</strong> 
                </p>
                
                <div style="
                    background: rgba(243, 156, 18, 0.1);
                    border-radius: 4px;
                    padding: 10px;
                    font-size: 12px;
                    line-height: 1.4;
                    color: #666;
                    border-left: 3px solid #f39c12;
                ">
                    <strong style="color: #f39c12;">📌 Action Required:</strong><br>
                    Enable <em>"Add to Cart on Page Load"</em> in<br>
                    <strong>onpage checkout -> One Page Checkout Settings</strong>
                </div>
            </div>
        </div>
    </div>
    
    <style>
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        #onepaquc-admin-notice button:hover {
            color: #333 !important;
        }
    </style>
    <?php
}


function onepaquc_checkout_already_rendered(): bool
{
    return defined('ONEPAQUC_CHECKOUT_RENDERED') && ONEPAQUC_CHECKOUT_RENDERED === 1;
}


/**
 * Display the checkout form
 */
function onepaquc_display_one_page_checkout_form(): bool
{

    if (onepaquc_checkout_already_rendered() || !function_exists('WC') || !WC()->cart || WC()->cart->is_empty()) {
        return false;
    }
?>
    <div class="one-page-checkout-container" id="checkout-popup" data-isonepagewidget="true">
        <h2>Checkout</h2>
        <p class="one-page-checkout-description"><?php echo get_option('txt-complete_your_purchase') ? esc_attr(get_option('txt-complete_your_purchase')) : 'Complete your purchase using the form below.'; ?></p>
        <?php echo do_shortcode('[woocommerce_checkout]'); ?>
    </div>
<?php
    // Mark as rendered for the rest of this request
    if (!defined('ONEPAQUC_CHECKOUT_RENDERED')) {
        define('ONEPAQUC_CHECKOUT_RENDERED', 1);
    }
    return true;
}

function onepaquc_add_checkout_tab_to_product_page($tabs)
{
    // If it's already printed somewhere, don't add the tab
    if (onepaquc_checkout_already_rendered()) {
        return $tabs;
    }

    // Add checkout tab as the first tab
    $new_tabs = array();



    // Add checkout tab first
    $new_tabs['checkout'] = array(
        'title'    => esc_html__('Checkout', 'one-page-quick-checkout-for-woocommerce'),
        'priority' => 5, // Lower number = higher priority (appears first)
        'callback' => 'onepaquc_display_one_page_checkout_form'
    );

    // Add existing tabs after checkout
    foreach ($tabs as $key => $tab) {
        $tab['priority'] = $tab['priority'] + 10; // Push other tabs down
        $new_tabs[$key] = $tab;
    }

    return $new_tabs;
}

function onepaquc_add_checkout_inline_styles()
{
    // Make sure style is enqueued before adding inline styles
    if (wp_style_is('rmenu-cart-style', 'enqueued')) {
        wp_add_inline_style('rmenu-cart-style', '.checkout-button-drawer {display: none !important; } a.checkout-button-drawer-link { display: flex !important; }');
    }
}

// if current page contains the shortcode plugincy_one_page_checkout
function onepaquc_check_shortcode_and_enqueue_styles()
{
    if (is_page() && has_shortcode(get_post()->post_content, 'plugincy_one_page_checkout')) {
        add_action('wp_enqueue_scripts', 'onepaquc_add_checkout_inline_styles', 99);
    }
}
add_action('wp', 'onepaquc_check_shortcode_and_enqueue_styles', 99);

/**
 * Replace the default quantity display with quantity controls in checkout
 */
function onepaquc_custom_quantity_input_on_checkout($html, $cart_item, $cart_item_key)
{

    // Get current quantity
    $quantity = $cart_item['quantity'];
    $new_html = '<strong class="product-quantity">× ' . esc_attr($quantity) . '</strong>';
    if (onepaquc_is_enabled_option('rmenu_quantity_control', '1')) {
        // Build custom quantity input
        $new_html = '<div class="checkout-quantity-control">';
        $new_html .= '<button type="button" class="checkout-qty-btn checkout-qty-minus" data-cart-item="' . esc_attr($cart_item_key) . '">-</button>';
        $new_html .= '<input type="text" name="cart[' . esc_attr($cart_item_key) . '][qty]" class="checkout-qty-input" value="' . esc_attr($quantity) . '" min="1" step="1" size="4">';
        $new_html .= '<button type="button" class="checkout-qty-btn checkout-qty-plus" data-cart-item="' . esc_attr($cart_item_key) . '">+</button>';
        $new_html .= '</div>';
    }
    if (onepaquc_is_enabled_option('rmenu_remove_product', '0')) {
        // remove button
        $remove_button = ' <a class="remove-item-checkout" data-cart-item="' . esc_attr($cart_item_key) . '" aria-label="' . esc_attr__('Remove this item', 'one-page-quick-checkout-for-woocommerce') . '"><svg style="width: 12px; fill: #ff0000;" xmlns="https://www.w3.org/2000/svg" viewBox="0 0 448 512" role="graphics-symbol" aria-hidden="false" aria-label=""><path d="M135.2 17.69C140.6 6.848 151.7 0 163.8 0H284.2C296.3 0 307.4 6.848 312.8 17.69L320 32H416C433.7 32 448 46.33 448 64C448 81.67 433.7 96 416 96H32C14.33 96 0 81.67 0 64C0 46.33 14.33 32 32 32H128L135.2 17.69zM31.1 128H416V448C416 483.3 387.3 512 352 512H95.1C60.65 512 31.1 483.3 31.1 448V128zM111.1 208V432C111.1 440.8 119.2 448 127.1 448C136.8 448 143.1 440.8 143.1 432V208C143.1 199.2 136.8 192 127.1 192C119.2 192 111.1 199.2 111.1 208zM207.1 208V432C207.1 440.8 215.2 448 223.1 448C232.8 448 240 440.8 240 432V208C240 199.2 232.8 192 223.1 192C215.2 192 207.1 199.2 207.1 208zM304 208V432C304 440.8 311.2 448 320 448C328.8 448 336 440.8 336 432V208C336 199.2 328.8 192 320 192C311.2 192 304 199.2 304 208z"></path></svg></a>';
        $new_html .= $remove_button;
    }
    return $new_html;
}
add_filter('woocommerce_checkout_cart_item_quantity', 'onepaquc_custom_quantity_input_on_checkout', 10, 3);


/**
 * Force checkout mode across all pages
 * 
 * Forces WooCommerce to treat all pages as checkout pages
 * Useful for custom checkout implementations
 * 
 * @param bool $is_checkout Original checkout status
 * @return bool Always returns true
 */
add_filter('woocommerce_is_checkout', 'onepaquc_force_woocommerce_checkout_mode', 999);

function onepaquc_force_woocommerce_checkout_mode($is_checkout)
{
    // Don't affect wp-admin (except AJAX calls)
    if (is_admin() && !(defined('DOING_AJAX') && DOING_AJAX)) {
        return $is_checkout;
    }

    if ($is_checkout || (is_cart() && !onepaquc_is_checkout_rendered())) {
        return $is_checkout;
    }

    // Global setting: popup checkout
    $checkout_method   = get_option('rmenu_wc_checkout_method', 'direct_checkout');
    $is_popup_checkout = ($checkout_method === 'popup_checkout');

    if(onepaquc_is_checkout_rendered() || $is_popup_checkout){
        return true;
    }

    return $is_checkout;
}

function onepaquc_is_checkout_rendered(){
    $post_id = 0;
    if (function_exists('get_queried_object_id')) {
        $post_id = (int) get_queried_object_id();
    }
    if (!$post_id && isset($GLOBALS['post']->ID)) {
        $post_id = (int) $GLOBALS['post']->ID;
    }

    // (1) Current page has [plugincy_one_page_checkout] shortcode
    $has_opc_shortcode = onepaquc_page_has_shortcode('plugincy_one_page_checkout');
    $has_opcs_shortcode = onepaquc_page_has_shortcode('onepaquc_checkout');
    $has_checkout_block = false;
    if (function_exists('has_block')) {
        $has_checkout_block = has_block('plugincy/one-page-checkout', $post_id ?: null) || has_block('wc/one-page-checkout', $post_id ?: null);
    }

    $has_elementor_widget = false;
    if ($post_id && function_exists('get_post_meta')) {
        $elementor_data = get_post_meta($post_id, '_elementor_data', true);
        if (is_string($elementor_data) && $elementor_data !== '') {
            $has_elementor_widget = (strpos($elementor_data, '"widgetType":"onepaquc_checkout"') !== false) || (strpos($elementor_data, '"widgetType":"plugincy"') !== false);
        }
    }
    

    

    // (3) Single product page & (global enable-all OR per-product enabled)
    $enable_all_opc    = (bool) get_option('onepaquc_checkout_enable_all', 0);
    $is_single_product = function_exists('is_product') && is_product();
    

    $per_product_enabled = false;
    if ($is_single_product && !$enable_all_opc) {
        // Resolve current product ID safely
        $product_id = $post_id;
        if ($product_id) {
            $per_product_enabled = (bool) get_post_meta($product_id, '_one_page_checkout', true);
        }
    }

    // Apply your OR conditions
    if (
        $has_opc_shortcode
        || $has_opcs_shortcode
        || $has_checkout_block
        || $has_elementor_widget
        || ($is_single_product && ($enable_all_opc || $per_product_enabled))
    ) {
        return true;
    }

    return false;
}

/**
 * Whether current request should bypass full-page caching.
 */
function onepaquc_should_bypass_cache_for_checkout()
{
    if (is_admin() || wp_doing_ajax()) {
        return false;
    }

    if ((defined('REST_REQUEST') && REST_REQUEST) || (defined('DOING_CRON') && DOING_CRON)) {
        return false;
    }

    return onepaquc_is_checkout_rendered();
}

/**
 * Mark checkout-rendered requests as non-cacheable for popular cache plugins.
 */
function onepaquc_mark_checkout_request_nocache()
{
    if (!onepaquc_should_bypass_cache_for_checkout()) {
        return;
    }

    if (!defined('DONOTCACHEPAGE')) {
        define('DONOTCACHEPAGE', true);
    }
    if (!defined('DONOTCACHEOBJECT')) {
        define('DONOTCACHEOBJECT', true);
    }
    if (!defined('DONOTCACHEDB')) {
        define('DONOTCACHEDB', true);
    }
    if (!defined('DONOTMINIFY')) {
        define('DONOTMINIFY', true);
    }
    if (!defined('DONOTROCKETOPTIMIZE')) {
        define('DONOTROCKETOPTIMIZE', true);
    }
}
add_action('wp', 'onepaquc_mark_checkout_request_nocache', 0);
add_action('template_redirect', 'onepaquc_mark_checkout_request_nocache', 0);

/**
 * Send no-cache headers for checkout-rendered requests.
 */
function onepaquc_send_checkout_nocache_headers()
{
    if (!onepaquc_should_bypass_cache_for_checkout()) {
        return;
    }

    nocache_headers();

    if (!headers_sent()) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: Wed, 11 Jan 1984 05:00:00 GMT');
        header('Surrogate-Control: no-store');
        header('X-Accel-Expires: 0');
        header('X-LiteSpeed-Cache-Control: no-cache');
    }
}
add_action('send_headers', 'onepaquc_send_checkout_nocache_headers', 0);

/**
 * Return false for "can cache?" style filters when checkout is rendered.
 */
function onepaquc_prevent_page_cache_when_checkout($can_cache = true)
{
    if (onepaquc_should_bypass_cache_for_checkout()) {
        return false;
    }

    return $can_cache;
}

/**
 * Return true for "bypass cache?" style filters when checkout is rendered.
 */
function onepaquc_bypass_page_cache_when_checkout($bypass_cache = false)
{
    if (onepaquc_should_bypass_cache_for_checkout()) {
        return true;
    }

    return $bypass_cache;
}

// Popular cache plugin compatibility.
add_filter('do_rocket_generate_caching_files', 'onepaquc_prevent_page_cache_when_checkout', 10, 1); // WP Rocket
add_filter('do_createsupercache', 'onepaquc_prevent_page_cache_when_checkout', 10, 1); // WP Super Cache
add_filter('w3tc_can_cache', 'onepaquc_prevent_page_cache_when_checkout', 10, 1); // W3 Total Cache
add_filter('breeze_is_page_cache_allowed', 'onepaquc_prevent_page_cache_when_checkout', 10, 1); // Breeze
add_filter('sgo_bypass_caching', 'onepaquc_bypass_page_cache_when_checkout', 10, 1); // SiteGround Optimizer
add_filter('cache_enabler_bypass', 'onepaquc_bypass_page_cache_when_checkout', 10, 1); // Cache Enabler
add_filter('litespeed_control_set_nocache', 'onepaquc_bypass_page_cache_when_checkout', 10, 1); // LiteSpeed Cache

/**
 * Check if the current queried page content contains a shortcode.
 */
function onepaquc_page_has_shortcode($shortcode_tag)
{
    if (empty($shortcode_tag)) return false;

    // Check global $post first
    if (isset($GLOBALS['post']->post_content) && function_exists('has_shortcode')) {
        if (has_shortcode($GLOBALS['post']->post_content, $shortcode_tag)) {
            return true;
        }
    }

    // Fallback: check queried object content
    if (function_exists('get_queried_object')) {
        $obj = get_queried_object();
        if (!empty($obj->post_content) && function_exists('has_shortcode')) {
            if (has_shortcode($obj->post_content, $shortcode_tag)) {
                return true;
            }
        }
    }

    return false;
}

require_once plugin_dir_path(__FILE__) . 'includes/extra_features.php';
require_once plugin_dir_path(__FILE__) . 'includes/quick_checkout_button.php';
require_once plugin_dir_path(__FILE__) . 'includes/blocks/buy-now-button-block.php';
require_once plugin_dir_path(__FILE__) . 'includes/trusted-badge.php';
require_once plugin_dir_path(__FILE__) . 'includes/elementor/plugincy-cart-widget.php';
require_once plugin_dir_path(__FILE__) . 'includes/elementor/one-page-checkout.php';
require_once plugin_dir_path(__FILE__) . 'includes/elementor/elementor-category.php';


add_filter('woocommerce_checkout_fields', 'onepaquc_remove_required_checkout_fields', 999);
add_filter('woocommerce_default_address_fields', 'onepaquc_remove_required_default_address_fields', 999);
add_filter('woocommerce_billing_fields', 'onepaquc_remove_required_billing_fields', 999);
add_filter('woocommerce_shipping_fields', 'onepaquc_remove_required_shipping_fields', 999);
add_filter('woocommerce_shared_settings', 'onepaquc_remove_required_block_checkout_fields', 999);
add_filter('woocommerce_checkout_fields', 'onepaquc_apply_custom_checkout_field_labels', 1000);
add_filter('woocommerce_default_address_fields', 'onepaquc_apply_custom_default_address_field_labels', 1000);

/**
 * Return sanitized checkout field keys selected in admin as removable.
 *
 * @return array
 */
function onepaquc_get_removed_checkout_fields()
{
    $removed_fields = get_option('onepaquc_checkout_fields', []);
    if (!is_array($removed_fields)) {
        return [];
    }

    $removed_fields = array_map('sanitize_key', $removed_fields);
    $removed_fields = array_filter($removed_fields, function ($field) {
        return is_string($field) && $field !== '';
    });

    return array_values(array_unique($removed_fields));
}

/**
 * Check whether a checkout field key matches one of the configured removable keys.
 *
 * @param string $field_key
 * @param array  $removed_fields
 * @return bool
 */
function onepaquc_is_removed_checkout_field($field_key, $removed_fields)
{
    if (!is_string($field_key) || $field_key === '' || !is_array($removed_fields) || empty($removed_fields)) {
        return false;
    }

    foreach ($removed_fields as $removed_field) {
        if ($removed_field !== '' && strpos($field_key, $removed_field) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Set selected fields as non-required in a flat field array.
 *
 * @param array $fields
 * @param array $removed_fields
 * @return array
 */
function onepaquc_mark_fields_not_required($fields, $removed_fields)
{
    if (!is_array($fields) || empty($fields) || empty($removed_fields)) {
        return $fields;
    }

    foreach ($fields as $field_key => $field_config) {
        if (!onepaquc_is_removed_checkout_field((string) $field_key, $removed_fields) || !is_array($field_config)) {
            continue;
        }

        $fields[$field_key]['required'] = false;

        if (isset($fields[$field_key]['validate']) && is_array($fields[$field_key]['validate'])) {
            $fields[$field_key]['validate'] = array_values(array_diff($fields[$field_key]['validate'], ['required']));
        }
    }

    return $fields;
}

/**
 * Map checkout field keys to plugin label option keys.
 *
 * @return array
 */
function onepaquc_get_checkout_label_option_map()
{
    return [
        'first_name'     => 'txt_first_name',
        'last_name'      => 'txt_last_name',
        'country'        => 'txt_country',
        'address_1'      => 'txt_street',
        'city'           => 'txt_city',
        'state'          => 'txt_district',
        'postcode'       => 'txt_postcode',
        'phone'          => 'txt_phone_number',
        'email'          => 'txt_email_address',
        'order_comments' => 'txt_notes',
    ];
}

/**
 * Get a sanitized label value from plugin settings.
 *
 * @param string $option_key
 * @return string
 */
function onepaquc_get_custom_checkout_label($option_key)
{
    $value = get_option($option_key, '');
    if (!is_string($value)) {
        return '';
    }

    $value = trim($value);
    return $value === '' ? '' : sanitize_text_field($value);
}

/**
 * Apply custom labels to classic/shortcode/Elementor checkout fields.
 *
 * @param array $fields
 * @return array
 */
function onepaquc_apply_custom_checkout_field_labels($fields)
{
    if (!is_array($fields) || empty($fields)) {
        return $fields;
    }

    $label_map = onepaquc_get_checkout_label_option_map();

    foreach ($fields as $group_key => $group_fields) {
        if (!is_array($group_fields)) {
            continue;
        }

        foreach ($group_fields as $field_key => $field_config) {
            if (!is_array($field_config)) {
                continue;
            }

            $option_key = null;

            if (isset($label_map[$field_key])) {
                $option_key = $label_map[$field_key];
            } else {
                foreach ($label_map as $needle => $mapped_option) {
                    if ($needle !== 'order_comments' && strpos((string) $field_key, $needle) !== false) {
                        $option_key = $mapped_option;
                        break;
                    }
                }
            }

            if (!$option_key) {
                continue;
            }

            $custom_label = onepaquc_get_custom_checkout_label($option_key);
            if ($custom_label === '') {
                continue;
            }

            $fields[$group_key][$field_key]['label'] = $custom_label;
        }
    }

    return $fields;
}

/**
 * Apply custom labels to default address fields (shared base for multiple checkout flows).
 *
 * @param array $fields
 * @return array
 */
function onepaquc_apply_custom_default_address_field_labels($fields)
{
    if (!is_array($fields) || empty($fields)) {
        return $fields;
    }

    $label_map = onepaquc_get_checkout_label_option_map();
    foreach ($fields as $field_key => $field_config) {
        if (!is_array($field_config) || !isset($label_map[$field_key])) {
            continue;
        }

        $custom_label = onepaquc_get_custom_checkout_label($label_map[$field_key]);
        if ($custom_label === '') {
            continue;
        }

        $fields[$field_key]['label'] = $custom_label;
    }

    return $fields;
}

/**
 * Classic checkout fields (grouped array: billing/shipping/order/account).
 *
 * @param array $fields
 * @return array
 */
function onepaquc_remove_required_checkout_fields($fields)
{
    $removed_fields = onepaquc_get_removed_checkout_fields();
    if (empty($removed_fields) || !is_array($fields)) {
        return $fields;
    }

    foreach ($fields as $group_key => $group_fields) {
        if (!is_array($group_fields)) {
            continue;
        }
        $fields[$group_key] = onepaquc_mark_fields_not_required($group_fields, $removed_fields);
    }

    return $fields;
}

/**
 * Address defaults used by classic checkout and country locale logic.
 *
 * @param array $fields
 * @return array
 */
function onepaquc_remove_required_default_address_fields($fields)
{
    $removed_fields = onepaquc_get_removed_checkout_fields();
    return onepaquc_mark_fields_not_required($fields, $removed_fields);
}

/**
 * Billing fields (flat array with keys like billing_email).
 *
 * @param array $fields
 * @return array
 */
function onepaquc_remove_required_billing_fields($fields)
{
    $removed_fields = onepaquc_get_removed_checkout_fields();
    return onepaquc_mark_fields_not_required($fields, $removed_fields);
}

/**
 * Shipping fields (flat array with keys like shipping_city).
 *
 * @param array $fields
 * @return array
 */
function onepaquc_remove_required_shipping_fields($fields)
{
    $removed_fields = onepaquc_get_removed_checkout_fields();
    return onepaquc_mark_fields_not_required($fields, $removed_fields);
}

/**
 * WooCommerce Blocks checkout fields are driven by shared settings (defaultFields/countryData).
 * Mirror admin-selected removals there so Blocks and Elementor blocks respect the same setup.
 *
 * @param array $settings
 * @return array
 */
function onepaquc_remove_required_block_checkout_fields($settings)
{
    if (!is_array($settings)) {
        return $settings;
    }

    $removed_fields = onepaquc_get_removed_checkout_fields();
    $has_removed_fields = !empty($removed_fields);

    if (isset($settings['defaultFields']) && is_array($settings['defaultFields'])) {
        $label_map = onepaquc_get_checkout_label_option_map();

        foreach ($label_map as $field_key => $option_key) {
            if (!isset($settings['defaultFields'][$field_key]) || !is_array($settings['defaultFields'][$field_key])) {
                continue;
            }

            $custom_label = onepaquc_get_custom_checkout_label($option_key);
            if ($custom_label === '') {
                continue;
            }

            $settings['defaultFields'][$field_key]['label'] = $custom_label;
            $settings['defaultFields'][$field_key]['optionalLabel'] = sprintf(
                /* translators: %s: checkout field label. */
                __('%s (optional)', 'one-page-quick-checkout-for-woocommerce'),
                $custom_label
            );
        }

        if ($has_removed_fields) {
            foreach ($settings['defaultFields'] as $field_key => $field_config) {
                if (!is_array($field_config) || !onepaquc_is_removed_checkout_field((string) $field_key, $removed_fields)) {
                    continue;
                }

                $settings['defaultFields'][$field_key]['required'] = false;
                $settings['defaultFields'][$field_key]['hidden']   = true;

                if (
                    !isset($settings['defaultFields'][$field_key]['optionalLabel'])
                    && !empty($field_config['label'])
                    && is_string($field_config['label'])
                ) {
                    $settings['defaultFields'][$field_key]['optionalLabel'] = sprintf(
                        /* translators: %s: checkout field label. */
                        __('%s (optional)', 'one-page-quick-checkout-for-woocommerce'),
                        $field_config['label']
                    );
                }
            }
        }
    }

    if ($has_removed_fields && isset($settings['countryData']) && is_array($settings['countryData'])) {
        foreach ($settings['countryData'] as $country_code => $country_data) {
            if (!is_array($country_data)) {
                continue;
            }

            if (!isset($settings['countryData'][$country_code]['locale']) || !is_array($settings['countryData'][$country_code]['locale'])) {
                $settings['countryData'][$country_code]['locale'] = [];
            }

            foreach ($removed_fields as $removed_field) {
                if (!isset($settings['countryData'][$country_code]['locale'][$removed_field]) || !is_array($settings['countryData'][$country_code]['locale'][$removed_field])) {
                    $settings['countryData'][$country_code]['locale'][$removed_field] = [];
                }

                $settings['countryData'][$country_code]['locale'][$removed_field]['required'] = false;
                $settings['countryData'][$country_code]['locale'][$removed_field]['hidden']   = true;
            }
        }
    }

    return $settings;
}

// if (get_option('onepaquc_checkout_fields')) {
//     $checkout_fields = get_option('onepaquc_checkout_fields');
//     foreach ($checkout_fields as $field) {
//         if (isset($onepaquc_rcheckoutformfields[$field])) {
//             $selector = $onepaquc_rcheckoutformfields[$field]['selector'];
//             $custom_css .= "{$selector} { display: none !important; }";
//         }
//     }
// }


// add_settings_link
function onepaquc_add_settings_link($links)
{
    if (!is_array($links)) {
        $links = [];
    }
    $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=onepaquc_cart')) . '">' . esc_html__('Settings', 'one-page-quick-checkout-for-woocommerce') . '</a>';
    $pro_link = '<a href="https://plugincy.com/one-page-quick-checkout-for-woocommerce" style="color: #ff5722; font-weight: bold;" target="_blank">' . esc_html__('Get Pro', 'one-page-quick-checkout-for-woocommerce') . '</a>';
    $links[] = $settings_link;
    $links[] = $pro_link;
    return $links;
}


// add settings button after deactivate button in plugins page

add_action('plugin_action_links_' . plugin_basename(__FILE__), 'onepaquc_add_settings_link');


if (get_option("rmenu_enable_sticky_cart", 0)) {
    function onepaquc_display_cart()
    {
        if (class_exists('WooCommerce')) {
            echo do_shortcode('[plugincy_cart drawer="right" cart_icon="cart" product_title_tag="p" position="fixed"]');
        }
    }

    add_action('wp_footer', 'onepaquc_display_cart');
}






class onepaquc_cart_analytics_main
{
    private $analytics;

    public function __construct()
    {
        // Initialize analytics with the correct plugin file path
        $this->analytics = new onepaquc_cart_anaylytics(
            '03',
            'https://plugincy.com/wp-json/product-analytics/v1',
            RMENU_VERSION,
            'One Page Quick Checkout for WooCommerce',
            __FILE__ // Pass the main plugin file
        );

        add_action('admin_footer',  array($this->analytics, "add_deactivation_feedback_form"));

        // Plugin hooks
        add_action('init', array($this, 'init'));
        if (get_option('rmenu_allow_analytics', 1)) {
            add_action('admin_init', array($this, 'admin_init'));
        }

        // Handle deactivation feedback AJAX
        add_action('wp_ajax_onepaquc_send_deactivation_feedback', array($this, 'handle_deactivation_feedback'));

        // Also enqueue script in admin to ensure AJAX variables are available
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }

    public function init()
    {
        // Any initialization code
    }

    public function admin_init()
    {
        // Send analytics data on first activation or weekly
        $this->maybe_send_analytics();
    }

    private function maybe_send_analytics()
    {
        $last_sent = get_option('onepaquc_analytics_last_sent', 0);
        $week_ago = strtotime('-1 week');

        if ($last_sent < $week_ago) {
            $this->analytics->send_tracking_data();
            update_option('onepaquc_analytics_last_sent', time());
        }
    }

    /**
     * Enqueue admin scripts to ensure AJAX URL is available
     */
    public function enqueue_admin_scripts($hook)
    {
        // Only on plugins page
        if ($hook !== 'plugins.php') {
            return;
        }

        // Ensure jQuery is loaded
        wp_enqueue_script('jquery');
    }

    public function handle_deactivation_feedback()
    {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'deactivation_feedback')) {
            wp_send_json_error(array('message' => 'Invalid nonce'));
            wp_die();
        }

        // Get and sanitize reason
        $reason = isset($_POST['reason']) ? sanitize_text_field(wp_unslash($_POST['reason'])) : 'no-reason-provided';

        // Send deactivation data through analytics class
        $result = $this->analytics->send_deactivation_data($reason);

        // Send response
        if ($result) {
            wp_send_json_success(array('message' => 'Feedback sent successfully'));
        } else {
            wp_send_json_error(array('message' => 'Failed to send feedback'));
        }

        wp_die();
    }
}

new onepaquc_cart_analytics_main();



add_action('wp_enqueue_scripts', function () {
    wp_add_inline_script('jquery-core', "
        (function() {
            function isDebugMode() {
                return new URLSearchParams(window.location.search).get('plugincydebug') === 'true';
            }
            
            window.plugincydebugLog = function() {
                if (isDebugMode() && console && console.log) {
                    console.log.apply(console, arguments);
                }
            };
        })();
    ");
});











/**
 * WooCommerce URL Parameter Add to Cart Handler
 * 
 * Handles adding products to cart via URL parameters
 * Supports: Simple, Variable, Grouped, and other product types
 * 
 * URL Parameters:
 * - onepaquc_add-to-cart: Product ID (required)
 * 
 * - onepaquc_quantity: Quantity (optional, default: 1)
 * - onepaquc_variation_id: Variation ID for variable products (optional)
 * - onepaquc_attribute_*: Variation attributes (optional)
 * 
 * Example URLs:
 * Simple Product: ?onepaquc_add-to-cart=76&onepaquc_quantity=2
 * Variable Product: ?onepaquc_add-to-cart=76&onepaquc_variation_id=1745&onepaquc_quantity=1
 * With Attributes: ?onepaquc_add-to-cart=76&onepaquc_variation_id=1745&onepaquc_attribute_pa_color=blue
 */

add_action('template_redirect', 'onepaquc_handle_url_add_to_cart', 20);


function onepaquc_handle_url_add_to_cart()
{
    if (!isset($_GET['onepaquc_add-to-cart'])) {
        return;
    }

    // Ensure cart is loaded
    if (null === WC()->cart) {
        wc_load_cart();
    }

    $product_id = absint($_GET['onepaquc_add-to-cart']);
    if ($product_id <= 0) {
        wc_add_notice(__('Invalid product ID.', 'woocommerce'), 'error');
        return;
    }

    $product = wc_get_product($product_id);
    if (!$product) {
        wc_add_notice(__('Product not found.', 'woocommerce'), 'error');
        return;
    }
    if (!$product->is_purchasable()) {
        wc_add_notice(__('This product cannot be purchased.', 'woocommerce'), 'error');
        return;
    }

    $quantity = isset($_GET['onepaquc_quantity']) ? max(1, absint($_GET['onepaquc_quantity'])) : 1;

    $variation_id = isset($_GET['onepaquc_variation_id']) ? absint($_GET['onepaquc_variation_id']) : 0;
    $variation    = array();
    $cart_item_data = array();

    // Collect variations from either JSON or prefixed query args
    if ($product->is_type('variable')) {
        // 1) JSON blob: onepaquc_variations={"attribute_pa_brand":"dell"}
        if (!empty($_GET['onepaquc_variations'])) {
            $json_raw = wp_unslash($_GET['onepaquc_variations']);
            // Some servers escape quotes; handle both raw and urldecoded
            $decoded  = json_decode($json_raw, true);
            if (!is_array($decoded)) {
                $decoded = json_decode(urldecode($json_raw), true);
            }
            if (is_array($decoded)) {
                foreach ($decoded as $k => $v) {
                    $variation[onepaquc_normalize_attr_key($k)] = onepaquc_normalize_attr_value($v);
                }
            }
        }

        // 2) Fallback: query params like onepaquc_attribute_pa_color=blue
        foreach ($_GET as $key => $value) {
            if (strpos($key, 'onepaquc_attribute_') === 0) {
                $attr_key = substr($key, strlen('onepaquc_attribute_'));
                $variation[onepaquc_normalize_attr_key($attr_key)] = onepaquc_normalize_attr_value($value);
            }
        }

        if ($variation_id <= 0) {
            wc_add_notice(__('Please select product options before adding to cart.', 'woocommerce'), 'error');
            return;
        }

        $variation_product = wc_get_product($variation_id);
        if (!$variation_product || $variation_product->get_parent_id() !== $product_id) {
            wc_add_notice(__('Invalid variation selected.', 'woocommerce'), 'error');
            return;
        }

        // Ensure we provide all attributes required by this variation
        $required = $variation_product->get_variation_attributes(); // already like ['attribute_pa_color'=>'blue']
        foreach ($required as $req_key => $req_val) {
            if (empty($variation[$req_key])) {
                $variation[$req_key] = $req_val;
            }
        }
    }

    // Stock check (handles simple & variation)
    $p_for_stock = ($variation_id > 0) ? wc_get_product($variation_id) : $product;
    if (!$p_for_stock || !$p_for_stock->has_enough_stock($quantity)) {
        wc_add_notice(
            sprintf(__('Sorry, we do not have enough "%s" in stock.', 'woocommerce'), $p_for_stock ? $p_for_stock->get_name() : $product->get_name()),
            'error'
        );
        return;
    }

    // Add to cart
    try {
        $added = false;
        if ($variation_id > 0) {
            $added = WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variation, $cart_item_data);
        } else {
            $added = WC()->cart->add_to_cart($product_id, $quantity, 0, array(), $cart_item_data);
        }

        if ($added) {
            // Optional success notice
            wc_add_to_cart_message(array($product_id => $quantity), true);

            // Always redirect to /checkout/ WITHOUT the add-to-cart params
            $redirect_url = onepaquc_get_clean_checkout_url();
            wp_safe_redirect($redirect_url);
            exit;
        } else {
            wc_add_notice(__('Unable to add product to cart.', 'woocommerce'), 'error');
        }
    } catch (Exception $e) {
        wc_add_notice($e->getMessage(), 'error');
    }
}

/**
 * Get a clean checkout URL (no onepaquc_* params) to avoid repeat add on refresh.
 */
function onepaquc_get_clean_checkout_url()
{
    // Base checkout URL
    $checkout_url = get_option('rmenu_wc_checkout_method', 'direct_checkout') === "direct_checkout" ? wc_get_checkout_url() : wc_get_cart_url();

    // Remove any left-over params if we landed on /checkout/?onepaquc_* already
    $remove = array('onepaquc_add-to-cart', 'onepaquc_quantity', 'onepaquc_variation_id', 'onepaquc_variations');
    // Also strip any per-attribute params
    if (!empty($_GET)) {
        foreach (array_keys($_GET) as $k) {
            if (strpos($k, 'onepaquc_attribute_') === 0) {
                $remove[] = $k;
            }
        }
    }

    $checkout_url = remove_query_arg(array_unique($remove), $checkout_url);
    return $checkout_url;
}

/**
 * Normalize attribute key to Woo format: ensure it starts with 'attribute_' and is lowercase.
 * Accepts keys like 'pa_color', 'attribute_pa_color', 'Color', etc.
 */
function onepaquc_normalize_attr_key($key)
{
    $key = wc_clean(wp_unslash($key));
    $key = strtolower($key);
    // If already starts with attribute_, keep; else prepend
    if (strpos($key, 'attribute_') !== 0) {
        // If user passed pa_xxx or taxonomy name, prepend attribute_
        $key = 'attribute_' . $key;
    }
    return $key;
}

/**
 * Normalize attribute value to a slug Woo expects for variations.
 */
function onepaquc_normalize_attr_value($value)
{
    // Convert to slug (e.g., 'Deep Blue' -> 'deep-blue')
    return sanitize_title(wc_clean(wp_unslash($value)));
}


/**
 * Get cart redirect URL
 * 
 * @return string Redirect URL
 */
function onepaquc_get_cart_redirect_url()
{
    // Get the current URL without query parameters
    $current_url = home_url(add_query_arg(array(), wp_unslash($_SERVER['REQUEST_URI'])));

    // Remove all onepaquc parameters
    $redirect_url = remove_query_arg(
        array(
            'onepaquc_add-to-cart',
            'onepaquc_quantity',
            'onepaquc_variation_id'
        ),
        $current_url
    );

    // Remove attribute parameters
    $parsed_url = parse_url($current_url);
    if (isset($parsed_url['query'])) {
        parse_str($parsed_url['query'], $query_params);
        foreach ($query_params as $key => $value) {
            if (strpos($key, 'onepaquc_attribute_') === 0) {
                $redirect_url = remove_query_arg($key, $redirect_url);
            }
        }
    }

    // Stay on the same page (cart, checkout, or wherever they were)
    return $redirect_url;
}

/**
 * Optional: Add custom cart item data
 * Use this filter to add custom data to cart items
 */
add_filter('woocommerce_add_cart_item_data', 'onepaquc_add_custom_cart_item_data', 10, 3);

function onepaquc_add_custom_cart_item_data($cart_item_data, $product_id, $variation_id)
{
    // Check if this was added via our URL handler
    if (isset($_GET['onepaquc_add-to-cart'])) {
        // Add custom data here if needed
        // Example: $cart_item_data['custom_field'] = 'custom_value';

        // Add a unique identifier to prevent duplicate cart items from being merged
        // Remove this if you want products to merge in cart
        // $cart_item_data['unique_key'] = md5(microtime() . rand());
    }

    return $cart_item_data;
}

/**
 * Optional: Validate cart item before adding
 */
add_filter('woocommerce_add_to_cart_validation', 'onepaquc_validate_cart_item', 10, 3);

function onepaquc_validate_cart_item($passed, $product_id, $quantity)
{
    // Add custom validation rules here
    // Example: Check if user is logged in for certain products

    return $passed;
}


// Allow checkout page access even when the cart is empty
add_action('template_redirect', function () {
    if (is_checkout() && !is_wc_endpoint_url()) {
        remove_action('template_redirect', 'wc_redirect_empty_cart_to_cart');
    }
}, 1);

// Let users access checkout even if the cart is empty
add_filter('woocommerce_checkout_redirect_empty_cart', '__return_false');
